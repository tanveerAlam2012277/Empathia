import "package:flutter/foundation.dart";
import "package:flutter/material.dart";
import "package:fluttertoast/fluttertoast.dart";
import "package:shared_preferences/shared_preferences.dart";
import "package:store/features/authentication/model/user_model.dart";
import "package:store/features/authentication/view/on_board/on_board.dart";
import "package:store/features/authentication/view/modules/patient/patient_home.dart";
import "package:store/home2.dart";
import "package:store/utils/api_routes.dart";
import "package:store/utils/helper/helper_function.dart";
import "package:store/viewModel/patient/services/user_view_model.dart";
import "package:zego_uikit_prebuilt_call/zego_uikit_prebuilt_call.dart";
import "package:zego_uikit_signaling_plugin/zego_uikit_signaling_plugin.dart";
import 'package:http/http.dart' as http;

class SplashServices {
  Future<User> getUserData() => UserViewModel().getUser();
  void checkAuthentication(BuildContext context) async {
    final dp = await SharedPreferences.getInstance();
    final userType = dp.getString("userType");
    getUserData().then((value) {
      if (userType == "patient") {
        ZegoUIKitPrebuiltCallInvitationService().init(
          appID: APIRoutes.zegoAppID,
          appSign: APIRoutes.zegoAppSign,
          userID: dp.getString("email")!,
          userName: dp.getString("email")!.toString().split("@")[0],
          plugins: [
            ZegoUIKitSignalingPlugin(),
          ],
        );
        THelperFunction.navigatedToScreenWithPop(context, PatientHomeScreen());
      } else if (userType == "psychology") {
        ZegoUIKitPrebuiltCallInvitationService().init(
          appID: APIRoutes.zegoAppID,
          appSign: APIRoutes.zegoAppSign,
          userID: dp.getString("email")!,
          userName: dp.getString("name")!,
          plugins: [
            ZegoUIKitSignalingPlugin(),
          ],
          invitationEvents: ZegoUIKitPrebuiltCallInvitationEvents(
            onOutgoingCallAccepted: (callID, callee) async {
              await http.post(
                Uri.parse(APIRoutes.deductMoney),
                body: {
                  "id": callID.split("_")[1],
                  "amount": "100",
                },
              ).then((val) async {
                await http.put(
                  Uri.parse(APIRoutes.updateApptStatus),
                  body: {
                    "appointmentId": callID.split("_")[0],
                    "status": "completed",
                  },
                ).then((val) {
                  THelperFunction.navigatedToScreenWithPop(
                      context, const HomeScreen2());
                });
              });
            },
          ),
        );
        THelperFunction.navigatedToScreenWithPop(context, const HomeScreen2());
      } else {
        THelperFunction.navigatedToScreenWithPop(context, const OnBoard());
      }
    }).onError((error, stackTrace) {
      if (kDebugMode) {
        print(error.toString());
      }
    });
  }
}
