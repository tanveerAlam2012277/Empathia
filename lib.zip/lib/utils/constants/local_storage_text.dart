class LocalStorageText {
  LocalStorageText._();
  static const  String email = "email";
}
