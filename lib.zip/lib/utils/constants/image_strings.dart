class TImageString {
  TImageString._();

  // ! Gif
  static const String patient = "assets/gif/patient.gif";
  static const String psychologist = "assets/gif/psychologist.gif";




  // ! auth images
  static const String deleiveredImage =
      "assets/images/auth/sammy-line-man-receives-a-mail.png";
  static const String verifiedImage =
      "assets/images/auth/sammy-line-man-and-woman-high-fiving-each-other.png";
  static const String verifiedSuccess =
      "assets/images/auth/verified.png";


  // ! mmusic image
    static const String musicCd =
      "assets/images/music/music_cd.png";

}
 