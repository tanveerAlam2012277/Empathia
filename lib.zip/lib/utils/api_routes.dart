class APIRoutes {
  static const String baseURL =
      "https://empbackend-production-6ea7.up.railway.app/";
  static const String getCategories = baseURL + "categories";
  static const String getAllMusicByGenres = baseURL + "music/all";
  static const String getArticlesByCat = baseURL + "articles/";

  static const String setMoodRecord = baseURL + "user/registerMood";
  static const String getMoodRecords = baseURL + "user/getUserMoodsForDay";

  static const String getUserDetails = baseURL + "user/get";
  static const String setCommunityName = baseURL + "user/setCommunityName";

  static const String checkTestEligibility = baseURL + "test/checkEligibility";
  static const String getTest = baseURL + "test/getSingle";
  static const String submitTest = baseURL + "test/addTestResult";

  static const String createPost = baseURL + "post/create";
  static const String likePost = baseURL + "post/like";
  static const String unlikePost = baseURL + "post/unlike";
  static const String getAllPosts = baseURL + "post/getAll";

  static const String getAllGroups = baseURL + "group/all";
  static const String addMessage = baseURL + "group/addMessage";
  static const String getMessages = baseURL + "group/messages/";

  static const String allMotivation = baseURL + "motivation/all";
  static const String allHopeboard = baseURL + "hopeboard/all";
  static const String deleteHopeboard = baseURL + "hopeboard/delete";
  static const String createHopeboard = baseURL + "hopeboard/create";

  static const String getAmountInWallet =
      baseURL + "user/getUsersAmountInWallet";
  static const String addMoney = baseURL + "user/addMoneyInWallet";
  static const String deductMoney = baseURL + "user/removeMoneyFromWallet";

  static const String markOffline = baseURL + "cyco/offline";
  static const String markOnline = baseURL + "cyco/online";
  static const String getCyco = baseURL + "cyco/get";
  static const String getOnlineCycos = baseURL + "cyco/getAllOnline";
  static const String requestAppointment = baseURL + "cyco/request";
  static const String viewRequests = baseURL + "cyco/upcoming";
  static const String cancelAppointment = baseURL + "cyco/cancelAppointment";
  static const String updateApptStatus = baseURL + "cyco/updateStatus";

  static const String zegoAppSign =
      "23154c3b03be1b6e435ff8ad594e152a7d1b2fe250c162e80a624e78aee31f87";
  static const int zegoAppID = 1358820995;
}
