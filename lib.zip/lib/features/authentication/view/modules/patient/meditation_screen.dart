import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:store/features/authentication/model/genre.model.dart';
import 'package:store/features/authentication/view/modules/patient/widget/meditation_music_player/meditation_music_player.dart';
import 'package:http/http.dart' as http;
import 'package:store/utils/api_routes.dart';

class MeditationScreen extends StatefulWidget {
  const MeditationScreen({super.key});

  @override
  State<MeditationScreen> createState() => _MeditationScreenState();
}

class _MeditationScreenState extends State<MeditationScreen> {
  List<Genre> genres = [];

  @override
  void initState() {
    super.initState();
    getGenres();
  }

  getGenres() {
    http
        .get(
      Uri.parse(
        APIRoutes.getAllMusicByGenres,
      ),
    )
        .then((response) {
      var jsonData = jsonDecode(response.body)['genres'];
      List<Genre> cats = [];
      for (var item in jsonData) {
        cats.add(Genre.fromJson(item));
      }
      setState(() {
        genres = cats;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 15),
              Text(
                "Meditation",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 3),
              Text(
                "Soothing sounds to relax your mind.",
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              if (genres.length > 0)
                Expanded(
                  child: ListView.builder(
                    itemBuilder: (context, index) {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              vertical: 10.0,
                            ),
                            child: Text(
                              genres[index].name,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 160,
                            child: ListView.builder(
                              shrinkWrap: true,
                              scrollDirection: Axis.horizontal,
                              itemBuilder: (context, i) {
                                return GestureDetector(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      CupertinoPageRoute(
                                        builder: (context) =>
                                            MeditationMusicPlayer(
                                          musicUrls:
                                              genres[index].musics[i].url,
                                          title: genres[index].musics[i].title +
                                              " from " +
                                              genres[index].name,
                                        ),
                                      ),
                                    );
                                  },
                                  child: Card(
                                    elevation: 5,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        image: DecorationImage(
                                          image: NetworkImage(
                                            genres[index].musics[i].image,
                                          ),
                                          fit: BoxFit.cover,
                                          colorFilter: ColorFilter.mode(
                                            Colors.black.withOpacity(0.4),
                                            BlendMode.darken,
                                          ),
                                        ),
                                      ),
                                      width: 160,
                                      child: Center(
                                        child: Text(
                                          genres[index].musics[i].title,
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              },
                              itemCount: genres[index].musics.length,
                            ),
                          ),
                        ],
                      );
                    },
                    itemCount: genres.length,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
