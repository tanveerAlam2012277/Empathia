import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:store/features/authentication/model/user_model.dart';
import 'package:store/features/authentication/view/modules/patient/all_groups.dart';
import 'package:store/features/authentication/view/modules/patient/public_community.dart';
import 'package:http/http.dart' as http;
import 'package:store/utils/api_routes.dart';
import 'package:store/utils/constants/colors.dart';

class CommunityScreen extends StatefulWidget {
  const CommunityScreen({super.key});

  @override
  State<CommunityScreen> createState() => _CommunityScreenState();
}

class _CommunityScreenState extends State<CommunityScreen> {
  EmpUser? user;

  TextEditingController communityNameController = TextEditingController();

  @override
  void initState() {
    super.initState();
    getUser();
  }

  getUser() async {
    final SharedPreferences dp = await SharedPreferences.getInstance();
    final String? userId = dp.getString("userId");
    http.post(
      Uri.parse(
        APIRoutes.getUserDetails,
      ),
      body: {
        "id": userId,
      },
    ).then((response) {
      if (response.statusCode == 200) {
        var jsonResponse = jsonDecode(response.body);
        print(jsonResponse);
        user = EmpUser.fromJson(
          jsonResponse['user'],
        );
        setState(() {
          communityNameController.text = user!.communityName;
        });
        if (user!.communityName == "Anonymous") {
          showCommunityNameDialog();
        }
      } else {
        Fluttertoast.showToast(
            msg: "There was an error in the system. Please try again later.");
      }
    });
  }

  showCommunityNameDialog() {
    showModalBottomSheet(
      isScrollControlled: true,
      context: context,
      builder: (context) {
        return Padding(
          padding:
              EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
          child: Container(
            padding: EdgeInsets.all(15),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Set Community Name",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  "Set a community name to chat with other users.",
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.grey,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 20),
                TextField(
                  decoration: InputDecoration(
                    hintText: "Community Name",
                  ),
                  controller: communityNameController,
                ),
                SizedBox(height: 20),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      http.post(
                        Uri.parse(
                          APIRoutes.setCommunityName,
                        ),
                        body: {
                          "id": user!.id,
                          "communityName": communityNameController.text,
                        },
                      ).then((response) {
                        if (response.statusCode == 200) {
                          Navigator.pop(context);
                          Fluttertoast.showToast(
                              msg: "Name changed successfully.");
                          getUser();
                        } else {
                          Fluttertoast.showToast(
                              msg:
                                  "There was an error in the system. Please try again later.");
                        }
                      });
                    },
                    child: Text("Set Community Name"),
                    style: ButtonStyle(
                      backgroundColor: WidgetStatePropertyAll(TColors.primary),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: 15.0,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 15),
              Text(
                "Community",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
              ),
              SizedBox(height: 3),
              Text(
                "Chat with fellow users in public and private groups.",
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.grey,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              ListTile(
                onTap: () {
                  showCommunityNameDialog();
                },
                title: Text(
                  "Chatting As:",
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                subtitle: Text(
                  user == null ? "Loading..." : user!.communityName,
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.grey,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                trailing: Icon(
                  Icons.edit,
                  color: TColors.primary,
                ),
              ),
              SizedBox(
                height: 10,
              ),
              if (user == null)
                Center(
                  child: CupertinoActivityIndicator(
                    color: TColors.primary,
                  ),
                ),
              if (user != null)
                TabBar(
                  tabs: [
                    Tab(
                      text: "Public",
                    ),
                    Tab(
                      text: "Groups",
                    ),
                  ],
                ),
              if (user != null)
                Expanded(
                  child: TabBarView(
                    physics: NeverScrollableScrollPhysics(),
                    children: [
                      PublicCommunity(
                        user: user!,
                      ),
                      AllGroups(),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
