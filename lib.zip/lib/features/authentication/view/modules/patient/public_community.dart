import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:store/features/authentication/model/grouppost.model.dart';
import 'package:store/features/authentication/model/user_model.dart';
import 'package:store/utils/api_routes.dart';
import 'package:store/utils/constants/colors.dart';

class PublicCommunity extends StatefulWidget {
  EmpUser user;

  PublicCommunity({required this.user});

  @override
  State<PublicCommunity> createState() => _PublicCommunityState();
}

class _PublicCommunityState extends State<PublicCommunity> {
  TextEditingController _messageController = TextEditingController();

  bool isPosting = false;

  String replyingTo = "";

  String email = "";

  List<GroupPost> posts = [];

  @override
  void initState() {
    super.initState();
    getAllPosts();
  }

  void getAllPosts() async {
    final response = await http.get(
      Uri.parse(
        APIRoutes.getAllPosts,
      ),
    );

    if (response.statusCode == 200) {
      final postsData = json.decode(response.body);
      print(postsData);

      List<GroupPost> postsList = [];

      postsData['data'].forEach((postData) {
        postsList.add(GroupPost.fromJson(postData));
      });

      setState(() {
        posts = postsList;
      });
    } else {
      print("Error fetching posts");
    }
  }

  createPost() async {
    setState(() {
      isPosting = true;
    });

    final response = await http.post(
      Uri.parse(
        APIRoutes.createPost,
      ),
      body: {
        "message": _messageController.text,
        "replyTo": replyingTo,
        "user": widget.user.id,
      },
    );

    if (response.statusCode == 200) {
      Fluttertoast.showToast(msg: "Post created successfully");
      setState(() {
        _messageController.clear();
      });
    } else {
      Fluttertoast.showToast(
        msg: "There was an error creating the post, please try again later.",
      );
    }

    setState(() {
      isPosting = false;
      getAllPosts();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                height: 10,
              ),
              if (replyingTo != "")
                Card(
                  child: ListTile(
                    title: Text(
                      "Replying to:",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    subtitle: Padding(
                      padding: const EdgeInsets.only(top: 5.0),
                      child: Text(
                        replyingTo,
                        style: GoogleFonts.eduVicWaNtBeginner(
                          fontSize: 16,
                        ),
                      ),
                    ),
                    trailing: InkWell(
                      onTap: () {
                        setState(() {
                          replyingTo = "";
                        });
                      },
                      child: Icon(
                        CupertinoIcons.clear,
                        size: 25,
                        color: Colors.red,
                      ),
                    ),
                  ),
                ),
              if (replyingTo != "")
                SizedBox(
                  height: 10,
                ),
              TextField(
                controller: _messageController,
                onChanged: (value) {
                  setState(() {});
                },
                decoration: InputDecoration(
                  hintText: "Enter your message",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  suffixIcon: IconButton(
                    icon: Icon(
                      Icons.send,
                      color: _messageController.text.isEmpty
                          ? Colors.grey
                          : Colors.blue,
                    ),
                    onPressed: () {
                      if (_messageController.text.isEmpty) {
                        Fluttertoast.showToast(
                          msg: "Please enter a message",
                        );
                        return;
                      }

                      createPost();
                    },
                  ),
                ),
                maxLines: 5,
              ),
              SizedBox(
                height: 10,
              ),
              if (posts.isEmpty)
                Center(
                  child: CircularProgressIndicator(),
                ),
              if (posts.isNotEmpty)
                Expanded(
                  child: ListView.builder(
                    shrinkWrap: true,
                    physics: BouncingScrollPhysics(),
                    itemCount: posts.length,
                    itemBuilder: (context, index) {
                      return Card(
                        child: Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ListTile(
                                leading: Icon(
                                  CupertinoIcons.person_alt_circle_fill,
                                  size: 25,
                                  color: TColors.primary,
                                ),
                                title: Text(
                                  posts[index].userName,
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                              if (posts[index].replyTo != "")
                                ListTile(
                                  leading: Icon(
                                    Icons.reply,
                                    color: Colors.grey,
                                  ),
                                  title: Text(
                                    "Replying to: ${posts[index].replyTo.trim()}",
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.grey,
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              Text(
                                posts[index].message,
                                style: GoogleFonts.eduVicWaNtBeginner(
                                  fontSize: 16,
                                ),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              if (posts[index].replyTo != "")
                                SizedBox(
                                  height: 10,
                                ),
                              Row(
                                children: [
                                  if (!posts[index].likes.contains(email))
                                    InkWell(
                                      onTap: () async {
                                        final response = await http.post(
                                          Uri.parse(
                                            APIRoutes.likePost,
                                          ),
                                          body: {
                                            "postId": posts[index].id,
                                            "email": email,
                                          },
                                        );

                                        if (response.statusCode == 200) {
                                          Fluttertoast.showToast(
                                            msg: "Post liked successfully",
                                          );
                                          setState(() {
                                            posts[index].likes.add(email);
                                          });
                                        } else {
                                          Fluttertoast.showToast(
                                            msg: "Error liking post",
                                          );
                                        }
                                      },
                                      child: Icon(
                                        Icons.thumb_up_alt_outlined,
                                        color: Colors.blue,
                                      ),
                                    ),
                                  if (posts[index].likes.contains(email))
                                    InkWell(
                                      onTap: () async {
                                        final response = await http.post(
                                          Uri.parse(
                                            APIRoutes.unlikePost,
                                          ),
                                          body: {
                                            "postId": posts[index].id,
                                            "email": email,
                                          },
                                        );

                                        if (response.statusCode == 200) {
                                          Fluttertoast.showToast(
                                            msg: "Post unliked successfully",
                                          );
                                          setState(() {
                                            posts[index].likes.remove(email);
                                          });
                                        } else {
                                          Fluttertoast.showToast(
                                            msg: "Error unliking post",
                                          );
                                        }
                                      },
                                      child: Icon(
                                        Icons.thumb_up_alt,
                                        color: Colors.blue,
                                      ),
                                    ),
                                  SizedBox(
                                    width: 10,
                                  ),
                                  Text(
                                    "${posts[index].likes.length}",
                                    style: TextStyle(
                                      fontSize: 18,
                                    ),
                                  ),
                                  Spacer(),
                                  InkWell(
                                    onTap: () {
                                      setState(() {
                                        replyingTo = posts[index].userName +
                                            ": " +
                                            posts[index].message;
                                      });
                                    },
                                    child: Text(
                                      "Reply",
                                      style: TextStyle(
                                        fontSize: 16,
                                        color: Colors.blue,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
