import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class TestResultScreen extends StatefulWidget {
  int rating;
  String module;

  TestResultScreen({
    required this.rating,
    required this.module,
  });

  @override
  State<TestResultScreen> createState() => _TestResultScreenState();
}

class _TestResultScreenState extends State<TestResultScreen> {
  List<String> ratingEmojis = ["😨", "😥", "🙂", "😄"];
  List<String> ratingName = ["Severe", "Moderate", "Mild", "Normal"];
  List<String> ratingRemarks = [
    "You are in a severe condition. Please consult a doctor immediately.",
    "You are in a moderate condition. Please consult a doctor.",
    "You are in a mild condition. Please take care of yourself.",
    "You are in a normal condition. Keep it up!"
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Column(
            children: [
              SizedBox(
                height: 20,
              ),
              Text(
                "Test Result",
                style: TextStyle(
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                "Your rating is",
                style: TextStyle(
                  fontSize: 20,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                ratingEmojis[widget.rating - 1],
                style: TextStyle(
                  fontSize: 50,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                ratingName[widget.rating - 1],
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                ratingRemarks[widget.rating - 1],
                style: TextStyle(
                  fontSize: 20,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text("Home"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
