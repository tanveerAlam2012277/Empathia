import 'dart:convert';

import 'package:chart_sparkline/chart_sparkline.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:store/features/authentication/model/mood.model.dart';
import 'package:http/http.dart' as http;
import 'package:store/utils/api_routes.dart';
import 'package:store/utils/constants/colors.dart';

class MoodTrackerScreen extends StatefulWidget {
  const MoodTrackerScreen({super.key});

  @override
  State<MoodTrackerScreen> createState() => _MoodTrackerScreenState();
}

class _MoodTrackerScreenState extends State<MoodTrackerScreen> {
  DateTime selectedDate = DateTime.now();
  double averageMood = 0.0;
  List<Mood> moods = [];

  bool isLoading = true;

  double ratingMeter = 0.0;

  List<double> data = [];
  List<Color> colors = [];

  @override
  void initState() {
    super.initState();
    getMoodRecords();
  }

  bool isToday(DateTime date) {
    final now = DateTime.now();
    return date.year == now.year &&
        date.month == now.month &&
        date.day == now.day;
  }

  getMoodRecords() async {
    setState(() {
      isLoading = true;
      data = [];
      colors = [];
      moods = [];
      averageMood = 0.0;
    });
    final SharedPreferences dp = await SharedPreferences.getInstance();
    final String? userId = dp.getString("userId");
    // print("SENDING FOR $userId");
    http.post(
      Uri.parse(
        APIRoutes.getMoodRecords,
      ),
      body: {
        "date": selectedDate.toString(),
        "userId": userId,
      },
    ).then((response) {
      if (response.statusCode == 200) {
        List<Mood> moodList = [];
        var jsonResponse = jsonDecode(response.body);
        print(jsonResponse);
        for (var mood in jsonResponse['moods']) {
          moodList.add(Mood.fromJson(mood));
        }
        setState(() {
          moods = moodList;
          averageMood = jsonResponse['averageMood'] ?? 0.0;
          if (moods.isNotEmpty) {
            data = moods.map((e) => e.rating).toList();
            List<Color?> nullableColors =
                data.map((rating) => getMoodColor(rating)).toList();
            List<Color> nonNullableColors = nullableColors
                .where((color) => color != null)
                .toList()
                .cast<Color>();
            colors = nonNullableColors;
          }
          isLoading = false;
        });
      }
    });
  }

  Color? getMoodColor(double rating) {
    if (rating < 0.75) {
      return Colors.red; // Very Bad
    } else if (rating < 1.25) {
      return Colors.orange[800]; // Bad
    } else if (rating < 1.75) {
      return Colors.orange[400]; // Not Good
    } else if (rating < 2.25) {
      return Colors.yellow[700]; // Average
    } else if (rating < 2.75) {
      return Colors.yellow[500]; // Good
    } else if (rating < 3.25) {
      return Colors.lightGreen[500]; // Very Good
    } else if (rating < 3.75) {
      return Colors.lightGreen[800]; // Excellent
    } else if (rating < 4.25) {
      return Colors.green[500]; // Outstanding
    } else if (rating < 4.75) {
      return Colors.green[800]; // Fantastic
    } else {
      return Colors.green; // Perfect
    }
  }

  String getMood(double rating) {
    if (rating < 0.75) {
      return "Very Bad";
    } else if (rating < 1.25) {
      return "Bad";
    } else if (rating < 1.75) {
      return "Not Good";
    } else if (rating < 2.25) {
      return "Average";
    } else if (rating < 2.75) {
      return "Good";
    } else if (rating < 3.25) {
      return "Very Good";
    } else if (rating < 3.75) {
      return "Excellent";
    } else if (rating < 4.25) {
      return "Outstanding";
    } else if (rating < 4.75) {
      return "Fantastic";
    } else {
      return "Perfect";
    }
  }

  String getMoodEmoji(double rating) {
    if (rating < 0.75) {
      return "😭"; // Very Bad
    } else if (rating < 1.25) {
      return "😞"; // Bad
    } else if (rating < 1.75) {
      return "😐"; // Not Good
    } else if (rating < 2.25) {
      return "😕"; // Average
    } else if (rating < 2.75) {
      return "😊"; // Good
    } else if (rating < 3.25) {
      return "😀"; // Very Good
    } else if (rating < 3.75) {
      return "😁"; // Excellent
    } else if (rating < 4.25) {
      return "😃"; // Outstanding
    } else if (rating < 4.75) {
      return "😄"; // Fantastic
    } else {
      return "😍"; // Perfect
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          physics: NeverScrollableScrollPhysics(),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 25.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 15),
                Text(
                  "Mood Tracker",
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 2),
                Text(
                  "Track your moods for everyday.",
                  style: TextStyle(
                    fontSize: 14,
                    color: Colors.grey,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(
                  height: 20,
                ),
                if (isLoading)
                  Center(
                    child: CircularProgressIndicator(
                      color: TColors.primary,
                    ),
                  ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: GestureDetector(
                        onTap: () {
                          showDatePicker(
                            context: context,
                            initialDate: selectedDate,
                            firstDate: DateTime(2024),
                            lastDate: DateTime.now(),
                          ).then((value) {
                            if (value != null) {
                              setState(() {
                                selectedDate = value;
                                getMoodRecords();
                              });
                            }
                          });
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: TColors.primary,
                              width: 2,
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Wrap(
                              children: [
                                Text(
                                  DateFormat.yMMMMEEEEd()
                                      .format(selectedDate)
                                      .toString(),
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                SizedBox(
                                  width: 10,
                                ),
                                Icon(
                                  Icons.edit,
                                  color: TColors.primary,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    if (!isLoading && data.isNotEmpty)
                      Sparkline(
                        data: data,
                        lineWidth: 10.0,
                        useCubicSmoothing: true,
                        lineGradient: LinearGradient(
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          colors: colors,
                        ),
                      ),
                    SizedBox(
                      height: 20,
                    ),
                    if (isToday(selectedDate))
                      Center(
                        child: RatingBar.builder(
                          initialRating: 3,
                          itemCount: 5,
                          allowHalfRating: true,
                          itemBuilder: (context, index) {
                            switch (index) {
                              case 0:
                                return Icon(
                                  Icons.sentiment_very_dissatisfied,
                                  color: Colors.red,
                                );
                              case 1:
                                return Icon(
                                  Icons.sentiment_dissatisfied,
                                  color: Colors.redAccent,
                                );
                              case 2:
                                return Icon(
                                  Icons.sentiment_neutral,
                                  color: Colors.amber,
                                );
                              case 3:
                                return Icon(
                                  Icons.sentiment_satisfied,
                                  color: Colors.lightGreen,
                                );
                              case 4:
                                return Icon(
                                  Icons.sentiment_very_satisfied,
                                  color: Colors.green,
                                );
                              default:
                                return Container();
                            }
                          },
                          onRatingUpdate: (rating) {
                            setState(() {
                              ratingMeter = rating;
                            });
                          },
                        ),
                      ),
                    if (isToday(selectedDate))
                      SizedBox(
                        height: 20,
                      ),
                    if (isToday(selectedDate))
                      Center(
                        child: GestureDetector(
                          onTap: () async {
                            showDialog(
                                context: context,
                                builder: (context) {
                                  return AlertDialog(
                                    title: Text("Add Mood"),
                                    content: Text(
                                      "Are you sure you want to add \"${getMood(ratingMeter)}\" rating to your mood?",
                                    ),
                                    actions: [
                                      TextButton(
                                        onPressed: () {
                                          Navigator.pop(context);
                                        },
                                        child: Text("Cancel"),
                                      ),
                                      TextButton(
                                        onPressed: () async {
                                          final SharedPreferences dp =
                                              await SharedPreferences
                                                  .getInstance();
                                          final String? userId =
                                              dp.getString("userId");
                                          print("SENDING FOR $userId");
                                          Clipboard.setData(
                                            ClipboardData(
                                              text: userId!,
                                            ),
                                          );
                                          http.post(
                                              Uri.parse(
                                                APIRoutes.setMoodRecord,
                                              ),
                                              body: {
                                                "rating":
                                                    ratingMeter.toString(),
                                                "userId": userId,
                                              }).then((response) {
                                            print(
                                              jsonDecode(
                                                response.body,
                                              ),
                                            );
                                            if (response.statusCode == 200) {
                                              getMoodRecords();
                                              Navigator.pop(context);
                                            }
                                          });
                                        },
                                        child: Text("Add"),
                                      ),
                                    ],
                                  );
                                });
                          },
                          child: Card(
                            elevation: 5,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(100),
                            ),
                            child: Container(
                              decoration: BoxDecoration(
                                color: TColors.primary,
                                borderRadius: BorderRadius.circular(100),
                              ),
                              child: Padding(
                                padding: const EdgeInsets.all(15.0),
                                child: Icon(
                                  Icons.add,
                                  color: Colors.white,
                                  size: 40,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    SizedBox(
                      height: 10,
                    ),
                    if (!isLoading && data.isNotEmpty)
                      Card(
                        elevation: 5,
                        child: Container(
                          decoration: BoxDecoration(
                            color: TColors.accent,
                            borderRadius: BorderRadius.circular(
                              10,
                            ),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: ListTile(
                              title: Text("Average Mood"),
                              subtitle: Text(
                                getMood(averageMood),
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              leading: Text(
                                getMoodEmoji(
                                  averageMood,
                                ),
                                style: TextStyle(
                                  fontSize: 40,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                if (!isLoading && data.isEmpty)
                  Center(
                    child: Column(
                      children: [
                        Text(
                          "No Mood Records Found",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
