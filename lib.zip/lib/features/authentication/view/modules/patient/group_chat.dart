import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:store/features/authentication/model/chat_message.dart';
import 'package:store/features/authentication/model/chatgroup.model.dart';
import 'package:store/features/authentication/model/user_model.dart';
import 'package:store/utils/api_routes.dart';

class GroupChatScreen extends StatefulWidget {
  ChatGroup chatGroup;

  GroupChatScreen({required this.chatGroup});

  @override
  _GroupChatScreenState createState() => _GroupChatScreenState();
}

class _GroupChatScreenState extends State<GroupChatScreen> {
  List<ChatMessage> messages = [];
  bool isSendingMessage = false;

  final messageController = TextEditingController();

  String userID = "";
  EmpUser? user;

  Timer? timer;

  @override
  void initState() {
    super.initState();
    getUser();
    getAllMessages();
    timer = Timer.periodic(
      Duration(seconds: 5),
      (Timer t) => getAllMessages(),
    );
  }

  getUser() async {
    final SharedPreferences dp = await SharedPreferences.getInstance();
    final String? userId = dp.getString("userId");
    setState(() {
      userID = userId!;
    });
    http.post(
      Uri.parse(
        APIRoutes.getUserDetails,
      ),
      body: {
        "id": userId,
      },
    ).then((response) {
      if (response.statusCode == 200) {
        var jsonResponse = jsonDecode(response.body);
        print(jsonResponse);
        user = EmpUser.fromJson(
          jsonResponse['user'],
        );
      } else {
        Fluttertoast.showToast(
            msg: "There was an error in the system. Please try again later.");
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  getAllMessages() {
    http.post(
      Uri.parse(
        APIRoutes.getMessages,
      ),
      body: {
        "groupId": widget.chatGroup.id,
      },
    ).then((response) {
      // print(response.body);
      var jsonResponse = jsonDecode(response.body)['data'];
      if (response.statusCode == 200) {
        List<ChatMessage> tempMessages = [];
        for (var message in jsonResponse) {
          tempMessages.add(
            ChatMessage.fromJson(
              message,
              message['user'] == userID ||
                  (message['user'] != "admin" &&
                      message['user']['_id'] != null &&
                      message['user']['_id'] == userID),
            ),
          );
        }
        setState(() {
          messages = tempMessages;
        });
      }
    });
  }

  addMessage() async {
    setState(() {
      isSendingMessage = true;
    });
    var result = await http.post(
      Uri.parse(
        APIRoutes.addMessage,
      ),
      body: {
        "message": messageController.text,
        "groupId": widget.chatGroup.id,
        "userId": userID,
      },
    );
    if (result.statusCode == 200) {
      var jsonResponse = jsonDecode(result.body)['data'];
      print(jsonResponse);
      ChatMessage sentMessage = ChatMessage.fromJson(jsonResponse, true);
      setState(() {
        messages = [sentMessage, ...messages];
        messageController.text = "";
        isSendingMessage = false;
      });
    } else {
      setState(() {
        isSendingMessage = false;
      });
      Fluttertoast.showToast(msg: "msg sending failed.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.chatGroup.name,
          // userID + " - " + messages.first.user,
          style: TextStyle(
              // fontSize: 8,
              ),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true,
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final message = messages[index];
                return Container(
                  padding: EdgeInsets.all(10),
                  child: Align(
                    alignment:
                        message.isMe ? Alignment.topRight : Alignment.topLeft,
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        maxWidth: MediaQuery.of(context).size.width *
                            0.5, // 50% of screen width
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20),
                            bottomLeft: message.isMe
                                ? Radius.circular(20)
                                : Radius.circular(0),
                            bottomRight: message.isMe
                                ? Radius.circular(0)
                                : Radius.circular(20),
                          ),
                          color: message.isMe ? Colors.blue : Colors.grey,
                        ),
                        padding: EdgeInsets.all(10),
                        child: Column(
                          crossAxisAlignment: message.isMe
                              ? CrossAxisAlignment.end
                              : CrossAxisAlignment.start,
                          children: [
                            Text(
                              message.senderName,
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                            Text(
                              message.message,
                              style: TextStyle(color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 8),
              child: TextField(
                onChanged: (value) {
                  setState(() {});
                },
                controller: messageController,
                decoration: InputDecoration(
                  hintText: 'Type a message',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  suffixIcon: IconButton(
                    icon: isSendingMessage
                        ? SizedBox(
                            height: 10,
                            width: 10,
                            child: CircularProgressIndicator(),
                          )
                        : Icon(
                            Icons.send,
                            color: messageController.text.isNotEmpty
                                ? Colors.blue
                                : Colors.grey,
                          ),
                    onPressed: () {
                      if (messageController.text.isNotEmpty) {
                        addMessage();
                      }
                    },
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
