import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:chart_sparkline/chart_sparkline.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:lottie/lottie.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:store/features/authentication/model/hopeboard.model.dart';
import 'package:store/features/authentication/model/mood.model.dart';
import 'package:http/http.dart' as http;
import 'package:store/features/authentication/model/motivation.model.dart';
import 'package:store/features/authentication/model/user_model.dart';
import 'package:store/features/authentication/view/modules/patient/hopeboard.dart';
import 'package:store/features/authentication/view/modules/patient/test_screen.dart';
import 'package:store/utils/api_routes.dart';
import 'package:store/utils/constants/colors.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  DateTime selectedDate = DateTime.now();
  double averageMood = 0.0;
  List<Mood> moods = [];

  bool isLoading = true;

  double ratingMeter = 0.0;

  List<double> data = [];
  List<Color> colors = [];

  EmpUser? user;

  List<Motivation> motivations = [];
  List<Hopeboard> hopeboards = [];

  isInHopeboard(String motivationID) {
    for (var hopeboard in hopeboards) {
      if (hopeboard.motivationID == motivationID) {
        return true;
      }
    }
    return false;
  }

  @override
  void initState() {
    super.initState();
    getUser();
    getMoodRecords();
    getMotivations();
  }

  getHopeboards() {
    http.post(
        Uri.parse(
          APIRoutes.allHopeboard,
        ),
        body: {
          "userId": user!.id,
        }).then((response) {
      if (response.statusCode == 200) {
        var jsonResponse = jsonDecode(response.body);
        print(jsonResponse);
        jsonResponse['hopeboards'].forEach((hopeboard) {
          setState(() {
            hopeboards.add(Hopeboard.fromJson(hopeboard));
          });
        });
      }
    });
  }

  getMotivations() async {
    http
        .get(
      Uri.parse(
        APIRoutes.allMotivation,
      ),
    )
        .then((response) {
      if (response.statusCode == 200) {
        var jsonResponse = jsonDecode(response.body);
        jsonResponse['motivations'].forEach((motivation) {
          setState(() {
            motivations.add(Motivation.fromJson(motivation));
          });
        });
        setState(() {
          motivations.shuffle();
        });
      }
    });
  }

  getTestEligibility() async {
    final SharedPreferences dp = await SharedPreferences.getInstance();
    final String? userId = dp.getString("userId");
    http.post(
      Uri.parse(
        APIRoutes.checkTestEligibility,
      ),
      body: {
        "id": userId,
      },
    ).then(
      (response) {
        print(response.body);
        if (response.statusCode == 200) {
          var jsonResponse = jsonDecode(response.body);
          if (jsonResponse['status'] == false) {
            showModalBottomSheet(
              isDismissible: false,
              context: context,
              builder: (context) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Wrap(
                    children: [
                      Text(
                        "Weekly Test for ${user!.selectModeules.toUpperCase()}",
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Container(
                        height: 10,
                      ),
                      Text(
                        "You are eligible to take the test for ${user!.selectModeules.toUpperCase()} this week. Would you like to take the test now?",
                        style: TextStyle(
                          fontSize: 16,
                          color: Colors.grey,
                        ),
                      ),
                      Container(
                        height: 20,
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: TextButton(
                              onPressed: () {
                                Navigator.pop(context);
                              },
                              child: Text(
                                "Not Now",
                                style: TextStyle(
                                  color: Colors.red,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () {
                                Navigator.pop(context);
                                Navigator.push(
                                  context,
                                  CupertinoPageRoute(
                                    builder: (_) => TestScreen(
                                      name: user!.selectModeules.toLowerCase(),
                                      userID: user!.id,
                                    ),
                                  ),
                                );
                              },
                              child: Text("Take Test"),
                            ),
                          ),
                        ],
                      ),
                      Container(
                        height: 20,
                      ),
                    ],
                  ),
                );
              },
            );
          }
        }
      },
    );
  }

  getUser() async {
    final SharedPreferences dp = await SharedPreferences.getInstance();
    final String? userId = dp.getString("userId");
    http.post(
      Uri.parse(
        APIRoutes.getUserDetails,
      ),
      body: {
        "id": userId,
      },
    ).then((response) {
      if (response.statusCode == 200) {
        var jsonResponse = jsonDecode(response.body);
        user = EmpUser.fromJson(
          jsonResponse['user'],
        );

        getTestEligibility();
        getHopeboards();
      } else {
        Fluttertoast.showToast(
            msg: "There was an error in the system. Please try again later.");
      }
    });
  }

  bool isToday(DateTime date) {
    final now = DateTime.now();
    return date.year == now.year &&
        date.month == now.month &&
        date.day == now.day;
  }

  getMoodRecords() async {
    setState(() {
      isLoading = true;
      data = [];
      colors = [];
      moods = [];
      averageMood = 0.0;
    });
    final SharedPreferences dp = await SharedPreferences.getInstance();
    final String? userId = dp.getString("userId");
    // print("SENDING FOR $userId");
    http.post(
      Uri.parse(
        APIRoutes.getMoodRecords,
      ),
      body: {
        "date": selectedDate.toString(),
        "userId": userId,
      },
    ).then((response) {
      if (response.statusCode == 200) {
        List<Mood> moodList = [];
        var jsonResponse = jsonDecode(response.body);
        print(jsonResponse);
        for (var mood in jsonResponse['moods']) {
          moodList.add(Mood.fromJson(mood));
        }
        setState(() {
          moods = moodList;
          averageMood = jsonResponse['averageMood'] != null
              ? double.parse(jsonResponse['averageMood'].toString())
              : 0.0;
          if (moods.isNotEmpty) {
            data = moods.map((e) => e.rating).toList();
            List<Color?> nullableColors =
                data.map((rating) => getMoodColor(rating)).toList();
            List<Color> nonNullableColors = nullableColors
                .where((color) => color != null)
                .toList()
                .cast<Color>();
            colors = nonNullableColors;
          }
          isLoading = false;
        });
      }
    });
  }

  Color? getMoodColor(double rating) {
    if (rating < 0.75) {
      return Colors.red; // Very Bad
    } else if (rating < 1.25) {
      return Colors.orange[800]; // Bad
    } else if (rating < 1.75) {
      return Colors.orange[400]; // Not Good
    } else if (rating < 2.25) {
      return Colors.yellow[700]; // Average
    } else if (rating < 2.75) {
      return Colors.yellow[500]; // Good
    } else if (rating < 3.25) {
      return Colors.lightGreen[500]; // Very Good
    } else if (rating < 3.75) {
      return Colors.lightGreen[800]; // Excellent
    } else if (rating < 4.25) {
      return Colors.green[500]; // Outstanding
    } else if (rating < 4.75) {
      return Colors.green[800]; // Fantastic
    } else {
      return Colors.green; // Perfect
    }
  }

  String getMood(double rating) {
    if (rating < 0.75) {
      return "Very Bad";
    } else if (rating < 1.25) {
      return "Bad";
    } else if (rating < 1.75) {
      return "Not Good";
    } else if (rating < 2.25) {
      return "Average";
    } else if (rating < 2.75) {
      return "Good";
    } else if (rating < 3.25) {
      return "Very Good";
    } else if (rating < 3.75) {
      return "Excellent";
    } else if (rating < 4.25) {
      return "Outstanding";
    } else if (rating < 4.75) {
      return "Fantastic";
    } else {
      return "Perfect";
    }
  }

  String getMoodEmoji(double rating) {
    if (rating < 0.75) {
      return "😭"; // Very Bad
    } else if (rating < 1.25) {
      return "😞"; // Bad
    } else if (rating < 1.75) {
      return "😐"; // Not Good
    } else if (rating < 2.25) {
      return "😕"; // Average
    } else if (rating < 2.75) {
      return "😊"; // Good
    } else if (rating < 3.25) {
      return "😀"; // Very Good
    } else if (rating < 3.75) {
      return "😁"; // Excellent
    } else if (rating < 4.25) {
      return "😃"; // Outstanding
    } else if (rating < 4.75) {
      return "😄"; // Fantastic
    } else {
      return "😍"; // Perfect
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: 15.0,
        ),
        child: SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 15),
              Text(
                "Empathia Dashboard",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
              ),
              SizedBox(height: 3),
              Text(
                "Welcome to Empathia, your personal health assistant.",
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.grey,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              if (user == null)
                Center(
                  child: CupertinoActivityIndicator(
                    color: TColors.primary,
                  ),
                ),
              if (user != null)
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Card(
                      elevation: 3,
                      child: Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: ListTile(
                          leading: Lottie.asset(
                            "assets/gif/dashboard.json",
                            // height: 60,
                          ),
                          title: Text(
                            "Welcome Back!",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          subtitle: Text(
                            "Let's begin your journey.",
                            style: TextStyle(
                              fontSize: 13,
                              color: Colors.grey,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Card(
                      elevation: 3,
                      child: Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [
                              const Color.fromARGB(255, 36, 65, 211),
                              Color.fromARGB(255, 43, 87, 200),
                            ],
                          ),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Padding(
                          padding: const EdgeInsets.all(12.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "Mood Tracker",
                                style: TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                  color: Colors.white,
                                ),
                              ),
                              SizedBox(height: 2),
                              Text(
                                "Track your moods for everyday.",
                                style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.white60,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              if (isLoading)
                                Center(
                                  child: CupertinoActivityIndicator(
                                    color: Colors.white,
                                  ),
                                ),
                              SizedBox(
                                height: 10,
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Center(
                                    child: GestureDetector(
                                      onTap: () {
                                        showDatePicker(
                                          context: context,
                                          initialDate: selectedDate,
                                          firstDate: DateTime(2024),
                                          lastDate: DateTime.now(),
                                        ).then((value) {
                                          if (value != null) {
                                            setState(() {
                                              selectedDate = value;
                                              getMoodRecords();
                                            });
                                          }
                                        });
                                      },
                                      child: Container(
                                        decoration: BoxDecoration(
                                          border: Border.all(
                                            color: Colors.white,
                                            width: 2,
                                          ),
                                          borderRadius:
                                              BorderRadius.circular(10),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Wrap(
                                            children: [
                                              Text(
                                                DateFormat.yMMMMEEEEd()
                                                    .format(selectedDate)
                                                    .toString(),
                                                style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.white,
                                                ),
                                              ),
                                              SizedBox(
                                                width: 10,
                                              ),
                                              Icon(
                                                Icons.edit,
                                                color: Colors.white,
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  if (!isLoading && data.isNotEmpty)
                                    Sparkline(
                                      data: data,
                                      lineWidth: 10.0,
                                      useCubicSmoothing: true,
                                      lineGradient: LinearGradient(
                                        begin: Alignment.topCenter,
                                        end: Alignment.bottomCenter,
                                        colors: colors,
                                      ),
                                    ),
                                  SizedBox(
                                    height: 20,
                                  ),
                                  if (isToday(selectedDate))
                                    Center(
                                      child: RatingBar.builder(
                                        initialRating: 3,
                                        itemCount: 5,
                                        unratedColor: Colors.white60,
                                        allowHalfRating: true,
                                        itemBuilder: (context, index) {
                                          switch (index) {
                                            case 0:
                                              return Icon(
                                                Icons
                                                    .sentiment_very_dissatisfied,
                                                color: Colors.red,
                                              );
                                            case 1:
                                              return Icon(
                                                Icons.sentiment_dissatisfied,
                                                color: Colors.redAccent,
                                              );
                                            case 2:
                                              return Icon(
                                                Icons.sentiment_neutral,
                                                color: Colors.amber,
                                              );
                                            case 3:
                                              return Icon(
                                                Icons.sentiment_satisfied,
                                                color: Colors.lightGreen,
                                              );
                                            case 4:
                                              return Icon(
                                                Icons.sentiment_very_satisfied,
                                                color: Colors.green,
                                              );
                                            default:
                                              return Container();
                                          }
                                        },
                                        onRatingUpdate: (rating) {
                                          setState(() {
                                            ratingMeter = rating;
                                          });
                                        },
                                      ),
                                    ),
                                  if (isToday(selectedDate))
                                    SizedBox(
                                      height: 20,
                                    ),
                                  if (isToday(selectedDate))
                                    Center(
                                      child: GestureDetector(
                                        onTap: () async {
                                          showDialog(
                                              context: context,
                                              builder: (context) {
                                                return AlertDialog(
                                                  title: Text("Add Mood"),
                                                  content: Text(
                                                    "Are you sure you want to add \"${getMood(ratingMeter)}\" rating to your mood?",
                                                  ),
                                                  actions: [
                                                    TextButton(
                                                      onPressed: () {
                                                        Navigator.pop(context);
                                                      },
                                                      child: Text("Cancel"),
                                                    ),
                                                    TextButton(
                                                      onPressed: () async {
                                                        final SharedPreferences
                                                            dp =
                                                            await SharedPreferences
                                                                .getInstance();
                                                        final String? userId =
                                                            dp.getString(
                                                                "userId");
                                                        print(
                                                            "SENDING FOR $userId");
                                                        Clipboard.setData(
                                                          ClipboardData(
                                                            text: userId!,
                                                          ),
                                                        );
                                                        http.post(
                                                            Uri.parse(
                                                              APIRoutes
                                                                  .setMoodRecord,
                                                            ),
                                                            body: {
                                                              "rating":
                                                                  ratingMeter
                                                                      .toString(),
                                                              "userId": userId,
                                                            }).then((response) {
                                                          print(
                                                            jsonDecode(
                                                              response.body,
                                                            ),
                                                          );
                                                          if (response
                                                                  .statusCode ==
                                                              200) {
                                                            getMoodRecords();
                                                            Navigator.pop(
                                                                context);
                                                          }
                                                        });
                                                      },
                                                      child: Text("Add"),
                                                    ),
                                                  ],
                                                );
                                              });
                                        },
                                        child: Card(
                                          elevation: 5,
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(100),
                                          ),
                                          child: Container(
                                            decoration: BoxDecoration(
                                              color: TColors.primary,
                                              borderRadius:
                                                  BorderRadius.circular(100),
                                            ),
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(15.0),
                                              child: Icon(
                                                Icons.add,
                                                color: Colors.white,
                                                size: 40,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  if (!isLoading && data.isNotEmpty)
                                    Card(
                                      elevation: 5,
                                      child: Container(
                                        decoration: BoxDecoration(
                                          color: TColors.accent,
                                          borderRadius: BorderRadius.circular(
                                            10,
                                          ),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: ListTile(
                                            title: Text("Average Mood"),
                                            subtitle: Text(
                                              getMood(averageMood),
                                              style: TextStyle(
                                                fontSize: 20,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            leading: Text(
                                              getMoodEmoji(
                                                averageMood,
                                              ),
                                              style: TextStyle(
                                                fontSize: 40,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                              if (!isLoading && data.isEmpty)
                                Center(
                                  child: Column(
                                    children: [
                                      Text(
                                        "No Mood Records Found",
                                        style: TextStyle(
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              SizedBox(
                height: 10,
              ),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            "Motivation Board",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Spacer(),
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                CupertinoPageRoute(
                                  builder: (_) => MyHopeboard(
                                    hopeboard: hopeboards,
                                  ),
                                ),
                              );
                            },
                            child: Row(
                              children: [
                                Icon(
                                  CupertinoIcons.bookmark,
                                  color: TColors.primary,
                                  size: 15,
                                ),
                                SizedBox(
                                  width: 5,
                                ),
                                Text(
                                  "View Hopeboard",
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: TColors.primary,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      if (motivations.isEmpty)
                        Center(
                          child: CupertinoActivityIndicator(
                            color: TColors.primary,
                          ),
                        ),
                      if (motivations.isNotEmpty)
                        CarouselSlider.builder(
                          itemCount: motivations.length,
                          itemBuilder: (BuildContext context, int itemIndex,
                                  int pageViewIndex) =>
                              Column(
                            children: [
                              CachedNetworkImage(
                                imageUrl: motivations[itemIndex].image,
                                placeholder: (context, url) => Center(
                                  child: LinearProgressIndicator(
                                    color: TColors.primary,
                                  ),
                                ),
                                errorWidget: (context, url, error) => Icon(
                                  Icons.error,
                                  color: Colors.red,
                                ),
                              ),
                              ListTile(
                                title: Text(
                                  motivations[itemIndex].caption,
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                trailing: GestureDetector(
                                  onTap: () async {
                                    print("Saving");
                                    if (isInHopeboard(
                                        motivations[itemIndex].id)) {
                                      Fluttertoast.showToast(
                                          msg: "Already saved to hopeboard.");
                                      return;
                                    }
                                    final SharedPreferences dp =
                                        await SharedPreferences.getInstance();
                                    final String? userId =
                                        dp.getString("userId");
                                    http.post(
                                      Uri.parse(
                                        APIRoutes.createHopeboard,
                                      ),
                                      body: {
                                        "message":
                                            "Created on ${DateTime.now()}",
                                        "motivation": motivations[itemIndex].id,
                                        "user": userId,
                                      },
                                    ).then((response) {
                                      print(response.body);
                                      if (response.statusCode == 200) {
                                        getHopeboards();
                                      }
                                    });
                                  },
                                  child: Icon(
                                    isInHopeboard(motivations[itemIndex].id)
                                        ? CupertinoIcons.bookmark_fill
                                        : CupertinoIcons.bookmark,
                                    color: TColors.primary,
                                  ),
                                ),
                              )
                            ],
                          ),
                          options: CarouselOptions(
                            autoPlay: false,
                            enlargeCenterPage: true,
                            viewportFraction: 0.9,
                            aspectRatio: 1.3,
                            initialPage: 0,
                            enableInfiniteScroll: false,
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                height: 80,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
