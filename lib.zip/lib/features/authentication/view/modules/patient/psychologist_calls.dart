import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_datetime_picker_plus/flutter_datetime_picker_plus.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:store/features/authentication/model/appointment.model.dart';
import 'package:store/features/authentication/view/modules/patient/recharge_now.dart';
import 'package:store/main.dart';
import 'package:store/utils/api_routes.dart';
import 'package:zego_uikit_prebuilt_call/zego_uikit_prebuilt_call.dart';

class PsycologistCall extends StatefulWidget {
  const PsycologistCall({super.key});

  @override
  State<PsycologistCall> createState() => _PsycologistCallState();
}

class _PsycologistCallState extends State<PsycologistCall> {
  int? amountInWallet;
  String userID = "";
  TextEditingController amountController = TextEditingController();

  List<Map<String, dynamic>> cycos = [];

  DateTime selectedDateTime = DateTime.now();

  List<Appointment> appointments = [];

  @override
  void initState() {
    super.initState();
    getWallet();
    getCycos();
    loadAllRequests();
  }

  loadAllRequests() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var userId = prefs.getString('userId');
    setState(() {
      userID = userId!;
    });
    print(userId);
    await http.post(
      Uri.parse(
        APIRoutes.viewRequests,
      ),
      body: {
        "id": userId,
        "userType": "user",
      },
    ).then((val) {
      print(val.body);
      var jsonData = json.decode(val.body);
      setState(() {
        appointments = List<Appointment>.from(
          jsonData['appointments'].map(
            (x) => Appointment.fromJson(x),
          ),
        );
      });
    });
  }

  decideColor(String status) {
    if (status == "pending") {
      return Colors.orange;
    } else if (status == "approved") {
      return Colors.green;
    } else if (status == "denied") {
      return Colors.red;
    } else if (status == "completed") {
      return Colors.blueGrey;
    } else {
      return Colors.grey;
    }
  }

  void getCycos() async {
    await http
        .get(
      Uri.parse(
        APIRoutes.getOnlineCycos,
      ),
    )
        .then((val) {
      print(val.body);
      var jsonData = json.decode(val.body);
      setState(() {
        cycos = List<Map<String, dynamic>>.from(jsonData['onlineCycos']);
      });
    });
  }

  getWallet() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    var userId = prefs.getString('userId');
    setState(() {
      userID = userId!;
    });
    await http.post(
      Uri.parse(
        APIRoutes.getAmountInWallet,
      ),
      body: {
        "id": userId,
      },
    ).then((val) {
      var jsonData = json.decode(val.body);
      setState(() {
        amountInWallet = int.parse(jsonData['walletAmount'].toString());
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 25.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  height: 20,
                ),
                Text(
                  "Talk to Psychologists",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(
                  height: 5,
                ),
                const Text(
                  "Get help from our professional psychologists.",
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                // Balance and Recharge UI
                Card(
                  elevation: 5,
                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.blue,
                          Colors.blueAccent,
                        ],
                      ),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Center(
                                child: Text(
                                  "Rs. ${amountInWallet == null ? "..." : amountInWallet.toString().replaceAllMapped(
                                        reg,
                                        mathFunc,
                                      )}",
                                  style: TextStyle(
                                    fontSize: 30,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        GestureDetector(
                          onTap: () {
                            showDialog(
                              context: context,
                              builder: (context) {
                                return AlertDialog(
                                  title: Text("Recharge Wallet"),
                                  content: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      TextField(
                                        controller: amountController,
                                        decoration: InputDecoration(
                                          labelText: "Amount",
                                          hintText: "Enter amount to recharge",
                                        ),
                                      ),
                                      SizedBox(
                                        height: 10,
                                      ),
                                      ElevatedButton(
                                        onPressed: () async {
                                          Navigator.pop(context);
                                          Navigator.push(
                                            context,
                                            MaterialPageRoute(
                                              builder: (context) => PayNow(
                                                amount: amountController.text,
                                                userID: userID,
                                              ),
                                            ),
                                          );
                                        },
                                        child: Center(
                                          child: Text(
                                            "Recharge",
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                );
                              },
                            );
                          },
                          child: Container(
                            width: double.infinity,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.green,
                                  Colors.lightGreen,
                                ],
                              ),
                              borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(10),
                                bottomRight: Radius.circular(10),
                              ),
                            ),
                            child: Center(
                              child: Padding(
                                padding: const EdgeInsets.all(12.0),
                                child: Text(
                                  "+ Recharge Wallet",
                                  style: TextStyle(
                                    fontSize: 16,
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(
                  height: 15,
                ),
                TabBar(
                  tabs: [
                    Tab(
                      text: "Psychologists",
                      icon: Icon(
                        Icons.people,
                      ),
                    ),
                    Tab(
                      text: "Requests",
                      icon: Icon(
                        Icons.calendar_today,
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 15,
                ),
                Expanded(
                  child: TabBarView(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Online Psychologists",
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          const Text(
                            "Book your appointment now.",
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Expanded(
                            child: ListView.builder(
                              itemCount: cycos.length,
                              itemBuilder: (context, index) {
                                return Padding(
                                  padding: const EdgeInsets.only(bottom: 10.0),
                                  child: GestureDetector(
                                    onTap: () {
                                      DatePicker.showDateTimePicker(
                                        context,
                                        showTitleActions: true,
                                        minTime: DateTime.now(),
                                        maxTime: DateTime.now()
                                            .add(Duration(days: 7)),
                                        onChanged: (date) {
                                          print('change $date');
                                        },
                                        onConfirm: (date) {
                                          String formattedDate =
                                              DateFormat.yMMMMEEEEd()
                                                      .format(date) +
                                                  " at " +
                                                  DateFormat.jm().format(date);

                                          showDialog(
                                            context: context,
                                            builder: (context) {
                                              return AlertDialog(
                                                title: Text(
                                                    "Appointment Confirmation"),
                                                content: Column(
                                                  mainAxisSize:
                                                      MainAxisSize.min,
                                                  children: [
                                                    Text(
                                                      "Are you sure you want to book an appointment with ${cycos[index]['name']} on $formattedDate?",
                                                    ),
                                                    SizedBox(
                                                      height: 10,
                                                    ),
                                                    ElevatedButton(
                                                      onPressed: () async {
                                                        Navigator.pop(context);
                                                        await http.post(
                                                          Uri.parse(
                                                            APIRoutes
                                                                .requestAppointment,
                                                          ),
                                                          body: {
                                                            "userId": userID,
                                                            "psychologistId":
                                                                cycos[index]
                                                                    ['_id'],
                                                            "appointmentTime":
                                                                formattedDate
                                                                    .toString(),
                                                          },
                                                        ).then((val) {
                                                          print(val.body);
                                                          var jsonData = json
                                                              .decode(val.body);
                                                          if (val.statusCode ==
                                                              200) {
                                                            loadAllRequests();
                                                            ScaffoldMessenger
                                                                    .of(context)
                                                                .showSnackBar(
                                                              SnackBar(
                                                                content: Text(
                                                                  "Appointment booked successfully.",
                                                                ),
                                                              ),
                                                            );
                                                          } else {
                                                            ScaffoldMessenger
                                                                    .of(context)
                                                                .showSnackBar(
                                                              SnackBar(
                                                                content: Text(
                                                                  "Failed to book appointment.",
                                                                ),
                                                              ),
                                                            );
                                                          }
                                                        });
                                                      },
                                                      child: Center(
                                                        child: Text(
                                                          "Confirm",
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              );
                                            },
                                          );
                                        },
                                        currentTime: DateTime.now(),
                                        locale: LocaleType.en,
                                      );
                                    },
                                    child: Card(
                                      elevation: 3,
                                      child: ListTile(
                                        title: Text(
                                          cycos[index]['name'],
                                          style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        // trailing: ZegoSendCallInvitationButton(
                                        //   buttonSize: Size(
                                        //     50,
                                        //     50,
                                        //   ),
                                        //   iconSize: Size(50, 50),
                                        //   isVideoCall: true,
                                        //   resourceID: "zegouikit_call",
                                        //   callID: userID,
                                        //   invitees: [
                                        //     ZegoUIKitUser(
                                        //       id: cycos[index]['email'],
                                        //       name: cycos[index]['name'],
                                        //     ),
                                        //   ],
                                        // ),
                                        trailing: Card(
                                          color: Colors.blue,
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(100),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 15.0,
                                              vertical: 10,
                                            ),
                                            child: Text(
                                              "Book Now",
                                              style: TextStyle(
                                                fontSize: 12,
                                                color: Colors.white,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                        ),
                                        subtitle: Text(
                                          cycos[index]['email'],
                                          style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.grey,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Your Requests",
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(
                            height: 5,
                          ),
                          const Text(
                            "View your appointment requests.",
                            style: TextStyle(
                              fontSize: 16,
                              color: Colors.grey,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          const SizedBox(
                            height: 20,
                          ),
                          Expanded(
                            child: ListView.builder(
                              itemCount: appointments.length,
                              itemBuilder: (context, index) {
                                return Card(
                                  elevation: 3,
                                  child: ListTile(
                                    title: Row(
                                      children: [
                                        Text(
                                          appointments[index].psychologistName,
                                          style: TextStyle(
                                            fontSize: 18,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                        Card(
                                          color: decideColor(
                                            appointments[index].status,
                                          ),
                                          shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(100),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 10.0,
                                              vertical: 5,
                                            ),
                                            child: Text(
                                              appointments[index]
                                                  .status
                                                  .toUpperCase(),
                                              style: TextStyle(
                                                fontSize: 10,
                                                color: Colors.white,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    trailing: (appointments[index].status ==
                                                "pending" ||
                                            appointments[index] == "approved")
                                        ? GestureDetector(
                                            onTap: () {
                                              showDialog(
                                                context: context,
                                                builder: (context) {
                                                  return AlertDialog(
                                                    title: Text(
                                                        "Appointment Cancellation"),
                                                    content: Column(
                                                      mainAxisSize:
                                                          MainAxisSize.min,
                                                      children: [
                                                        Text(
                                                          "Are you sure you want to cancel the appointment with ${appointments[index].psychologistName} on ${appointments[index].appointmentTime}?",
                                                        ),
                                                        SizedBox(
                                                          height: 10,
                                                        ),
                                                        ElevatedButton(
                                                          onPressed: () async {
                                                            Navigator.pop(
                                                                context);
                                                            await http.delete(
                                                              Uri.parse(
                                                                APIRoutes
                                                                    .cancelAppointment,
                                                              ),
                                                              body: {
                                                                "id": appointments[
                                                                        index]
                                                                    .id,
                                                              },
                                                            ).then((val) {
                                                              print(val.body);
                                                              var jsonData =
                                                                  json.decode(
                                                                      val.body);
                                                              if (val.statusCode ==
                                                                  200) {
                                                                loadAllRequests();
                                                                ScaffoldMessenger.of(
                                                                        context)
                                                                    .showSnackBar(
                                                                  SnackBar(
                                                                    content:
                                                                        Text(
                                                                      "Appointment cancelled successfully.",
                                                                    ),
                                                                  ),
                                                                );
                                                              } else {
                                                                ScaffoldMessenger.of(
                                                                        context)
                                                                    .showSnackBar(
                                                                  SnackBar(
                                                                    content:
                                                                        Text(
                                                                      "Failed to cancel appointment.",
                                                                    ),
                                                                  ),
                                                                );
                                                              }
                                                            });
                                                          },
                                                          child: Center(
                                                            child: Text(
                                                              "Confirm",
                                                            ),
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  );
                                                },
                                              );
                                            },
                                            child: Text(
                                              "Cancel",
                                              style: TextStyle(
                                                fontSize: 14,
                                                color: Colors.red,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          )
                                        : null,
                                    subtitle: Text(
                                      appointments[index].appointmentTime,
                                      style: TextStyle(
                                        fontSize: 14,
                                        color: Colors.grey,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                );
                              },
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
