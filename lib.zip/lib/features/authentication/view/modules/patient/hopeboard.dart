import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:store/features/authentication/model/hopeboard.model.dart';
import 'package:store/utils/api_routes.dart';
import 'package:store/utils/constants/colors.dart';

class MyHopeboard extends StatefulWidget {
  List<Hopeboard> hopeboard;

  MyHopeboard({required this.hopeboard});

  @override
  State<MyHopeboard> createState() => _MyHopeboardState();
}

class _MyHopeboardState extends State<MyHopeboard> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'My Hopeboard',
          style: TextStyle(
            color: TColors.white,
          ),
        ),
        iconTheme: IconThemeData(
          color: TColors.white,
        ),
        backgroundColor: TColors.primary,
      ),
      body: widget.hopeboard.isEmpty
          ? Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Center(
                  child: Text(
                    'No hopeboard posts yet',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            )
          : ListView.builder(
              itemCount: widget.hopeboard.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20.0, vertical: 5),
                  child: Card(
                    child: Column(
                      children: [
                        CachedNetworkImage(
                          imageUrl: widget.hopeboard[index].motivationImage,
                          placeholder: (context, url) => Center(
                            child: LinearProgressIndicator(
                              color: TColors.primary,
                            ),
                          ),
                          errorWidget: (context, url, error) => Icon(
                            Icons.error,
                            color: Colors.red,
                          ),
                        ),
                        ListTile(
                          title: Text(
                            widget.hopeboard[index].motivationCaption,
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          trailing: GestureDetector(
                            onTap: () async {
                              http.delete(
                                Uri.parse(
                                  APIRoutes.deleteHopeboard,
                                ),
                                body: {
                                  'id': widget.hopeboard[index].id.toString(),
                                },
                              ).then((res) {
                                if (res.statusCode == 200) {
                                  setState(() {
                                    widget.hopeboard.removeAt(index);
                                  });
                                  Fluttertoast.showToast(
                                      msg: "Post was removed from hopeboard");
                                }
                              });
                            },
                            child: Icon(
                              CupertinoIcons.bookmark_fill,
                              color: TColors.primary,
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
