import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_quill/flutter_quill.dart';
import 'package:store/features/authentication/model/article.model.dart';
import 'package:timeago/timeago.dart' as timeago;

class ArticleDetailsScreen extends StatefulWidget {
  Article article;
  String categoryName;
  String subcategoryName;

  ArticleDetailsScreen({
    required this.article,
    required this.categoryName,
    required this.subcategoryName,
  });

  @override
  State<ArticleDetailsScreen> createState() => _ArticleDetailsScreenState();
}

class _ArticleDetailsScreenState extends State<ArticleDetailsScreen> {
  QuillController _controller = QuillController.basic();
  String timeAgo = "";

  @override
  void initState() {
    super.initState();
    _controller = QuillController(
      document: Document.fromJson(jsonDecode(widget.article.message)),
      selection: TextSelection.collapsed(offset: 0),
    );
    DateTime createdAt = DateTime.parse(
      widget.article.createdAt,
    );
    timeago.setLocaleMessages('en_short', timeago.EnShortMessages());
    timeAgo = timeago.format(createdAt, locale: 'en_short');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 25.0),
          child: SafeArea(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      icon: Icon(Icons.arrow_back_ios),
                    ),
                    Text(
                      'Article',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(width: 30),
                  ],
                ),
                SizedBox(height: 10),
                SizedBox(
                  width: MediaQuery.of(context).size.width,
                  height: 200,
                  child: Card(
                    elevation: 5,
                    child: Hero(
                      tag: widget.article.id,
                      key: ValueKey(widget.article.id),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: CachedNetworkImage(
                          imageUrl: widget.article.image,
                          fit: BoxFit.cover,
                          placeholder: (context, url) =>
                              LinearProgressIndicator(),
                          errorWidget: (context, url, error) =>
                              Icon(Icons.error),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                Text(
                  widget.article.title,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 8.0,
                  ),
                  child: Text(
                    "Posted $timeAgo ago in ${widget.categoryName} > ${widget.subcategoryName}.",
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey,
                    ),
                  ),
                ),
                SizedBox(height: 25),
                IgnorePointer(
                  child: QuillEditor.basic(
                    configurations: QuillEditorConfigurations(
                      controller: _controller,
                      sharedConfigurations: const QuillSharedConfigurations(
                        locale: Locale('en'),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
