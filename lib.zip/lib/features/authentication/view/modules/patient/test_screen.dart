import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:store/features/authentication/view/modules/patient/test_result_screen.dart';
import 'package:store/utils/api_routes.dart';
import 'package:store/utils/constants/colors.dart';

class TestScreen extends StatefulWidget {
  String name;
  String userID;

  TestScreen({
    required this.name,
    required this.userID,
  });

  @override
  State<TestScreen> createState() => _TestScreenState();
}

class _TestScreenState extends State<TestScreen> {
  List<String> questions = [];
  List<String> answers = [];
  List<int> answerRatings = [];

  PageController controller = PageController();

  String currentAnswer = "";

  List<TestOption> options = [];
  List<TestOption> stressOptions = [
    TestOption(
      option: "Never",
      icon: Icons.sentiment_dissatisfied,
      rating: 4,
    ),
    TestOption(
      option: "Sometimes",
      icon: Icons.sentiment_neutral,
      rating: 3,
    ),
    TestOption(
      option: "Often",
      icon: Icons.sentiment_satisfied,
      rating: 2,
    ),
    TestOption(
      option: "Always",
      icon: Icons.sentiment_very_satisfied,
      rating: 1,
    ),
  ];
  List<TestOption> sleepOptions = [
    TestOption(
      option: "Rarely",
      icon: Icons.sentiment_dissatisfied,
      rating: 4,
    ),
    TestOption(
      option: "Sometimes",
      icon: Icons.sentiment_neutral,
      rating: 3,
    ),
    TestOption(
      option: "Often",
      icon: Icons.sentiment_satisfied,
      rating: 2,
    ),
    TestOption(
      option: "Almost Always",
      icon: Icons.sentiment_very_satisfied,
      rating: 1,
    ),
  ];
  List<TestOption> despressionOptions = [
    TestOption(
      option: "Not at all",
      icon: Icons.sentiment_dissatisfied,
      rating: 4,
    ),
    TestOption(
      option: "Several Days",
      icon: Icons.sentiment_neutral,
      rating: 3,
    ),
    TestOption(
      option: "More than half the days",
      icon: Icons.sentiment_satisfied,
      rating: 2,
    ),
    TestOption(
      option: "Nearly every day",
      icon: Icons.sentiment_very_satisfied,
      rating: 1,
    ),
  ];
  List<TestOption> anxietyOptions = [
    TestOption(
      option: "Mild",
      icon: Icons.sentiment_dissatisfied,
      rating: 4,
    ),
    TestOption(
      option: "Moderate",
      icon: Icons.sentiment_neutral,
      rating: 3,
    ),
    TestOption(
      option: "Severe",
      icon: Icons.sentiment_satisfied,
      rating: 2,
    ),
    TestOption(
      option: "Very Severe",
      icon: Icons.sentiment_very_satisfied,
      rating: 1,
    ),
  ];

  @override
  void initState() {
    super.initState();
    getTestQuestions();
  }

  getTestQuestions() {
    if (widget.name == "stress") {
      setState(() {
        options = stressOptions;
      });
    }
    if (widget.name == "sleep") {
      setState(() {
        options = sleepOptions;
      });
    }
    if (widget.name == "anxiety") {
      setState(() {
        options = anxietyOptions;
      });
    }
    if (widget.name == "despression") {
      setState(() {
        options = despressionOptions;
      });
    }

    http.post(Uri.parse(APIRoutes.getTest), body: {"name": widget.name}).then(
      (response) {
        if (response.statusCode == 200) {
          var jsonData = jsonDecode(response.body);
          questions = jsonData["data"]["questions"].cast<String>();
          setState(() {});
          print(questions.first);
        }
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: questions.isNotEmpty
              ? LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Colors.white,
                    Colors.white,
                  ],
                )
              : LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    const Color.fromARGB(255, 36, 65, 211),
                    Color.fromARGB(255, 56, 94, 192),
                  ],
                ),
        ),
        child: questions.isEmpty
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Center(
                    child: Text(
                      "Preparing your test...",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  const CupertinoActivityIndicator(
                    color: Colors.white,
                  ),
                ],
              )
            : SafeArea(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        height: 20,
                      ),
                      IconButton(
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (context) {
                              return AlertDialog(
                                title: Text("Are you sure?"),
                                content: Text(
                                    "You will lose all your progress if you go close your test."),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      Navigator.pop(context);
                                    },
                                    child: Text("Cancel"),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      Navigator.pop(context);
                                      Navigator.pop(context);
                                    },
                                    child: Text("Yes"),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                        icon: Icon(
                          Icons.close,
                        ),
                      ),
                      SizedBox(
                        height: 20,
                      ),
                      Expanded(
                        child: PageView.builder(
                          controller: controller,
                          itemCount: questions.length,
                          physics: NeverScrollableScrollPhysics(),
                          itemBuilder: (context, index) {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  questions[index],
                                  style: GoogleFonts.montserrat(
                                    fontSize: 25,
                                    color: Colors.black,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                                Text(
                                  "Question ${index + 1} of ${questions.length}",
                                  style: GoogleFonts.montserrat(
                                    fontSize: 16,
                                    color: Colors.black54,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                const SizedBox(
                                  height: 20,
                                ),
                                Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  children: options
                                      .map(
                                        (option) => GestureDetector(
                                          onTap: () {
                                            setState(() {
                                              currentAnswer = option.option;
                                              answers.add(option.option
                                                  .replaceAll(" ", "")
                                                  .replaceAll("⭐", ""));
                                              answerRatings.add(option.rating);

                                              Future.delayed(
                                                  Duration(milliseconds: 300),
                                                  () {
                                                currentAnswer = "";
                                                if (index <
                                                    questions.length - 1) {
                                                  controller.nextPage(
                                                    duration: Duration(
                                                      milliseconds: 300,
                                                    ),
                                                    curve: Curves.easeIn,
                                                  );
                                                } else {
                                                  Map<String, dynamic> body =
                                                      {};
                                                  body["user"] = widget.userID;
                                                  body['answers'] = answers;
                                                  body['questions'] = questions;
                                                  body['name'] = widget.name;

                                                  http
                                                      .post(
                                                    Uri.parse(
                                                        APIRoutes.submitTest),
                                                    headers: {
                                                      "Content-Type":
                                                          "application/json"
                                                    },
                                                    body: jsonEncode(body),
                                                  )
                                                      .then((res) {
                                                    print(questions.length);
                                                    print(answers.length);
                                                    print(res.body);
                                                    if (res.statusCode == 201) {
                                                      Fluttertoast.showToast(
                                                        msg:
                                                            "Test submitted successfully!",
                                                        backgroundColor:
                                                            Colors.green,
                                                        textColor: Colors.white,
                                                      );
                                                      int avgRatingOfAnswers =
                                                          answerRatings.reduce(
                                                                  (a, b) =>
                                                                      a + b) ~/
                                                              answerRatings
                                                                  .length;

                                                      Navigator.pop(context);
                                                      Navigator.push(
                                                        context,
                                                        CupertinoPageRoute(
                                                          builder: (_) =>
                                                              TestResultScreen(
                                                            rating:
                                                                avgRatingOfAnswers,
                                                            module: widget.name,
                                                          ),
                                                        ),
                                                      );
                                                    } else {
                                                      Fluttertoast.showToast(
                                                        msg:
                                                            "An error occurred, your test couldn't be submitted. Please try again later.",
                                                        backgroundColor:
                                                            Colors.red,
                                                        textColor: Colors.white,
                                                      );
                                                      Navigator.pop(context);
                                                    }
                                                  });
                                                }
                                              });
                                            });
                                          },
                                          child: Padding(
                                            padding: const EdgeInsets.only(
                                                bottom: 10.0),
                                            child: Card(
                                              elevation:
                                                  currentAnswer == option.option
                                                      ? 3
                                                      : 0,
                                              child: Container(
                                                  decoration: BoxDecoration(
                                                    color: currentAnswer ==
                                                            option.option
                                                        ? Colors.blue
                                                        : Colors.white,
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            10),
                                                    border: Border.all(
                                                      color: currentAnswer ==
                                                              option.option
                                                          ? Colors.blue
                                                          : Colors.black,
                                                    ),
                                                  ),
                                                  child: ListTile(
                                                    leading: Icon(
                                                      option.icon,
                                                      color: currentAnswer ==
                                                              option.option
                                                          ? Colors.white
                                                          : Colors.black,
                                                    ),
                                                    title: Text(
                                                      option.option,
                                                      style: TextStyle(
                                                        color: currentAnswer ==
                                                                option.option
                                                            ? Colors.white
                                                            : Colors.black,
                                                      ),
                                                    ),
                                                  )),
                                            ),
                                          ),
                                        ),
                                      )
                                      .toList(),
                                ),
                              ],
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}

class TestOption {
  String option;
  IconData icon;
  int rating;

  TestOption({required this.option, required this.icon, required this.rating});
}
