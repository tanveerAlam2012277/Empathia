import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:store/features/authentication/view/modules/patient/article_details_screen.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:store/features/authentication/model/generic.model.dart';
import 'package:store/features/authentication/model/subcategory.model.dart';
import 'package:store/utils/api_routes.dart';
import 'package:store/utils/constants/colors.dart';

class ArticleScreen extends StatefulWidget {
  const ArticleScreen({super.key});

  @override
  State<ArticleScreen> createState() => _ArticleScreenState();
}

class _ArticleScreenState extends State<ArticleScreen> {
  List<Generic> categories = [];
  List<Subcategory> subcategories = [];

  String selectedCategory = "";

  @override
  void initState() {
    super.initState();
    getCategories();
  }

  getCategories() {
    http
        .get(
      Uri.parse(
        APIRoutes.getCategories,
      ),
    )
        .then((response) {
      var jsonData = jsonDecode(response.body)['categories'];
      List<Generic> cats = [];
      for (var item in jsonData) {
        cats.add(Generic.fromJson(item));
      }
      setState(() {
        categories = cats;
        selectedCategory = categories[0].name;
        getSubcategoriesAndArticlesByID(categories[0].id);
      });
    });
  }

  getSubcategoriesAndArticlesByID(String catID) {
    http
        .get(
      Uri.parse(
        APIRoutes.getArticlesByCat + "$catID",
      ),
    )
        .then((response) {
      var jsonData = jsonDecode(response.body)['subcategories'];
      print(jsonData);
      List<Subcategory> subs = [];
      for (var item in jsonData) {
        subs.add(Subcategory.fromJson(item));
      }
      setState(() {
        subcategories = subs;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 15),
              Text(
                "Articles",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w900,
                ),
              ),
              SizedBox(height: 3),
              Text(
                "Read articles on mental health and wellness.",
                style: TextStyle(
                  fontSize: 14,
                  color: Colors.grey,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              if (categories != [])
                SizedBox(
                  height: 30,
                  child: ListView.builder(
                    shrinkWrap: true,
                    scrollDirection: Axis.horizontal,
                    itemCount: categories.length,
                    itemBuilder: (context, index) {
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            selectedCategory = categories[index].name;
                            setState(() {
                              subcategories = [];
                            });
                            getSubcategoriesAndArticlesByID(
                                categories[index].id);
                          });
                        },
                        child: Container(
                          height: 20,
                          margin: EdgeInsets.only(right: 10),
                          padding: EdgeInsets.symmetric(
                            horizontal: 10,
                            vertical: 5,
                          ),
                          decoration: BoxDecoration(
                            color: categories[index].name == selectedCategory
                                ? Colors.blue
                                : Colors.grey[200],
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              if (selectedCategory == categories[index].name)
                                BoxShadow(
                                  color: Colors.grey[200]!,
                                  blurRadius: 10,
                                  spreadRadius: 1,
                                ),
                            ],
                          ),
                          child: Text(
                            categories[index].name,
                            style: TextStyle(
                              color: categories[index].name == selectedCategory
                                  ? Colors.white
                                  : Colors.black,
                              fontWeight:
                                  categories[index].name == selectedCategory
                                      ? FontWeight.bold
                                      : null,
                              fontSize:
                                  categories[index].name == selectedCategory
                                      ? 16
                                      : 14,
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              SizedBox(
                height: 10,
              ),
              if (subcategories.length > 0)
                Expanded(
                  child: ListView.builder(
                    itemBuilder: (context, index) {
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              vertical: 10.0,
                            ),
                            child: Text(
                              subcategories[index].name,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 180,
                            child: ListView.builder(
                              shrinkWrap: true,
                              scrollDirection: Axis.horizontal,
                              itemBuilder: (context, i) {
                                DateTime createdAt = DateTime.parse(
                                  subcategories[index].articles[i].createdAt,
                                );
                                timeago.setLocaleMessages(
                                    'en_short', timeago.EnShortMessages());
                                String timeAgo = timeago.format(createdAt,
                                    locale: 'en_short');

                                return GestureDetector(
                                  onTap: () {
                                    Navigator.push(
                                      context,
                                      CupertinoPageRoute(
                                        builder: (context) =>
                                            ArticleDetailsScreen(
                                          article:
                                              subcategories[index].articles[i],
                                          categoryName: selectedCategory,
                                          subcategoryName:
                                              subcategories[index].name,
                                        ),
                                      ),
                                    );
                                  },
                                  child: Card(
                                    elevation: 5,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        color: Colors.white,
                                      ),
                                      width: 200,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          SizedBox(
                                            height: 100,
                                            width: 200,
                                            child: Hero(
                                              tag: subcategories[index]
                                                  .articles[i]
                                                  .id,
                                              key: ValueKey(subcategories[index]
                                                  .articles[i]
                                                  .id),
                                              child: ClipRRect(
                                                borderRadius: BorderRadius.only(
                                                  topLeft: Radius.circular(10),
                                                  topRight: Radius.circular(10),
                                                ),
                                                child: CachedNetworkImage(
                                                  imageUrl: subcategories[index]
                                                      .articles[i]
                                                      .image,
                                                  fit: BoxFit.cover,
                                                  placeholder: (context, url) =>
                                                      LinearProgressIndicator(),
                                                  errorWidget:
                                                      (context, url, error) =>
                                                          Icon(Icons.error),
                                                ),
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 10,
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 8.0,
                                            ),
                                            child: Text(
                                              subcategories[index]
                                                  .articles[i]
                                                  .title,
                                              maxLines: 2,
                                              overflow: TextOverflow.ellipsis,
                                              style: TextStyle(
                                                fontSize: 12.5,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                          ),
                                          SizedBox(
                                            height: 5,
                                          ),
                                          Padding(
                                            padding: const EdgeInsets.symmetric(
                                              horizontal: 8.0,
                                            ),
                                            child: Text(
                                              "Posted $timeAgo ago",
                                              style: TextStyle(
                                                  fontSize: 10,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.grey),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                );
                              },
                              itemCount: subcategories[index].articles.length,
                            ),
                          ),
                        ],
                      );
                    },
                    itemCount: subcategories.length,
                  ),
                ),
              SizedBox(
                height: 40,
              ),
              if (categories.length < 1)
                Center(
                  child: CircularProgressIndicator(
                    color: TColors.primary,
                  ),
                ),
              if (subcategories.length < 1 && categories.length > 0)
                Center(
                  child: CircularProgressIndicator(
                    color: TColors.primary,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
