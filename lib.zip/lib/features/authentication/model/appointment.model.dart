import 'package:store/features/authentication/model/user_model.dart';

class Appointment {
  String id;
  String userID;
  String userEmail;
  String psychologistID;
  String psychologistName;
  String psychologistEmail;
  String appointmentTime;
  String psychologistRemarks;
  String status;

  Appointment({
    required this.id,
    required this.userID,
    required this.userEmail,
    required this.psychologistID,
    required this.psychologistName,
    required this.psychologistEmail,
    required this.appointmentTime,
    required this.psychologistRemarks,
    required this.status,
  });

  factory Appointment.fromJson(Map<String, dynamic> json) {
    return Appointment(
      id: json['_id'],
      userID: json['user']['_id'],
      userEmail: json['user']['email'],
      psychologistID: json['psychologist']['_id'],
      psychologistName: json['psychologist']['name'],
      psychologistEmail: json['psychologist']['email'],
      appointmentTime: json['appointmentTime'],
      psychologistRemarks: json['psychologistRemarks'],
      status: json['status'],
    );
  }
}
