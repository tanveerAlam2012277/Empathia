class Music {
  String id;
  String title;
  String image;
  String url;
  String genreID;

  Music({
    required this.id,
    required this.title,
    required this.image,
    required this.url,
    required this.genreID,
  });

  factory Music.fromJson(Map<String, dynamic> json) {
    return Music(
      id: json['_id'],
      title: json['title'],
      image: json['image'],
      url: json['url'],
      genreID: json['genre'],
    );
  }
}
