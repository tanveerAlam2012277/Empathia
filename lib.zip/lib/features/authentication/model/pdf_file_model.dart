import 'dart:io';

class PdfFile {
  final File file;
  final String filePath;

  PdfFile({required this.file, required this.filePath});
}