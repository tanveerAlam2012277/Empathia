class Article {
  final String id;
  final String title;
  final String image;
  final String message;
  final String categoryID;
  final String subcategoryID;
  final String createdAt;

  Article({
    required this.id,
    required this.title,
    required this.image,
    required this.message,
    required this.categoryID,
    required this.subcategoryID,
    required this.createdAt,
  });

  factory Article.fromJson(Map<String, dynamic> json) {
    return Article(
      id: json['_id'].toString(),
      title: json['title'].toString(),
      image: json['image'] ??
          "https://contenthub-static.grammarly.com/blog/wp-content/uploads/2022/08/BMD-3398.png",
      message: json['message'].toString(),
      categoryID: json['category'].toString(),
      subcategoryID: json['subcategory'].toString(),
      createdAt: json['createdAt'].toString(),
    );
  }
}
