class Hopeboard {
  final String id;
  final String message;
  final String motivationID;
  final String motivationImage;
  final String motivationCaption;
  final String userID;

  Hopeboard({
    required this.id,
    required this.message,
    required this.motivationID,
    required this.motivationImage,
    required this.motivationCaption,
    required this.userID,
  });

  factory Hopeboard.fromJson(Map<String, dynamic> json) {
    return Hopeboard(
      id: json['_id'] ?? '',
      message: json['message'] ?? '',
      motivationID: json['motivation']['_id'] ?? '',
      motivationImage: json['motivation']['image'] ?? '',
      motivationCaption: json['motivation']['caption'] ?? '',
      userID: json['user'] ?? '',
    );
  }
}
