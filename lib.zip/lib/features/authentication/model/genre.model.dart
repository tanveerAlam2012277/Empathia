import 'package:store/features/authentication/model/music.model.dart';

class Genre {
  String id;
  String name;
  List<Music> musics;

  Genre({
    required this.id,
    required this.name,
    required this.musics,
  });

  factory Genre.fromJson(Map<String, dynamic> json) {
    return Genre(
      id: json['_id'],
      name: json['name'],
      musics: json['musics']
          .map<Music>((music) => Music.fromJson(music))
          .toList()
          .cast<Music>(),
    );
  }
}
