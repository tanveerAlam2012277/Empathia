class UserModel {
  bool? success;
  String? message;
  User? user;

  UserModel({this.success, this.message, this.user});

  UserModel.fromJson(Map<String, dynamic> json) {
    success = json['success'];
    message = json['message'];
    user = json['user'] != null ? User.fromJson(json['user']) : null;
  }
}

class User {
  String? sId;
  String? email;
  String? token;
  String? gender;
  String? age;

  User({this.sId, this.email, this.token, this.gender, this.age});

  User.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    email = json['email'];
    token = json['token'];
    gender = json['gender'];
    age = json['age'];
  }
}

class EmpUser {
  String id;
  String email;
  String gender;
  String age;
  String communityName;
  String selectModeules;

  EmpUser({
    required this.id,
    required this.email,
    required this.gender,
    required this.age,
    required this.communityName,
    required this.selectModeules,
  });

  factory EmpUser.fromJson(Map<String, dynamic> json) {
    return EmpUser(
      id: json['_id'],
      email: json['email'],
      gender: json['gender'],
      age: json['age'],
      communityName: json['communityName'],
      selectModeules: json['selectModeules'],
    );
  }
}
