import 'package:store/features/authentication/model/article.model.dart';

class Subcategory {
  String id;
  String name;
  String categoryID;
  List<Article> articles;

  Subcategory({
    required this.id,
    required this.name,
    required this.categoryID,
    required this.articles,
  });

  factory Subcategory.fromJson(Map<String, dynamic> json) {
    return Subcategory(
      id: json['_id'].toString(),
      name: json['name'].toString(),
      categoryID: json['category'].toString(),
      articles: json['articles']
          .map<Article>((article) => Article.fromJson(article))
          .toList(),
    );
  }
}
