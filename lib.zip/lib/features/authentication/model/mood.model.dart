class Mood {
  String id;
  double rating;
  String createdAt;

  Mood({
    required this.id,
    required this.rating,
    required this.createdAt,
  });

  Mood.fromJson(Map<String, dynamic> json)
      : id = json['_id'],
        rating = double.parse(json['rating'].toString()),
        createdAt = json['createdAt'];
}
