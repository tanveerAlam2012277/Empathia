class GroupPost {
  String id;
  String message;
  String replyTo;
  List<String> likes;
  String userName;

  GroupPost({
    required this.id,
    required this.message,
    required this.replyTo,
    required this.likes,
    required this.userName,
  });

  factory GroupPost.fromJson(Map<String, dynamic> json) {
    return GroupPost(
      id: json['_id'] ?? '',
      message: json['message'] ?? '',
      replyTo: json['replyTo'] ?? '',
      likes: List<String>.from(json['likes'] ?? []),
      userName:
          json['user'] == "admin" ? "Admin" : json['user']['communityName'],
    );
  }
}
