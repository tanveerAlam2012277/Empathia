class Generic {
  String id;
  String name;

  Generic({required this.id, required this.name});

  factory Generic.fromJson(Map<String, dynamic> json) {
    return Generic(
      id: json['_id'],
      name: json['name'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
    };
  }
}
