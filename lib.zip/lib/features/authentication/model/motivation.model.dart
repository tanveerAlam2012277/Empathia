class Motivation {
  final String id;
  final String caption;
  final String image;

  Motivation({
    required this.id,
    required this.caption,
    required this.image,
  });

  factory Motivation.fromJson(Map<String, dynamic> json) {
    return Motivation(
      id: json['_id'],
      image: json['image'],
      caption: json['caption'],
    );
  }
}
