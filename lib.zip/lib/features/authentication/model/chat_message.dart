class ChatMessage {
  String id;
  String message;
  String groupID;
  String user;
  String senderName;
  bool isMe;
  String createdAt;

  ChatMessage({
    this.id = "",
    required this.message,
    required this.groupID,
    required this.user,
    required this.senderName,
    this.isMe = false,
    required this.createdAt,
  });

  factory ChatMessage.fromJson(Map<String, dynamic> json, bool _isMe) {
    String userID = "admin";
    String senderName = "Admin";
    if (json['user'] != "admin") {
      userID = json['user']['_id'];
      senderName = json['user']['communityName'];
    }

    return ChatMessage(
      id: json['_id'] ?? '',
      message: json['message'] ?? '',
      groupID: json['groupID'] ?? '',
      user: userID,
      senderName: senderName,
      isMe: _isMe,
      createdAt: json['createdAt'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'message': message,
      'groupID': groupID,
      'user': user,
      'senderName': senderName,
      'isMe': isMe,
      'createdAt': createdAt,
    };
  }
}
