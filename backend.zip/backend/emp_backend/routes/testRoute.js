const express = require("express");
const router = express();

const { createTest, addQuestion, deleteQuestion, addTestResult, checkEligibility, getAllTests, getSingleTestByName } = require("../Controller/testController");

router.route("/test/create").post(createTest);
router.route("/test/addQuestion").post(addQuestion);
router.route("/test/deleteQuestion").delete(deleteQuestion);
router.route("/test/get").get(getAllTests);
router.route("/test/getSingle").post(getSingleTestByName);
router.route("/test/addTestResult").post(addTestResult);
router.route("/test/checkEligibility").post(checkEligibility);


module.exports = router;