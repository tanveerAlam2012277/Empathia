const express = require("express");
const router = express();

const { createGroup, addMember, removeMember, addGroupMessage, removeMessage, getAllGroups, getAllMessagesByGroupId } = require("../Controller/groupController");

router.route("/group/create").post(createGroup);
router.route("/group/addMember").post(addMember);
router.route("/group/removeMember").delete(removeMember);
router.route("/group/addMessage").post(addGroupMessage);
router.route("/group/removeMessage").delete(removeMessage);
router.route("/group/all").get(getAllGroups);
router.route("/group/messages").post(getAllMessagesByGroupId);

module.exports = router;