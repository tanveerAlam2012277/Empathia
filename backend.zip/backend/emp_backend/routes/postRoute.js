const express = require("express");
const router = express();

const {  createPost, likePost, unlikePost, deletePost, getAllPosts } = require("../Controller/postController");

router.route("/post/create").post(createPost);
router.route("/post/like").post(likePost);
router.route("/post/unlike").post(unlikePost);
router.route("/post/delete").delete(deletePost);
router.route("/post/getAll").get(getAllPosts);


module.exports = router;