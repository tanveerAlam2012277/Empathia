const express = require("express");
const router = express.Router();
const { createCategory, createSubcategory, createArticle, getArticles, getSubcategoriesAndArticles, getCategories, getSubcategories, updateCategoryName, updateSubcategoryName, editArticle, deleteCategoryAndRelated, deleteSubcategoryAndRelated, getSubcategoriesbyCat, deleteArticle } = require("../Controller/articleController");


router.route("/category/create").post(createCategory);
router.route("/subcategory/create").post(createSubcategory);
router.route("/article/create").post(createArticle);
router.route("/articles").get(getArticles);
router.route("/allsubcategories").get(getSubcategories);
router.route("/categories").get(getCategories);
router.route("/categories/subcategories/:id").get(getSubcategoriesbyCat);
router.route("/articles/:categoryId").get(getSubcategoriesAndArticles);
router.route("/category/update/:id").put(updateCategoryName);
router.route("/subcategory/update/:id").put(updateSubcategoryName);
router.route("/article/update/:id").put(editArticle);
router.route("/category/delete/:categoryId").delete(deleteCategoryAndRelated);
router.route("/subcategory/delete/:subcategoryId").delete(deleteSubcategoryAndRelated);
router.route("/article/delete/:id").delete(deleteArticle);

module.exports = router;