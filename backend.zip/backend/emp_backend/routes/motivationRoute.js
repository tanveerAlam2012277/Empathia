const express = require("express");
const router = express();

const { createMotivation, createHopeboard, deleteMotivation, deleteHopeboard, getAllUserHopeboards, getAllMotivations  } = require("../Controller/motivationController");

router.route("/motivation/create").post(createMotivation);
router.route("/hopeboard/create").post(createHopeboard);
router.route("/motivation/delete").delete(deleteMotivation);
router.route("/hopeboard/delete").delete(deleteHopeboard);
router.route("/hopeboard/all").post(getAllUserHopeboards);
router.route("/motivation/all").get(getAllMotivations);

module.exports = router;