const express = require("express");
const router = express();

const { createMusic, createGenre, getAllMusic, getGenres, updateGenreName, editMusic, deleteGenreAndRelated, deleteMusic, getGenresWithMusic } = require("../Controller/musicController");

router.route("/music/create").post(createMusic);
router.route("/genre/create").post(createGenre);
router.route("/musics").get(getAllMusic);
router.route("/genres").get(getGenres);
router.route("/genre/update/:id").put(updateGenreName);
router.route("/music/update/:id").put(editMusic);
router.route("/genre/delete/:id").delete(deleteGenreAndRelated);
router.route("/music/delete/:id").delete(deleteMusic);
router.route("/music/all").get(getGenresWithMusic);



module.exports = router;