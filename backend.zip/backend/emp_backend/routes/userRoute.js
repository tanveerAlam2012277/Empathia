const express = require("express");
const { CreateUser, login, VerifyOtp, allRegisterUser, ForgetPassword, ResetPassword, registerMood, getUserMoodsForDay, getUserByID, setCommunityName, addMoneyInWallet, removeMoneyFromWallet, getUsersAmountInWallet } = require("../Controller/userController");
const router = express.Router();


// singup
router.route("/user/register").post(CreateUser);
router.route("/user/get").post(getUserByID);
router.route("/user/login").post(login);
router.route("/user/verify").post(VerifyOtp);
router.route("/user/updatedUser").post(allRegisterUser);
router.route("/user/forgetPassword").post(ForgetPassword);
router.route("/user/resetPassword").post(ResetPassword);
router.route("/user/registerMood").post(registerMood);
router.route("/user/getUserMoodsForDay").post(getUserMoodsForDay);
router.route("/user/setCommunityName").post(setCommunityName);
router.route("/user/addMoneyInWallet").post(addMoneyInWallet);
router.route("/user/removeMoneyFromWallet").post(removeMoneyFromWallet);
router.route("/user/getUsersAmountInWallet").post(getUsersAmountInWallet);

module.exports = router