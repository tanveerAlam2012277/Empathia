const express = require("express");
const { getUsers, getCycos, deleteUser, deleteCyco, approveCyco, unpproveCyco, getCounts } = require("../Controller/adminUserController");
const router = express.Router();

router.get('/counts', getCounts);
router.get('/users', getUsers);
router.get('/cycos', getCycos);
router.delete('/users/:id', deleteUser);
router.delete('/cycos/:id', deleteCyco);
router.put('/cycos/approve/:id', approveCyco);
router.put('/cycos/unapprove/:id', unpproveCyco);


module.exports = router