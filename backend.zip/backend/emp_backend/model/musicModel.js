// models/Music.js
const mongoose = require('mongoose');

const musicSchema = new mongoose.Schema({
    title: {
        type: String
    },
    image: {
        type: String,
        default: "https://e7.pngegg.com/pngimages/726/962/png-clipart-music-digital-audio-mp3-android-electronic-device-audio-equipment-thumbnail.png"
    },
    genre: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Genre', // This should match the model name for Category
        required: true
    },
    url: {
        type: String,
    }
});

const Music = mongoose.model('Music', musicSchema)

module.exports = { Music };
