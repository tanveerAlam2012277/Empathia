const mongoose = require('mongoose');
const { Schema } = mongoose;

const AppointmentSchema = new Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'USER'
    },
    psychologist: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'CYCOUSER'
    },
    appointmentTime: {
        type: String,
        required: true
    },
    psychologistRemarks: {
        type: String,
        default: ''
    },
    status: {
        type: String,
        enum: ['pending', 'approved', 'denied', 'completed'],
        default: 'pending'
    }
});

const AppointmentModel = mongoose.model('APPOINTMENT', AppointmentSchema);

module.exports = { AppointmentModel };