// models/Music.js
const mongoose = require('mongoose');

const articleSchema = new mongoose.Schema({
    title: {
        type: String,
        required: true,
        trim: true
    },
    image: {
        type: String,
        required: true,
        default: "https://contenthub-static.grammarly.com/blog/wp-content/uploads/2022/08/BMD-3398.png"
    },
    message: {
        type: String,
        required: true,
    },
    category: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Category', // This should match the model name for Category
        required: true
    },
    subcategory: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Subcategory', // This should match the model name for Subcategory
        required: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
});

const articleModel = mongoose.model('ARTICLE', articleSchema)

module.exports = { articleModel };
