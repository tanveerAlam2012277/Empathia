// models/Music.js
const mongoose = require('mongoose');

const hopeboardSchema = new mongoose.Schema({ 
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'USER',
        required: true
    },
    motivation: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Motivation', 
        required: true
    },
    message: {
        type: String,
        required: true,
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
});

const hopeboardModel = mongoose.model('HOPEBOARD', hopeboardSchema)

module.exports = { hopeboardModel };
