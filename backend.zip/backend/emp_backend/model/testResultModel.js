const mongoose = require('mongoose');

const TestResultSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
  },
  questions: {
    type: [String],
    required: true,
  },
  answers: {
    type: [String],
    required: true,
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User', // This should match the model name for Category
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

const TestResult = mongoose.model('TestResult', TestResultSchema);

module.exports = TestResult;

