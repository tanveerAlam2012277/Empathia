// models/Music.js
const mongoose = require('mongoose');

const moodSchema = new mongoose.Schema({
    rating: {
        type: Number,
        required: true
    },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
});

const Mood = mongoose.model('Mood', moodSchema)

module.exports = { Mood };
