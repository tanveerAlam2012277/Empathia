// models/Music.js
const mongoose = require('mongoose');

const motivationSchema = new mongoose.Schema({
    caption: {
        type: String,
        trim: true
    },
    image: {
        type: String,
        required: true,
        default: "https://contenthub-static.grammarly.com/blog/wp-content/uploads/2022/08/BMD-3398.png"
    },
    createdAt: {
        type: Date,
        default: Date.now
    },
});

const motivationModel = mongoose.model('Motivation', motivationSchema)

module.exports = { motivationModel };
