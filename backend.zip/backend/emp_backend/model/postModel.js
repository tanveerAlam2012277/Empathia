const mongoose = require('mongoose');

const communityPostSchema = new mongoose.Schema({
    message: {
        type: String,
        required: true,
    },
    likes: {
        type: [String],
        required: true,
    },
    replyTo: {
        type: String,
    },
    user: {
        type: String,
        required: true
    }, 
    createdAt: {
        type: Date,
        default: Date.now
    },
},);

const communityPost = mongoose.model('COMMUNITYPOST', communityPostSchema)

module.exports = { communityPost };
