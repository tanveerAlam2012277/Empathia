const mongoose = require('mongoose');

const groupMessageSchema = new mongoose.Schema({
    message: {
        type: String,
        required: true,
    },
    group: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'CHATGROUP',
    },
    user: {
        type: String,
        required: true
    }, 
    createdAt: {
        type: Date,
        default: Date.now
    },
},);

const groupMessage = mongoose.model('GROUPMESSAGE', groupMessageSchema)

module.exports = { groupMessage };
