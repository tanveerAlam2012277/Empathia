const mongoose = require('mongoose');

const MentalTestSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true
  },
  questions: {
    type: [String],
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

const MentalTest = mongoose.model('MentalTest', MentalTestSchema);

module.exports = MentalTest;

