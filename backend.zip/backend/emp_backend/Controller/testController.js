const asyncHandler = require('express-async-handler');
const { userModel } = require("../model/userModel");
const MentalTest = require("../model/testModel");
const TestResult = require("../model/testResultModel");

const getAllTests = async (req, res) => {
    try {
        const tests = await MentalTest.find();

        res.status(200).json({ success: true, data: tests });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
};

const getSingleTestByName = asyncHandler(async (req, res) => {
    try {
        const { name } = req.body;
        const test = await MentalTest.findOne({ name: name });

        if (!test) {
            return res.status(404).json({ success: false, message: "Test not found!" });
        }

        res.status(200).json({ success: true, data: test });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false, error: error.message });
    }
});

const createTest = async (req, res) => {
    try {
        const newTest = await MentalTest.create({
            name: req.body.name,
            questions: req.body.questions
        });

        if (!newTest) {
            return res.status(400).json({ message: "Test not created!" });
        }

        res.status(200).json({ message: "Test created successfully!", newTest });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error creating test.' });
    }
};

const addQuestion = async (req, res) => {
    try {
        const test = await MentalTest.findById(req.body.id);

        if (!test) {
            return res.status(404).json({ message: "Test not found!" });
        }

        test.questions.push(req.body.question);
        const updatedTest = await test.save();

        res.status(200).json({ message: "Question added successfully!", updatedTest });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error adding question.' });
    }
};

const deleteQuestion = async (req, res) => {
    try {
        const test = await MentalTest.findById(req.body.id);

        if (!test) {
            return res.status(404).json({ message: "Test not found!" });
        }

        const question = req.body.question;
        const questionIndex = test.questions.indexOf(question);
        if (questionIndex === -1) {
            return res.status(400).json({ message: "Question not found!" });
        }

        test.questions.splice(questionIndex, 1);
        const updatedTest = await test.save();

        res.status(200).json({ message: "Question deleted successfully!", updatedTest });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error deleting question.' });
    }
};

const addTestResult = async (req, res) => {
    try {
        const { name, questions, answers, user } = req.body;

        // Check if user exists
        const userExists = await userModel.findById(user);
        if (!userExists) {
            return res.status(404).json({ message: "User not found!" });
        }

        const testResult = new TestResult({
            name,
            questions,
            answers,
            user
        });

        await testResult.save();

        res.status(201).json({
            success: true,
            data: testResult
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
};

const checkEligibility = async (req, res) => {
    try {
        const userId = req.body.id;

        // Get the date one week ago
        const oneWeekAgo = new Date();
        oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

        // Check if a test result exists for the user in the past week
        const testResult = await TestResult.findOne({
            user: userId,
            createdAt: { $gte: oneWeekAgo }
        });

        if (testResult) {
            return res.status(200).json({ status: true, message: "User has filled a test this week." },);
        } else {
            return res.status(200).json({ status: false, message: "User has not filled a test this week." });
        }
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
};

module.exports = { createTest, addQuestion, deleteQuestion, addTestResult, checkEligibility, getAllTests, getSingleTestByName }; 