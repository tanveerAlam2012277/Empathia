const asyncHandler = require('express-async-handler');
const Genre = require('../model/genreModel');
const { Music } = require('../model/musicModel');

const createMusic = asyncHandler(async (req, res) => {

    try {
        const newMusic = await Music.create({
            image: req.body.image,
            title: req.body.title,
            genre: req.body.genre,
            url: req.body.url,
        });

        if (!newMusic) {
            return res.status(404).json({ message: "Music not found!" });
        }

        await newMusic.save();

        res.status(200).json({ message: "Music added successfully!", newMusic });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error creating music.' });
    }
});

const createGenre = async (req, res) => {
    try {
        const newGenre = await Genre.create({
            name: req.body.title,
        });

        if (!newGenre) {
            return res.status(400).json({ message: "Genre not created!" });
        }

        res.status(200).json({ message: "Genre created successfully!", newGenre });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error creating genre.' });
    }
};


const getAllMusic = async (req, res) => {
    try {
        const musics = await Music.find().populate('genre');

        res.status(200).json({ musics });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching musics.' });
    }
};

const getGenres = async (req, res) => {
    try {
        const genres = await Genre.find();

        res.status(200).json({ genres });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching genres.' });
    }
};


const updateGenreName = async (req, res) => {
    try {
        const genreId = req.params.id;
        const newTitle = req.body.title;

        const genre = await Genre.findByIdAndUpdate(genreId, { name: newTitle }, { new: true });

        if (!genre) {
            return res.status(404).json({ message: 'Genre not found!' });
        }

        res.status(200).json({ message: 'Genre title updated successfully!', genre });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error updating genre title.' });
    }
};

const editMusic = asyncHandler(async (req, res) => {
    const musicId = req.params.id;

    try {
        const updatedMusic = await Music.findByIdAndUpdate(musicId, {
            image: req.body.image,
            title: req.body.title,
            url: req.body.url,
            genre: req.body.genre,
        }, { new: true });

        if (!updatedMusic) {
            return res.status(404).json({ message: "Music not found!" });
        }

        res.status(200).json({ message: "Music updated successfully!", updatedMusic });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error updating music.' });
    }
});

const deleteGenreAndRelated = async (req, res) => {
    try {
        const genreId = req.params.id;

        const genre = await Genre.findById(genreId);
        if (!genre) {
            return res.status(404).json({ message: 'Genre not found!' });
        }

        await Music.deleteMany({ genre: genreId });
        await Genre.deleteOne({ _id: genreId });

        res.status(200).json({ message: 'Genre, and it\'s musics deleted successfully!' });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error deleting genre and related subgenres and musics.' });
    }
};

const deleteMusic = async (req, res) => {
    try {
        const musicId = req.params.id;

        const music = await Music.findByIdAndDelete(musicId);

        if (!music) {
            return res.status(404).json({ message: 'Music not found!' });
        }

        res.status(200).json({ message: 'Music deleted successfully!' });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error deleting music.' });
    }
};

const getGenresWithMusic = async (req, res) => {
    try {
        const genres = await Genre.find();

        const genresWithMusic = await Promise.all(genres.map(async (genre) => {
            const musics = await Music.find({ genre: genre._id });
            return { ...genre._doc, musics };
        }));

        res.status(200).json({ genres: genresWithMusic });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching genres with music.' });
    }
};


module.exports = { createMusic, createGenre, getAllMusic, getGenres, updateGenreName, editMusic, deleteGenreAndRelated, deleteMusic, getGenresWithMusic }