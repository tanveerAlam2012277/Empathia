const asyncHandler = require('express-async-handler')
const { motivationModel } = require("../model/motivationModel")
const { hopeboardModel } = require("../model/hopeboardModel")

const createMotivation = asyncHandler(async (req, res) => {

    try {
        const newMotivation = await motivationModel.create({
            image: req.body.image,
            caption: req.body.caption,
        });

        if (!newMotivation) {
            return res.status(404).json({ message: "Motivation not found!" });
        }

        await newMotivation.save();

        res.status(200).json({ message: "Motivation added successfully!", newMotivation });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error creating motivation.' });
    }
});

const createHopeboard = asyncHandler(async (req, res) => {

    try {
        const newHopeboard = await hopeboardModel.create({
            user: req.body.user,
            message: req.body.message,
            motivation: req.body.motivation,
        });

        if (!newHopeboard) {
            return res.status(404).json({ message: "Hopeboard not found!" });
        }

        await newHopeboard.save();

        res.status(200).json({ message: "Hopeboard added successfully!", newHopeboard });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error creating hopeboard.' });
    }
});

const deleteMotivation = asyncHandler(async (req, res) => {
    try {
        const { id } = req.body;
        const motivation = await motivationModel.findById(id);

        if (!motivation) {
            return res.status(404).json({ message: "Motivation not found!" });
        }

        await motivationModel.findByIdAndDelete(id);

        res.status(200).json({ message: "Motivation deleted successfully!" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error deleting motivation.' });
    }
});

const deleteHopeboard = asyncHandler(async (req, res) => {
    try {
        const { id } = req.body;
        const hopeboard = await hopeboardModel.findById(id);

        if (!hopeboard) {
            return res.status(404).json({ message: "Hopeboard not found!" });
        }

        await hopeboardModel.findByIdAndDelete(id);

        res.status(200).json({ message: "Hopeboard deleted successfully!" });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error deleting hopeboard.' });
    }
});

const getAllUserHopeboards = asyncHandler(async (req, res) => {
    try {
        const { userId } = req.body;
        const hopeboards = await hopeboardModel.find({ user: userId }).populate('motivation').sort({ createdAt: -1 });

        if (!hopeboards) {
            return res.status(404).json({ message: "No hopeboards found for this user!" });
        }

        res.status(200).json({ message: "Hopeboards fetched successfully!", hopeboards });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching hopeboards.' });
    }
});

const getAllMotivations = asyncHandler(async (req, res) => {
    try {
        const motivations = await motivationModel.find().sort({ createdAt: -1 }).limit(10);

        if (!motivations) {
            return res.status(404).json({ message: "No motivations found!" });
        }

        res.status(200).json({ message: "Motivations fetched successfully!", motivations });
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching motivations.' });
    }
});

module.exports = { createMotivation, createHopeboard, deleteMotivation, deleteHopeboard, getAllUserHopeboards, getAllMotivations }