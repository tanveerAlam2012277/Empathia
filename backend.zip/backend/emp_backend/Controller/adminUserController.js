const { userModel } = require("../model/userModel");
const { CycoModel } = require("../model/userCycoModel");
const { articleModel } = require("../model/articleModel");
const { Music } = require("../model/musicModel");
const  Category  = require("../model/categoryModel");
const  Subcategory  = require("../model/subcategoryModel");
const Genre = require("../model/genreModel");

const asyncHandler = require('express-async-handler');

const getUsers = asyncHandler(async (req, res) => {
    try {
        const users = await userModel.find();

        res.status(200).json({ users });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching users.' });
    }
});

const getCycos = asyncHandler(async (req, res) => {
    try {
        const cycos = await CycoModel.find();

        res.status(200).json({ cycos });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching cycos.' });
    }
});

const deleteUser = asyncHandler(async (req, res) => {
    try {
        const userId = req.params.id;

        const user = await userModel.findByIdAndDelete(userId);

        if (!user) {
            return res.status(404).json({ message: 'User not found!' });
        }

        res.status(200).json({ message: 'User deleted successfully!' });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error deleting user.' });
    }
});

const deleteCyco = asyncHandler(async (req, res) => {
    try {
        const cycoId = req.params.id;

        const cyco = await CycoModel.findByIdAndDelete(cycoId);

        if (!cyco) {
            return res.status(404).json({ message: 'Cyco not found!' });
        }

        res.status(200).json({ message: 'Cyco deleted successfully!' });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error deleting cyco.' });
    }
});

const approveCyco = asyncHandler(async (req, res) => {
    try {
        const cycoId = req.params.id;

        const cyco = await CycoModel.findByIdAndUpdate(cycoId, { isApproved: true }, { new: true });

        if (!cyco) {
            return res.status(404).json({ message: 'Cyco not found!' });
        }

        res.status(200).json({ message: 'Cyco approved successfully!', cyco });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error approving Cyco.' });
    }
});

const unpproveCyco = asyncHandler(async (req, res) => {
    try {
        const cycoId = req.params.id;

        const cyco = await CycoModel.findByIdAndUpdate(cycoId, { isApproved: false }, { new: true });

        if (!cyco) {
            return res.status(404).json({ message: 'Cyco not found!' });
        }

        res.status(200).json({ message: 'Cyco approved successfully!', cyco });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error approving Cyco.' });
    }
});

const getCounts = asyncHandler(async (req, res) => {
    try {
        const userCount = await userModel.countDocuments();
        const cycoCount = await CycoModel.countDocuments();
        const categoryCount = await Category.countDocuments();
        const subcategoryCount = await Subcategory.countDocuments();
        const articleCount = await articleModel.countDocuments();
        const genreCount = await Genre.countDocuments();
        const musicCount = await Music.countDocuments();

        res.status(200).json({
            userCount,
            cycoCount,
            categoryCount,
            subcategoryCount,
            articleCount,
            genreCount,
            musicCount
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching counts.' });
    }
});

module.exports = { getUsers, getCycos, deleteUser, deleteCyco, approveCyco, unpproveCyco, getCounts };