const asyncHandler = require('express-async-handler');
const { chatgroup } = require('../model/chatgroupModel');
const { groupMessage } = require('../model/groupMessages');
const { userModel } = require('../model/userModel');

const createGroup = async (req, res) => {
    try {
        const { name } = req.body;

        const group = new chatgroup({
            name,
            members: []
        });

        await group.save();

        res.status(200).json({
            success: true,
            data: group
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
};

const addMember = async (req, res) => {
    try {
        const { userId, groupId } = req.body;

        // Find the group by ID
        const group = await chatgroup.findById(groupId);
        if (!group) {
            return res.status(404).json({ message: "Group not found!" });
        }

        // Add the userId to the members array if it's not already there
        if (!group.members.includes(userId)) {
            group.members.push(userId);
            await group.save();
        }

        res.status(200).json({
            success: true,
            data: group
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
};

const removeMember = async (req, res) => {
    try {
        const { userId, groupId } = req.body;

        // Find the group by ID
        const group = await chatgroup.findById(groupId);
        if (!group) {
            return res.status(404).json({ message: "Group not found!" });
        }

        // Remove the userId from the members array if it's there
        const index = group.members.indexOf(userId);
        if (index !== -1) {
            group.members.splice(index, 1);
            await group.save();
        }

        res.status(200).json({
            success: true,
            data: group
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
};

const addGroupMessage = async (req, res) => {
    try {
        const { message, groupId, userId } = req.body;

        const newMessage = new groupMessage({
            message: message,
            group: groupId,
            user: userId
        });

        await newMessage.save();

        // Create a copy of the newMessage object
        let newMessageObject = newMessage.toObject();

        // Fetch user details if the user is not 'admin'
        if (userId !== 'admin') {
            const user = await userModel.findById(userId);
            if (user) {
                // Replace the 'user' property on the copy
                newMessageObject.user = user.toObject();
            }
        }

        res.status(200).json({
            success: true,
            data: newMessageObject
        });
    } catch (error) {
        console.error(error);
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
};

const removeMessage = async (req, res) => {
    try {
        const { messageId } = req.body;

        // Find the message by ID and delete it
        const message = await groupMessage.findByIdAndDelete(messageId);
        if (!message) {
            return res.status(404).json({ message: "Message not found!" });
        }

        res.status(200).json({
            success: true,
            message: "Message deleted successfully!"
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
};

const getAllGroups = async (req, res) => {
    try {
        // Find all groups
        const groups = await chatgroup.find();

        res.status(200).json({
            success: true,
            data: groups
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
};

const getAllMessagesByGroupId = async (req, res) => {
    try {
        const { groupId } = req.body;

        // Find all messages of the group and sort them by creation date
        let messages = await groupMessage.find({ group: groupId }).sort({ createdAt: -1 });

        // Fetch user details for each message
        // Fetch user details for each message
        messages = await Promise.all(messages.map(async (message) => {
            message = message.toObject(); // Convert the message document to a regular object
            if (message.user != 'admin') {
                console.log(message.user);
                const user = await userModel.findById(message.user);
                if (user) {
                    message.user = user;
                }
            }
            return message;
        }));

        res.status(200).json({
            success: true,
            data: messages
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
};

module.exports = { createGroup, addMember, removeMember, addGroupMessage, removeMessage, getAllGroups, getAllMessagesByGroupId };