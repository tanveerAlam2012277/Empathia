const asyncHandler = require('express-async-handler')
const { articleModel } = require("../model/articleModel")
const CloudUploadImage = require("../utils/Cloudniary");
const  Category  = require('../model/categoryModel');
const  Subcategory  = require('../model/subcategoryModel');

const createArticle = asyncHandler(async (req, res) => {

    try {
        const newArticle = await articleModel.create({
            image: req.body.image,
            title: req.body.title,
            message: req.body.message,
            category: req.body.category,
            subcategory: req.body.subcategory,
        });

        if (!newArticle) {
            return res.status(404).json({ message: "Article not found!" });
        }

        await newArticle.save();

        res.status(200).json({ message: "Article added successfully!", newArticle });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error creating article.' });
    }
});

const createCategory = async (req, res) => {
    try {
        const newCategory = await Category.create({
            name: req.body.title,
        });

        if (!newCategory) {
            return res.status(400).json({ message: "Category not created!" });
        }

        res.status(200).json({ message: "Category created successfully!", newCategory });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error creating category.' });
    }
};

const createSubcategory = async (req, res) => {
    try {
        console.log(req.body);
        const newSubcategory = await Subcategory.create({
            name: req.body.title,
            category: req.body.category,
        });

        if (!newSubcategory) {
            return res.status(400).json({ message: "Subcategory not created!" });
        }

        res.status(200).json({ message: "Subcategory created successfully!", newSubcategory });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error creating subcategory.' });
    }
};

const getArticles = async (req, res) => {
    try {
        const articles = await articleModel.find().populate('category').populate('subcategory');

        res.status(200).json({ articles });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching articles.' });
    }
};

const getCategories = async (req, res) => {
    try {
        const categories = await Category.find();

        res.status(200).json({ categories });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching categories.' });
    }
};

const getSubcategories = async (req, res) => {
    try {
        const subcategories = await Subcategory.find()
            .populate({
                path: 'category',
                model: 'Category' // This should match the model name for Category
            })
            .sort({ 'category.name': 1 });

        res.status(200).json({ subcategories });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching subcategories.' });
    }
};

const getSubcategoriesAndArticles = async (req, res) => {
    try {
        const categoryId = req.params.categoryId;
        const subcategories = await Subcategory.find({ category: categoryId });

        const subcategoriesWithArticles = await Promise.all(subcategories.map(async (subcategory) => {
            const articles = await articleModel.find({ subcategory: subcategory._id });
            return { ...subcategory._doc, articles };
        }));

        res.status(200).json({ subcategories: subcategoriesWithArticles });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching subcategories and articles.' });
    }
};

const getSubcategoriesbyCat = async (req, res) => {
    try {
        const categoryId = req.params.id;

        const subcategories = await Subcategory.find({ category: categoryId })
            .populate({
                path: 'category',
                model: 'Category' // This should match the model name for Category
            })
            .sort({ 'category.name': 1 });

        res.status(200).json({ subcategories });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error fetching subcategories.' });
    }
};

const updateCategoryName = async (req, res) => {
    try {
        const categoryId = req.params.id;
        const newTitle = req.body.title;

        const category = await Category.findByIdAndUpdate(categoryId, { name: newTitle }, { new: true });

        if (!category) {
            return res.status(404).json({ message: 'Category not found!' });
        }

        res.status(200).json({ message: 'Category title updated successfully!', category });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error updating category title.' });
    }
};

const updateSubcategoryName = async (req, res) => {
    try {
        const subcategoryId = req.params.id;
        const newTitle = req.body.title;

        const subcategory = await Subcategory.findByIdAndUpdate(subcategoryId, { name: newTitle }, { new: true });

        if (!subcategory) {
            return res.status(404).json({ message: 'Subcategory not found!' });
        }

        res.status(200).json({ message: 'Subcategory title updated successfully!', subcategory });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error updating category title.' });
    }
};

const editArticle = asyncHandler(async (req, res) => {
    const articleId = req.params.id;

    try {
        const updatedArticle = await articleModel.findByIdAndUpdate(articleId, {
            image: req.body.image,
            title: req.body.title,
            message: req.body.message,
            category: req.body.category,
            subcategory: req.body.subcategory,
        }, { new: true });

        if (!updatedArticle) {
            return res.status(404).json({ message: "Article not found!" });
        }

        res.status(200).json({ message: "Article updated successfully!", updatedArticle });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error updating article.' });
    }
});

const deleteCategoryAndRelated = async (req, res) => {
    try {
        const categoryId = req.params.categoryId;

        const category = await Category.findById(categoryId);
        if (!category) {
            return res.status(404).json({ message: 'Category not found!' });
        }

        await Subcategory.deleteMany({ category: categoryId });
        await articleModel.deleteMany({ category: categoryId });
        await Category.deleteOne({ _id: categoryId });

        res.status(200).json({ message: 'Category, its subcategories, and articles deleted successfully!' });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error deleting category and related subcategories and articles.' });
    }
};

const deleteSubcategoryAndRelated = async (req, res) => {
    try {
        const subcategoryId = req.params.subcategoryId;

        const subcategory = await Subcategory.findById(subcategoryId);
        if (!subcategory) {
            return res.status(404).json({ message: 'Subcategory not found!' });
        }

        await articleModel.deleteMany({ subcategory: subcategoryId });
        await Subcategory.deleteOne({ _id: subcategoryId });

        res.status(200).json({ message: 'Subcategory and its articles deleted successfully!' });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error deleting subcategory and related articles.' });
    }
};

const deleteArticle = async (req, res) => {
    try {
        const articleId = req.params.id;

        const article = await articleModel.findByIdAndDelete(articleId);

        if (!article) {
            return res.status(404).json({ message: 'Article not found!' });
        }

        res.status(200).json({ message: 'Article deleted successfully!' });

    } catch (error) {
        console.error(error);
        res.status(500).json({ message: 'Error deleting article.' });
    }
};


module.exports = { createCategory, createSubcategory, createArticle, getArticles, getSubcategoriesAndArticles, getCategories, getSubcategories, updateCategoryName, updateSubcategoryName, editArticle, deleteCategoryAndRelated, deleteSubcategoryAndRelated, getSubcategoriesbyCat, deleteArticle }