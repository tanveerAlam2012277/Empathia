const asyncHandler = require('express-async-handler');
const { userModel } = require("../model/userModel");
const { communityPost } = require("../model/postModel");


const createPost = async (req, res) => {
    try {
        const { message, replyTo, user } = req.body;

        const post = new communityPost({
            message: message,
            likes: [],
            replyTo: replyTo,
            user: user,
        });

        await post.save();

        res.status(200).json({
            success: true,
            data: post
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
};

const likePost = async (req, res) => {
    try {
        const { email, postId } = req.body;

        // Find the post by ID
        const post = await communityPost.findById(postId);
        if (!post) {
            return res.status(404).json({ message: "Post not found!" });
        }

        // Add the email to the likes array if it's not already there
        if (!post.likes.includes(email)) {
            post.likes.push(email);
            await post.save();
        }

        res.status(200).json({
            success: true,
            data: post
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
};

const unlikePost = async (req, res) => {
    try {
        const { email, postId } = req.body;

        // Find the post by ID
        const post = await communityPost.findById(postId);
        if (!post) {
            return res.status(404).json({ message: "Post not found!" });
        }

        // Remove the email from the likes array if it's there
        const index = post.likes.indexOf(email);
        if (index !== -1) {
            post.likes.splice(index, 1);
            await post.save();
        }

        res.status(200).json({
            success: true,
            data: post
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
};

const deletePost = async (req, res) => {
    try {
        const { postId } = req.body;

        // Find the post by ID and delete it
        const post = await communityPost.findByIdAndDelete(postId);
        if (!post) {
            return res.status(404).json({ message: "Post not found!" });
        }

        res.status(200).json({
            success: true,
            message: "Post deleted successfully!"
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
};


const getAllPosts = async (req, res) => {
    try {
        // Find all posts
        let posts = await communityPost.find().sort({ createdAt: -1 });

        // Fetch user details for each post
        posts = await Promise.all(posts.map(async (post) => {
            post = post.toObject(); // Convert the post document to a regular object
            if (post.user != 'admin') {
                // console.log(post.user);
                const user = await userModel.findById(post.user);
                if (user) {
                    post.user = user;
                }
            }
            return post;
        }));

        res.status(200).json({
            success: true,
            data: posts
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: error.message
        });
    }
};

module.exports = { createPost, likePost, unlikePost, deletePost, getAllPosts };
