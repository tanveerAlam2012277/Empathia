package com.example.emp_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
