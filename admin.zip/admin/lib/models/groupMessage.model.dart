class GroupMessage {
  String message;
  String group;
  String user;
  String createdAt;

  GroupMessage({
    required this.message,
    required this.group,
    required this.user,
    required this.createdAt,
  });

  factory GroupMessage.fromJson(Map<String, dynamic> json) {
    return GroupMessage(
      message: json['message'] ?? '',
      group: json['group'] ?? '',
      user: json['user'] ?? '',
      createdAt: json['createdAt'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'message': message,
      'group': group,
      'user': user,
      'createdAt': createdAt,
    };
  }
}
