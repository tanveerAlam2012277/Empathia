class MentalTest {
  String id;
  String name;
  List<String> questions;

  MentalTest({
    required this.id,
    required this.name,
    required this.questions,
  });

  factory MentalTest.fromJson(Map<String, dynamic> json) {
    return MentalTest(
      id: json['_id'],
      name: json['name'],
      questions: List<String>.from(json['questions']),
    );
  }
}
