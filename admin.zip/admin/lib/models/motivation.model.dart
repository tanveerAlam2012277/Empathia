class Motivation {
  String id;
  String image;
  String caption;
  String createdAt;

  Motivation({
    required this.id,
    required this.image,
    required this.caption,
    required this.createdAt,
  });

  factory Motivation.fromJson(Map<String, dynamic> json) {
    return Motivation(
      id: json['_id'],
      image: json['image'],
      caption: json['caption'],
      createdAt: json['createdAt'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'image': image,
      'caption': caption,
      'createdAt': createdAt,
    };
  }
}
