class Cyco {
  final String id;
  final String email;
  final List<CnicUrl> cnicUrls;
  final String pdfUrl;
  final bool isVerified;
  final bool isApproved;
  final String licenceNumber;
  final String licenceImage;
  final String age;
  final String gender;
  final String cnicNumber;

  Cyco({
    required this.id,
    required this.email,
    required this.cnicUrls,
    required this.pdfUrl,
    required this.isVerified,
    required this.isApproved,
    required this.licenceNumber,
    required this.licenceImage,
    required this.age,
    required this.gender,
    required this.cnicNumber,
  });

  factory Cyco.fromJson(Map<String, dynamic> json) {
    var cnicUrlList = json['Cnicurls'] as List;
    List<CnicUrl> cnicUrlList_ =
        cnicUrlList.map((i) => CnicUrl.fromJson(i)).toList();

    return Cyco(
      id: json['_id'],
      email: json['email'],
      cnicUrls: cnicUrlList_,
      pdfUrl: json['Pdfurl'],
      isVerified: json['isVerified'],
      isApproved: json['isApproved'],
      licenceNumber: json['licenceNumber'],
      licenceImage: json['licenceImage'],
      age: json['age'],
      gender: json['gender'],
      cnicNumber: json['cnicNumber'],
    );
  }
}

class CnicUrl {
  final String url;
  final String assetId;
  final String publicId;

  CnicUrl({required this.url, required this.assetId, required this.publicId});

  factory CnicUrl.fromJson(Map<String, dynamic> json) {
    return CnicUrl(
      url: json['url'],
      assetId: json['asset_id'],
      publicId: json['public_id'],
    );
  }
}
