class Music {
  String id;
  String title;
  String image;
  String url;
  String genreName;
  String genreID;

  Music({
    required this.id,
    required this.title,
    required this.image,
    required this.url,
    required this.genreName,
    required this.genreID,
  });

  factory Music.fromJson(Map<String, dynamic> json) {
    return Music(
      id: json['_id'],
      title: json['title'],
      image: json['image'],
      url: json['url'],
      genreName: json['genre']['name'],
      genreID: json['genre']['_id'],
    );
  }
}
