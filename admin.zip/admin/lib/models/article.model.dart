class Article {
  final String id;
  final String title;
  final String image;
  final String message;
  final String categoryName;
  final String categoryID;
  final String subcategoryName;
  final String subcategoryID;
  final String createdAt;

  Article({
    required this.id,
    required this.title,
    required this.image,
    required this.message,
    required this.categoryName,
    required this.categoryID,
    required this.subcategoryName,
    required this.subcategoryID,
    required this.createdAt,
  });

  factory Article.fromJson(Map<String, dynamic> json) {
    return Article(
      id: json['_id'],
      title: json['title'],
      image: json['image'] ??
          "https://contenthub-static.grammarly.com/blog/wp-content/uploads/2022/08/BMD-3398.png",
      message: json['message'],
      categoryName: json['category']['name'],
      categoryID: json['category']['_id'],
      subcategoryName: json['subcategory']['name'],
      subcategoryID: json['subcategory']['_id'],
      createdAt: json['createdAt'],
    );
  }
}
