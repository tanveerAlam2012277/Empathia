class ChatGroup {
  String id;
  String name;
  List<String> members;
  String createdAt;

  ChatGroup({
    required this.id,
    required this.name,
    required this.members,
    required this.createdAt,
  });

  factory ChatGroup.fromJson(Map<String, dynamic> json) {
    return ChatGroup(
      id: json['_id'] ?? '',
      name: json['name'] ?? '',
      members: List<String>.from(json['members'] ?? []),
      createdAt: json['createdAt'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'members': members,
      'createdAt': createdAt,
    };
  }
}
