import 'package:emp_admin/models/music.model.dart';

class Generic {
  String id;
  String name;

  Generic({required this.id, required this.name});

  factory Generic.fromJson(Map<String, dynamic> json) {
    return Generic(
      id: json['_id'],
      name: json['name'],
    );
  }
}
