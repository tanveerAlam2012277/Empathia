class Subcategory {
  String id;
  String name;
  String categoryID;
  String categoryName;

  Subcategory({
    required this.id,
    required this.name,
    required this.categoryID,
    required this.categoryName,
  });

  factory Subcategory.fromJson(Map<String, dynamic> json) {
    return Subcategory(
      id: json['_id'],
      name: json['name'],
      categoryID: json['category']['_id'],
      categoryName: json['category']['name'],
    );
  }
}
