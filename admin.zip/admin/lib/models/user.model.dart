class User {
  final String id;
  final String communityName;
  final String email;
  final String selectModeules;
  final bool isVerified;
  final String age;
  final String gender;

  User({
    this.id = '',
    this.communityName = '',
    this.email = '',
    this.selectModeules = '',
    this.isVerified = false,
    this.age = '',
    this.gender = '',
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      id: json['_id'] ?? '',
      communityName: json['communityName'] ?? '',
      email: json['email'] ?? '',
      selectModeules: json['selectModeules'] ?? '',
      isVerified: json['isVerified'] ?? false,
      age: json['age'] ?? '',
      gender: json['gender'] ?? '',
    );
  }
}
