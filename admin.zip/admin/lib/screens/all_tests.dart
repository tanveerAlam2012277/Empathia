import 'dart:convert';

import 'package:emp_admin/constants/api_routes.dart';
import 'package:emp_admin/models/mentaltest.model.dart';
import 'package:emp_admin/screens/edit_test.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AllTests extends StatefulWidget {
  const AllTests({super.key});

  @override
  State<AllTests> createState() => _AllTestsState();
}

class _AllTestsState extends State<AllTests> {
  List<MentalTest> allTests = [];

  @override
  void initState() {
    super.initState();
    getCategories();
  }

  getCategories() async {
    var response = await http.get(
      Uri.parse(
        APIRoutes.getTests,
      ),
    );
    var jsonResponse = jsonDecode(response.body)['data'];
    print(jsonResponse);
    if (response.statusCode == 200) {
      List<MentalTest> tempcategories = [];
      for (var category in jsonResponse) {
        tempcategories.add(MentalTest.fromJson(category));
      }
      setState(() {
        allTests = tempcategories;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20),
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Icon(
                  Icons.arrow_back_ios,
                  color: Colors.white,
                  size: 40,
                ),
              ),
              SizedBox(height: 15),
              Text(
                "Mental Tests",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 5),
              Text(
                "View & Edit All Mental Tests.",
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              SizedBox(
                height: 20,
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: allTests.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        elevation: 3,
                        child: ListTile(
                          leading: Text("#${index + 1}"),
                          title: Text(
                            "${allTests[index].name}",
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          trailing: Wrap(
                            children: [
                              InkWell(
                                onTap: () async {
                                  await Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                      builder: (context) => EditMentalTest(
                                        test: allTests[index],
                                      ),
                                    ),
                                  ).then((val) {
                                    setState(() {
                                      allTests = [];
                                    });
                                    getCategories();
                                  });
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(
                                    Icons.edit,
                                    color: Colors.blue,
                                    size: 30,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
