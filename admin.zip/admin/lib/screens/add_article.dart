import 'dart:convert';
import 'package:emp_admin/constants/api_routes.dart';
import 'package:emp_admin/models/generic.model.dart';
import 'package:emp_admin/screens/all_articles.dart';
import 'package:emp_admin/screens/dashboard.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:html';
import 'package:flutter/material.dart';
import 'package:flutter_quill/flutter_quill.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class AddArticle extends StatefulWidget {
  const AddArticle({super.key});

  @override
  State<AddArticle> createState() => _AddArticleState();
}

class _AddArticleState extends State<AddArticle> {
  QuillController _controller = QuillController.basic();
  TextEditingController titleController = TextEditingController();
  TextEditingController categoryController = TextEditingController();
  TextEditingController subcategoryController = TextEditingController();

  List<Generic> categories = [];
  List<Generic> subcategories = [];

  Generic? selectedCategory;
  Generic? selectedSubcategory;

  File? selectedImage;

  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    implementQuill();
    getCategories();
  }

  getCategories() {
    http
        .get(
      Uri.parse(
        APIRoutes.getCategories,
      ),
    )
        .then((response) {
      var jsonData = jsonDecode(response.body)['categories'];
      List<Generic> cats = [];
      for (var item in jsonData) {
        cats.add(Generic.fromJson(item));
      }
      setState(() {
        categories = cats;
      });
    });
  }

  void implementQuill() {
    // load saved article into editor
    SharedPreferences.getInstance().then((prefs) {
      final article = prefs.getString("article");
      if (article != null) {
        _controller = QuillController(
          document: Document.fromJson(jsonDecode(article)),
          selection: TextSelection.collapsed(offset: 0),
        );
        setState(() {});
      }
    });
  }

  getImage() async {
    FileUploadInputElement uploadInput = FileUploadInputElement()
      ..accept = 'image/*';
    uploadInput.click();

    uploadInput.onChange.listen((e) {
      final file = uploadInput.files!.first;
      final reader = FileReader();
      reader.readAsDataUrl(file);
      reader.onLoadEnd.listen((event) {
        setState(() {
          selectedImage = file;
        });
      });
    });
  }

  submitArticle() async {
    setState(() {
      isLoading = true;
    });
    Fluttertoast.showToast(
      msg: "Your upload has started, please wait",
    );
    final dateTime = DateTime.now().millisecondsSinceEpoch;
    FirebaseStorage.instance
        .ref()
        .child(
          dateTime.toString(),
        )
        .putBlob(selectedImage)
        .then((val) async {
      await val.ref.getDownloadURL().then((downloadURL) async {
        var respone = await http.post(
          Uri.parse(
            APIRoutes.createArticle,
          ),
          body: {
            "image": downloadURL,
            "title": titleController.text,
            "category": categoryController.text,
            "subcategory": subcategoryController.text,
            "message": jsonEncode(_controller.document.toDelta().toJson()),
          },
        );
        var jsonData = jsonDecode(respone.body);
        print(jsonData);
        if (respone.statusCode == 200) {
          Fluttertoast.showToast(
            msg: "Article saved successfully",
          );
          SharedPreferences.getInstance().then((prefs) {
            prefs.remove("article");
          });
          setState(() {
            isLoading = false;
          });
          // Go to All articles
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (_) => DashboardScreen(),
            ),
            (route) => false,
          );
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => AllArticles(),
            ),
          );
        } else {
          Fluttertoast.showToast(
            msg: "Failed to save article",
          );
        }
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 20),
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Icon(
                    Icons.arrow_back_ios,
                    color: Colors.white,
                    size: 40,
                  ),
                ),
                SizedBox(height: 15),
                Text(
                  "Add Article",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  "Fill in the details of this article.",
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: TextFormField(
                        controller: titleController,
                        decoration: InputDecoration(
                          labelText: "Article Title",
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(
                      flex: 2,
                      child: InkWell(
                        onTap: getImage,
                        child: Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: selectedImage != null
                                  ? Colors.green
                                  : Colors.white,
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Center(
                              child: Text(
                                selectedImage != null
                                    ? "Edit Image: ${selectedImage!.name}"
                                    : "Select Image",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: DropdownButtonFormField<Generic>(
                        value: selectedCategory,
                        onChanged: (value) {
                          setState(() {
                            selectedCategory = value;
                            categoryController.text = value!.id;
                            subcategories = [];
                            selectedSubcategory = null;
                            subcategoryController.text = "";
                            http
                                .get(
                              Uri.parse(
                                APIRoutes.getSubcategoriesByCat +
                                    "/${value.id}",
                              ),
                            )
                                .then((response) {
                              print(response);
                              var jsonData =
                                  jsonDecode(response.body)['subcategories'];
                              List<Generic> subs = [];
                              for (var item in jsonData) {
                                subs.add(Generic.fromJson(item));
                              }
                              setState(() {
                                subcategories = subs;
                              });
                            });
                          });
                        },
                        items: categories.map((Generic category) {
                          return DropdownMenuItem<Generic>(
                            value: category,
                            child: Text(category.name),
                          );
                        }).toList(),
                        decoration: InputDecoration(
                          labelText: "Category",
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(
                      flex: 2,
                      child: DropdownButtonFormField<Generic>(
                        value: selectedSubcategory,
                        onChanged: (value) {
                          setState(() {
                            selectedSubcategory = value;
                            subcategoryController.text = value!.id;
                          });
                        },
                        items: subcategories.map((Generic subcategory) {
                          return DropdownMenuItem<Generic>(
                            value: subcategory,
                            child: Text(subcategory.name),
                          );
                        }).toList(),
                        decoration: InputDecoration(
                          labelText: "Subcategory",
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Center(
                  child: Card(
                    child: QuillToolbar.simple(
                      configurations: QuillSimpleToolbarConfigurations(
                        controller: _controller,
                        sharedConfigurations: const QuillSharedConfigurations(
                          locale: Locale('en'),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 15,
                ),
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.45,
                  child: Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.grey),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(20.0),
                      child: QuillEditor.basic(
                        configurations: QuillEditorConfigurations(
                          controller: _controller,
                          sharedConfigurations: const QuillSharedConfigurations(
                            locale: Locale('en'),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 15,
                ),
                if (isLoading)
                  Center(
                    child: CircularProgressIndicator(),
                  ),
                if (!isLoading)
                  InkWell(
                    onTap: () async {
                      print("**** PRINTING JSON ****");
                      final json =
                          jsonEncode(_controller.document.toDelta().toJson());
                      print(json);

                      //save json to shared prefs
                      SharedPreferences prefs =
                          await SharedPreferences.getInstance();
                      prefs.setString("article", json);
                      if (json != "" &&
                          titleController.text.isNotEmpty &&
                          selectedCategory != null &&
                          selectedSubcategory != null &&
                          selectedImage != null) {
                        submitArticle();
                      } else {
                        Fluttertoast.showToast(
                          msg:
                              "Please fill in all fields. (Title, Category, Subcategory, Image, Content).",
                        );
                      }
                    },
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.blue,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Center(
                          child: Text(
                            "Save Article",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                SizedBox(
                  height: 15,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
