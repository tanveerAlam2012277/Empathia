import 'dart:convert';

import 'package:emp_admin/constants/api_routes.dart';
import 'package:emp_admin/screens/all_groups.dart';
import 'package:emp_admin/screens/all_quotes.dart';
import 'package:emp_admin/screens/all_tests.dart';
import 'package:emp_admin/screens/community_tab.dart';
import 'package:http/http.dart' as http;
import 'package:emp_admin/screens/all_articles.dart';
import 'package:emp_admin/screens/all_categories.dart';
import 'package:emp_admin/screens/all_cycos.dart';
import 'package:emp_admin/screens/all_genres.dart';
import 'package:emp_admin/screens/all_music.dart';
import 'package:emp_admin/screens/all_subcategories.dart';
import 'package:emp_admin/screens/all_users.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  String categories = "...";
  String subcategories = "...";
  String articles = "...";
  String genres = "...";
  String musics = "...";
  String users = "...";
  String cycos = "...";

  @override
  void initState() {
    super.initState();
    getCounts();
  }

  Future<void> getCounts() async {
    final response = await http.get(
      Uri.parse(
        APIRoutes.counts,
      ),
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> counts = jsonDecode(response.body);

      setState(() {
        users = counts['userCount'].toString();
        cycos = counts['cycoCount'].toString();
        categories = counts['categoryCount'].toString();
        subcategories = counts['subcategoryCount'].toString();
        articles = counts['articleCount'].toString();
        genres = counts['genreCount'].toString();
        musics = counts['musicCount'].toString();
      });
    } else {
      throw Exception('Failed to load counts');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Dashboard"),
      ),
      drawer: Drawer(
        child: Column(
          children: [
            DrawerHeader(
              child: Center(
                child: Text(
                  "Emptathia Admin",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            ListTile(
              title: Text("Dashboard"),
              leading: Icon(Icons.dashboard),
              onTap: () {
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (_) => DashboardScreen(),
                  ),
                  (route) => false,
                );
              },
            ),
            ListTile(
              title: Text("Motivation Quotes"),
              leading: Icon(
                CupertinoIcons.text_quote,
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AllQuotes(),
                  ),
                );
              },
            ),
            ListTile(
              title: Text("Articles"),
              leading: Icon(
                CupertinoIcons.t_bubble,
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AllArticles(),
                  ),
                );
              },
            ),
            ListTile(
              title: Text("Community Tab"),
              leading: Icon(
                Icons.comment_bank_outlined,
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => CommunityTab(),
                  ),
                );
              },
            ),
            ListTile(
              title: Text("Chat Groups"),
              leading: Icon(
                CupertinoIcons.person_3_fill,
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AllGroups(),
                  ),
                );
              },
            ),
            ListTile(
              title: Text("Mental Tests"),
              leading: Icon(
                CupertinoIcons.ear,
              ),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => AllTests(),
                  ),
                );
              },
            ),
            ExpansionTile(
              leading: Icon(
                Icons.music_note,
              ),
              title: Text("Music"),
              children: [
                ListTile(
                  title: Text("Genres"),
                  leading: Icon(Icons.list_alt_sharp),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => AllGenresScreen(),
                      ),
                    );
                  },
                ),
                ListTile(
                  title: Text("Music Files"),
                  leading: Icon(
                    Icons.disc_full,
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => AllMusics(),
                      ),
                    );
                  },
                ),
              ],
            ),
            ExpansionTile(
              leading: Icon(
                Icons.person_search_sharp,
              ),
              title: Text("Members Onboard"),
              children: [
                ListTile(
                  title: Text("Users"),
                  leading: Icon(Icons.people_alt_sharp),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => AllUsersScreen(),
                      ),
                    );
                  },
                ),
                ListTile(
                  title: Text("Psychologists"),
                  leading: Icon(
                    Icons.work_history,
                  ),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => AllCycosScreen(),
                      ),
                    );
                  },
                ),
              ],
            ),
          ],
        ),
      ),
      body: SizedBox(
        child: GridView.count(
          childAspectRatio: 2,
          crossAxisCount: 5,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                elevation: 4,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.blue,
                        Colors.blueAccent,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ListTile(
                    subtitle: Text(
                      "Categories",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    title: Text(
                      categories,
                      style: TextStyle(
                        fontSize: 24,
                        color: Colors.white,
                      ),
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AllCategoriesScreen(),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                elevation: 4,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.green,
                        Colors.greenAccent,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ListTile(
                    subtitle: Text(
                      "Subcategories",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    title: Text(
                      subcategories,
                      style: TextStyle(
                        fontSize: 24,
                        color: Colors.white,
                      ),
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AllSubcategoriesScreen(),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                elevation: 4,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.red,
                        Colors.redAccent,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ListTile(
                    subtitle: Text(
                      "Articles",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    title: Text(
                      articles,
                      style: TextStyle(
                        fontSize: 24,
                        color: Colors.white,
                      ),
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AllArticles(),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                elevation: 4,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.purple,
                        Colors.purpleAccent,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ListTile(
                    subtitle: Text(
                      "Genres",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    title: Text(
                      genres,
                      style: TextStyle(
                        fontSize: 24,
                        color: Colors.white,
                      ),
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AllGenresScreen(),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                elevation: 4,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.orange,
                        Colors.orangeAccent,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ListTile(
                    subtitle: Text(
                      "Music",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    title: Text(
                      musics,
                      style: TextStyle(
                        fontSize: 24,
                        color: Colors.white,
                      ),
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AllMusics(),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                elevation: 4,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.teal,
                        Colors.tealAccent,
                      ],
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ListTile(
                    subtitle: Text(
                      "Users",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    title: Text(
                      users,
                      style: TextStyle(
                        fontSize: 24,
                        color: Colors.white,
                      ),
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AllUsersScreen(),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                elevation: 4,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.brown,
                        Colors.brown.withOpacity(
                          0.5,
                        ),
                      ],
                    ),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ListTile(
                    subtitle: Text(
                      "Cycos",
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    title: Text(
                      cycos,
                      style: TextStyle(
                        fontSize: 24,
                        color: Colors.white,
                      ),
                    ),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => AllCycosScreen(),
                        ),
                      );
                    },
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
