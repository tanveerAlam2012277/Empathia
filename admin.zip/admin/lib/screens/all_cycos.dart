import 'dart:convert';
import 'package:emp_admin/constants/api_routes.dart';
import 'package:emp_admin/models/cyco.model.dart';
import 'package:emp_admin/models/user.model.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:emp_admin/models/generic.model.dart';
import 'package:flutter/material.dart';

class AllCycosScreen extends StatefulWidget {
  const AllCycosScreen({super.key});

  @override
  State<AllCycosScreen> createState() => _AllCycosScreenState();
}

class _AllCycosScreenState extends State<AllCycosScreen> {
  List<Cyco> users = [];

  TextEditingController genreController = TextEditingController();

  @override
  void initState() {
    super.initState();
    getUsers();
  }

  getUsers() async {
    var response = await http.get(
      Uri.parse(
        APIRoutes.cycos,
      ),
    );
    var jsonResponse = jsonDecode(response.body);
    if (response.statusCode == 200) {
      List<Cyco> tempusers = [];
      for (var genre in jsonResponse) {
        tempusers.add(Cyco.fromJson(genre));
      }
      setState(() {
        users = tempusers;
      });
    }
  }

  deleteUser(String id) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Text(
                "Delete User",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Text(
                "Are you sure you want to delete this Psychologist?",
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  Fluttertoast.showToast(
                    msg: "Deleting Psychologist...",
                  );
                  await http
                      .delete(
                    Uri.parse(
                      APIRoutes.cycos + "/$id",
                    ),
                  )
                      .then((response) {
                    if (response.statusCode == 200) {
                      Fluttertoast.showToast(
                        msg: jsonDecode(response.body)['message'],
                      );
                      Navigator.pop(context);
                      getUsers();
                    } else {
                      Fluttertoast.showToast(
                        msg: "Failed to delete Psychologist.",
                      );
                      Navigator.pop(context);
                    }
                  });
                },
                child: Text(
                  "Delete",
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20),
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Icon(
                  Icons.arrow_back_ios,
                  color: Colors.white,
                  size: 40,
                ),
              ),
              SizedBox(height: 15),
              Text(
                "Psychologists",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 5),
              Text(
                "View, Approve, Delete All Psychologists.",
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              SizedBox(
                height: 20,
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: users.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        elevation: 3,
                        child: ListTile(
                          leading: Text("#${index + 1}"),
                          title: Text(
                            "${users[index].email}",
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "CNIC: ${users[index].cnicNumber} | ${users[index].age} Years Old. |",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                "License Number: ${users[index].licenceNumber} | Gender: ${users[index].gender.toUpperCase()}",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Row(
                                children: [
                                  Text(
                                    "Verified: ${users[index].isVerified ? "Yes" : "No"} | Approved: ${users[index].isApproved ? "Yes" : "No"}",
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  if (users[index].isApproved)
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: InkWell(
                                        onTap: () async {
                                          Fluttertoast.showToast(
                                            msg: "Blocking Psychologist...",
                                          );
                                          await http
                                              .put(
                                            Uri.parse(
                                              APIRoutes.unapproveCycos +
                                                  "/${users[index].id}",
                                            ),
                                          )
                                              .then((response) {
                                            print(response.body);
                                            if (response.statusCode == 200) {
                                              Fluttertoast.showToast(
                                                msg: jsonDecode(
                                                    response.body)['message'],
                                              );
                                              getUsers();
                                            } else {
                                              Fluttertoast.showToast(
                                                msg:
                                                    "Failed to block Psychologist.",
                                              );
                                              Navigator.pop(context);
                                            }
                                          });
                                        },
                                        child: Container(
                                          decoration: BoxDecoration(
                                            color: Colors.red,
                                            borderRadius:
                                                BorderRadius.circular(5),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Text(
                                              "Block Psychologist",
                                              style: TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  if (!users[index].isApproved)
                                    Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: InkWell(
                                        onTap: () async {
                                          Fluttertoast.showToast(
                                            msg: "Approving Psychologist...",
                                          );
                                          await http
                                              .put(
                                            Uri.parse(
                                              APIRoutes.approveCycos +
                                                  "/${users[index].id}",
                                            ),
                                          )
                                              .then((response) {
                                            print(response.body);
                                            if (response.statusCode == 200) {
                                              Fluttertoast.showToast(
                                                msg: jsonDecode(
                                                    response.body)['message'],
                                              );
                                              getUsers();
                                            } else {
                                              Fluttertoast.showToast(
                                                msg:
                                                    "Failed to approve Psychologist.",
                                              );
                                              Navigator.pop(context);
                                            }
                                          });
                                        },
                                        child: Container(
                                          decoration: BoxDecoration(
                                            color: Colors.green,
                                            borderRadius:
                                                BorderRadius.circular(5),
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.all(8.0),
                                            child: Text(
                                              "Approve Psychologist",
                                              style: TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.bold,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ],
                          ),
                          trailing: Wrap(
                            children: [
                              InkWell(
                                onTap: () {
                                  // View documents in modal
                                  showModalBottomSheet(
                                    context: context,
                                    isScrollControlled: true,
                                    builder: (context) {
                                      return Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Column(
                                          children: [
                                            Text(
                                              "Documents",
                                              style: TextStyle(
                                                fontSize: 24,
                                                fontWeight: FontWeight.bold,
                                              ),
                                            ),
                                            SizedBox(height: 10),
                                            Text(
                                              "CNIC Front",
                                              style: TextStyle(
                                                fontSize: 18,
                                              ),
                                            ),
                                            Image.network(
                                              users[index].cnicUrls[0].url,
                                              height: 200,
                                            ),
                                            SizedBox(height: 10),
                                            Text(
                                              "CNIC Back",
                                              style: TextStyle(
                                                fontSize: 18,
                                              ),
                                            ),
                                            Image.network(
                                              users[index].cnicUrls[1].url,
                                              height: 200,
                                            ),
                                            SizedBox(height: 10),
                                            Text(
                                              "License",
                                              style: TextStyle(
                                                fontSize: 18,
                                              ),
                                            ),
                                            Image.network(
                                              users[index].licenceImage,
                                              height: 200,
                                            ),
                                          ],
                                        ),
                                      );
                                    },
                                  );
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(
                                    Icons.file_copy,
                                    color: Colors.blue,
                                    size: 30,
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: () {
                                  deleteUser(
                                    users[index].id,
                                  );
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(
                                    Icons.delete,
                                    color: Colors.red,
                                    size: 30,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
