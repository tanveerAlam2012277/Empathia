import 'dart:convert';
import 'package:emp_admin/constants/api_routes.dart';
import 'package:emp_admin/models/user.model.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:emp_admin/models/generic.model.dart';
import 'package:flutter/material.dart';

class AllUsersScreen extends StatefulWidget {
  const AllUsersScreen({super.key});

  @override
  State<AllUsersScreen> createState() => _AllUsersScreenState();
}

class _AllUsersScreenState extends State<AllUsersScreen> {
  List<User> users = [];

  @override
  void initState() {
    super.initState();
    getUsers();
  }

  getUsers() async {
    var response = await http.get(
      Uri.parse(
        APIRoutes.users,
      ),
    );
    var jsonResponse = jsonDecode(response.body)['users'];
    if (response.statusCode == 200) {
      List<User> tempusers = [];
      for (var user in jsonResponse) {
        tempusers.add(User.fromJson(user));
      }
      setState(() {
        users = tempusers;
      });
    }
  }

  deleteUser(String id) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Text(
                "Delete User",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Text(
                "Are you sure you want to delete this user?",
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  Fluttertoast.showToast(
                    msg: "Deleting User...",
                  );
                  await http
                      .delete(
                    Uri.parse(
                      APIRoutes.users + "/$id",
                    ),
                  )
                      .then((response) {
                    if (response.statusCode == 200) {
                      Fluttertoast.showToast(
                        msg: jsonDecode(response.body)['message'],
                      );
                      Navigator.pop(context);
                      getUsers();
                    } else {
                      Fluttertoast.showToast(
                        msg: "Failed to delete User",
                      );
                      Navigator.pop(context);
                    }
                  });
                },
                child: Text(
                  "Delete",
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20),
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Icon(
                  Icons.arrow_back_ios,
                  color: Colors.white,
                  size: 40,
                ),
              ),
              SizedBox(height: 15),
              Text(
                "Users",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 5),
              Text(
                "View All Users in Empathia.",
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              SizedBox(
                height: 20,
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: users.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        elevation: 3,
                        child: ListTile(
                          leading: Text("#${index + 1}"),
                          title: Text(
                            "${users[index].email}",
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          subtitle: Text(
                            "Modules: ${users[index].selectModeules} | ${users[index].age} Years Old. |",
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          trailing: Wrap(
                            children: [
                              InkWell(
                                onTap: () {
                                  deleteUser(
                                    users[index].id,
                                  );
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(
                                    Icons.delete,
                                    color: Colors.red,
                                    size: 30,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
