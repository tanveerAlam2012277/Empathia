import 'dart:convert';
import 'package:emp_admin/constants/api_routes.dart';
import 'package:emp_admin/models/chatgroup.model.dart';
import 'package:emp_admin/screens/group_chat.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;

class AllGroups extends StatefulWidget {
  const AllGroups({super.key});

  @override
  State<AllGroups> createState() => _AllGroupsState();
}

class _AllGroupsState extends State<AllGroups> {
  List<ChatGroup> allGroups = [];

  TextEditingController nameController = TextEditingController();

  @override
  void initState() {
    super.initState();
    getGroups();
  }

  getGroups() async {
    var response = await http.get(
      Uri.parse(
        APIRoutes.getAllGroups,
      ),
    );
    var jsonResponse = jsonDecode(response.body)['data'];
    print(jsonResponse);
    if (response.statusCode == 200) {
      List<ChatGroup> tempcategories = [];
      for (var category in jsonResponse) {
        tempcategories.add(ChatGroup.fromJson(category));
      }
      setState(() {
        allGroups = tempcategories;
      });
    }
  }

  addGroup(String name) async {
    var response = await http.post(
      Uri.parse(
        APIRoutes.createGroup,
      ),
      body: {
        "name": name,
      },
    );
    if (response.statusCode == 200) {
      getGroups();

      setState(() {
        nameController.text = "";
      });
      Fluttertoast.showToast(
        msg: "Group added successfully",
      );
      Navigator.pop(context);
    } else {
      Fluttertoast.showToast(
          msg:
              "An error occured while trying to create your group. Please try again later.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) {
              return SimpleDialog(
                title: Text("Add Group"),
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextField(
                      controller: nameController,
                      decoration: InputDecoration(
                        hintText: "Group Name",
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: ElevatedButton(
                      onPressed: () {
                        addGroup(nameController.text);
                      },
                      child: Text("Add Group"),
                    ),
                  ),
                ],
              );
            },
          );
        },
        label: Text(
          "Add Group",
        ),
        icon: Icon(
          Icons.add,
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20),
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Icon(
                  Icons.arrow_back_ios,
                  color: Colors.white,
                  size: 40,
                ),
              ),
              SizedBox(height: 15),
              Text(
                "Chat Groups",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 5),
              Text(
                "View & Edit All Chat Groups.",
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              SizedBox(
                height: 20,
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: allGroups.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        elevation: 3,
                        child: ListTile(
                          leading: Text("#${index + 1}"),
                          title: Text(
                            "${allGroups[index].name}",
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          trailing: Wrap(
                            children: [
                              InkWell(
                                onTap: () async {},
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(
                                    CupertinoIcons.person_3_fill,
                                    color: Colors.blue,
                                    size: 30,
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: () async {
                                  Navigator.push(
                                    context,
                                    CupertinoPageRoute(
                                      builder: (_) => GroupChatScreen(
                                        chatGroup: allGroups[index],
                                      ),
                                    ),
                                  );
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(
                                    CupertinoIcons.chat_bubble_2,
                                    color: Colors.deepPurple,
                                    size: 30,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
