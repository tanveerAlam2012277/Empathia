import 'package:emp_admin/constants/api_routes.dart';
import 'package:emp_admin/models/mentaltest.model.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;

class EditMentalTest extends StatefulWidget {
  MentalTest test;
  EditMentalTest({required this.test});

  @override
  State<EditMentalTest> createState() => _EditMentalTestState();
}

class _EditMentalTestState extends State<EditMentalTest> {
  TextEditingController questionController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
            context: context,
            builder: (_) => AlertDialog(
              title: Text("Add Question"),
              content: TextField(
                controller: questionController,
                decoration: InputDecoration(
                  hintText: "Enter the question",
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  child: Text("Cancel"),
                ),
                TextButton(
                  onPressed: () async {
                    await http.post(
                        Uri.parse(
                          APIRoutes.addQuestion,
                        ),
                        body: {
                          "id": widget.test.id,
                          "question": questionController.text,
                        }).then((val) {
                      if (val.statusCode == 200) {
                        setState(() {
                          widget.test.questions.add(questionController.text);
                        });
                        questionController.clear();
                        Fluttertoast.showToast(
                          msg: "Question added successfully",
                          backgroundColor: Colors.green,
                        );
                        Navigator.pop(context);
                        Navigator.pop(context);
                      }
                    });
                  },
                  child: Text("Add"),
                ),
              ],
            ),
          );
        },
        child: Icon(Icons.add),
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(
            horizontal: 25.0,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20),
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Icon(
                  Icons.arrow_back_ios,
                  color: Colors.white,
                  size: 40,
                ),
              ),
              SizedBox(height: 15),
              Text(
                "Edit ${widget.test.name.toUpperCase()}",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 5),
              Text(
                "Edit questions for the weekly mental health test for this module.",
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              SizedBox(
                height: 20,
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: widget.test.questions.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        elevation: 3,
                        child: ListTile(
                          leading: Text("#${index + 1}"),
                          title: Text(
                            "${widget.test.questions[index]}",
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          trailing: IconButton(
                            onPressed: () async {
                              showDialog(
                                context: context,
                                builder: (context) {
                                  return AlertDialog(
                                    title: Text("Delete Question"),
                                    content: Text(
                                        "Are you sure you want to delete this question?"),
                                    actions: [
                                      TextButton(
                                        onPressed: () {
                                          Navigator.pop(context);
                                        },
                                        child: Text("Cancel"),
                                      ),
                                      TextButton(
                                        onPressed: () async {
                                          await http.delete(
                                            Uri.parse(
                                              APIRoutes.deleteQuestion,
                                            ),
                                            body: {
                                              "id": widget.test.id,
                                              "question":
                                                  widget.test.questions[index],
                                            },
                                          ).then((val) {
                                            if (val.statusCode == 200) {
                                              setState(() {
                                                widget.test.questions
                                                    .removeAt(index);
                                              });
                                              Fluttertoast.showToast(
                                                msg:
                                                    "Question removed successfully",
                                                backgroundColor: Colors.green,
                                              );
                                            }
                                            Navigator.pop(context);
                                            Navigator.pop(context);
                                          });
                                        },
                                        child: Text("Delete"),
                                      ),
                                    ],
                                  );
                                },
                              );
                            },
                            icon: Icon(Icons.delete),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
