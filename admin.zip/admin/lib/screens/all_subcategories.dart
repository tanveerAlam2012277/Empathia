import 'dart:convert';

import 'package:emp_admin/constants/api_routes.dart';
import 'package:emp_admin/models/subcategory.model.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:emp_admin/models/generic.model.dart';
import 'package:flutter/material.dart';

class AllSubcategoriesScreen extends StatefulWidget {
  const AllSubcategoriesScreen({super.key});

  @override
  State<AllSubcategoriesScreen> createState() => _AllSubcategoriesScreenState();
}

class _AllSubcategoriesScreenState extends State<AllSubcategoriesScreen> {
  List<Generic> categories = [];
  String selectedCategory = "";
  List<Subcategory> subcategories = [];
  TextEditingController subcategoryController = TextEditingController();

  @override
  void initState() {
    super.initState();
    getSubcategories();
    getCategories();
  }

  getCategories() async {
    var response = await http.get(
      Uri.parse(
        APIRoutes.getCategories,
      ),
    );
    var jsonResponse = jsonDecode(response.body)['categories'];
    if (response.statusCode == 200) {
      List<Generic> tempcategories = [];
      for (var category in jsonResponse) {
        tempcategories.add(Generic.fromJson(category));
      }
      setState(() {
        categories = tempcategories;
      });
    }
  }

  getSubcategories() async {
    var response = await http.get(
      Uri.parse(
        APIRoutes.getAllSubcategories,
      ),
    );
    var jsonResponse = jsonDecode(response.body)['subcategories'];
    if (response.statusCode == 200) {
      List<Subcategory> tempSubcategories = [];
      for (var subcategory in jsonResponse) {
        tempSubcategories.add(Subcategory.fromJson(subcategory));
      }
      setState(() {
        subcategories = tempSubcategories;
      });
    }
  }

  addSubcategory() {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Text(
                "Add New Subcategory",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: subcategoryController,
                decoration: InputDecoration(
                  hintText: "Subcategory Name",
                ),
              ),
              SizedBox(height: 10),
              DropdownButtonFormField(
                items: categories.map((category) {
                  return DropdownMenuItem(
                    child: Text(category.name),
                    value: category.id,
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedCategory = value.toString();
                  });
                },
                decoration: InputDecoration(
                  hintText: "Select Category",
                ),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  if (subcategoryController.text.isEmpty) {
                    Fluttertoast.showToast(msg: "Subcategory Name is required");
                    return;
                  }
                  Fluttertoast.showToast(
                    msg: "Adding Subcategory...",
                  );
                  await http.post(
                    Uri.parse(
                      APIRoutes.createSubcategory,
                    ),
                    body: {
                      "title": subcategoryController.text,
                      "category": selectedCategory,
                    },
                  ).then((response) {
                    if (response.statusCode == 200) {
                      Fluttertoast.showToast(
                        msg: jsonDecode(response.body)['message'],
                      );
                      getSubcategories();
                      Navigator.pop(context);
                    } else {
                      Fluttertoast.showToast(
                        msg: "Failed to add Subategory",
                      );
                      Navigator.pop(context);
                    }
                  });
                },
                child: Text(
                  "Add",
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  editSubcategory(int index) {
    setState(() {
      subcategoryController.text = subcategories[index].name;
    });
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Text(
                "Edit Subcategory",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: subcategoryController,
                decoration: InputDecoration(
                  hintText: "Subcategory Name",
                ),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  if (subcategoryController.text.isEmpty) {
                    Fluttertoast.showToast(msg: "Subcategory Name is required");
                    return;
                  }
                  Fluttertoast.showToast(
                    msg: "Updating Subcategory...",
                  );
                  await http.put(
                    Uri.parse(
                      APIRoutes.updateSubcategory +
                          "${subcategories[index].id}",
                    ),
                    body: {
                      "title": subcategoryController.text,
                    },
                  ).then((response) {
                    if (response.statusCode == 200) {
                      Fluttertoast.showToast(
                        msg: jsonDecode(response.body)['message'],
                      );
                      setState(() {
                        subcategories[index].name = subcategoryController.text;
                      });
                      Navigator.pop(context);
                    } else {
                      Fluttertoast.showToast(
                        msg: "Failed to update Subategory",
                      );
                      Navigator.pop(context);
                    }
                  });
                },
                child: Text(
                  "Update",
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  deleteSubcategory(String id) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Text(
                "Delete Subcategory",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Text(
                "Are you sure you want to delete this subcategory? All articles and subcategories attached to it will be deleted as well.",
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  Fluttertoast.showToast(
                    msg: "Deleting Subcategory...",
                  );
                  await http
                      .delete(
                    Uri.parse(
                      APIRoutes.deleteSubcategoryAndRelated + "$id",
                    ),
                  )
                      .then((response) {
                    if (response.statusCode == 200) {
                      Fluttertoast.showToast(
                        msg: jsonDecode(response.body)['message'],
                      );
                      Navigator.pop(context);
                      getSubcategories();
                    } else {
                      Fluttertoast.showToast(
                        msg: "Failed to delete Subcategory",
                      );
                      Navigator.pop(context);
                    }
                  });
                },
                child: Text(
                  "Delete",
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            subcategoryController.text = "";
          });
          addSubcategory();
        },
        child: Icon(
          Icons.add,
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20),
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Icon(
                  Icons.arrow_back_ios,
                  color: Colors.white,
                  size: 40,
                ),
              ),
              SizedBox(height: 15),
              Text(
                "Subcategories",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 5),
              Text(
                "Add New, View & Edit All Subcategories.",
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              SizedBox(
                height: 20,
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: subcategories.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        elevation: 3,
                        child: ListTile(
                          leading: Text("#${index + 1}"),
                          title: Text(
                            "${subcategories[index].name}",
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          subtitle: Text(
                            "from ${subcategories[index].categoryName}",
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.white54,
                            ),
                          ),
                          trailing: Wrap(
                            children: [
                              InkWell(
                                onTap: () {
                                  editSubcategory(index);
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(
                                    Icons.edit,
                                    color: Colors.blue,
                                    size: 30,
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: () {
                                  deleteSubcategory(subcategories[index].id);
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(
                                    Icons.delete,
                                    color: Colors.red,
                                    size: 30,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
