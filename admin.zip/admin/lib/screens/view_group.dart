import 'package:flutter/material.dart';

class ViewGroup extends StatefulWidget {
  const ViewGroup({super.key});

  @override
  State<ViewGroup> createState() => _ViewGroupState();
}

class _ViewGroupState extends State<ViewGroup> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
