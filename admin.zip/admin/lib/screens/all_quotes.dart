import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:emp_admin/constants/api_routes.dart';
import 'package:emp_admin/models/motivation.model.dart';
import 'package:emp_admin/screens/add_motivation.dart';
import 'package:emp_admin/screens/add_music.dart';
import 'package:emp_admin/screens/edit_music.dart';
import 'package:flutter/cupertino.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:emp_admin/models/music.model.dart';
import 'package:flutter/material.dart';

class AllQuotes extends StatefulWidget {
  const AllQuotes({super.key});

  @override
  State<AllQuotes> createState() => _AllQuotesState();
}

class _AllQuotesState extends State<AllQuotes> {
  List<Motivation> motivations = [];

  @override
  void initState() {
    super.initState();
    getMotivations();
  }

  getMotivations() async {
    var response = await http.get(
      Uri.parse(
        APIRoutes.getAllMotivation,
      ),
    );
    var jsonRes = jsonDecode(response.body)['motivations'];
    List<Motivation> motivationsList = [];
    for (var music in jsonRes) {
      motivationsList.add(Motivation.fromJson(music));
    }
    setState(() {
      motivations = motivationsList;
    });
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        return Scaffold(
          floatingActionButton: FloatingActionButton(
            onPressed: () {
              Navigator.push(
                context,
                CupertinoPageRoute(
                  builder: (_) => AddMotivation(),
                ),
              );
            },
            child: Icon(Icons.add),
          ),
          body: SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 25.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(height: 20),
                  InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Icon(
                      Icons.arrow_back_ios,
                      color: Colors.white,
                      size: 40,
                    ),
                  ),
                  SizedBox(height: 15),
                  Text(
                    "Motivational Quotes",
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    "View & Manage All Motivational Quotes",
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Expanded(
                    child: ListView.builder(
                      itemCount: motivations.length,
                      itemBuilder: (context, index) {
                        return Card(
                          child: ListTile(
                            leading: CachedNetworkImage(
                              imageUrl: motivations[index].image,
                              placeholder: (context, url) =>
                                  CupertinoActivityIndicator(),
                              errorWidget: (context, url, error) =>
                                  Icon(Icons.error),
                              height: 100,
                              width: 100,
                            ),
                            title: Text(
                              motivations[index].caption == ""
                                  ? "No Caption"
                                  : motivations[index].caption,
                            ),
                            trailing: IconButton(
                              icon: Icon(Icons.delete),
                              onPressed: () {
                                showDialog(
                                  context: context,
                                  builder: (context) {
                                    return AlertDialog(
                                      title: Text("Delete Motivation"),
                                      content: Text(
                                          "Are you sure you want to delete this Motivation?"),
                                      actions: [
                                        TextButton(
                                          onPressed: () {
                                            Navigator.pop(context);
                                          },
                                          child: Text("Cancel"),
                                        ),
                                        TextButton(
                                          onPressed: () async {
                                            var response = await http.delete(
                                              Uri.parse(
                                                APIRoutes.deleteMotivation,
                                              ),
                                              body: {
                                                "id": motivations[index].id,
                                              },
                                            );
                                            if (response.statusCode == 200) {
                                              getMotivations();
                                              Navigator.pop(context);
                                              Fluttertoast.showToast(
                                                msg: "Motivation Deleted",
                                                backgroundColor: Colors.green,
                                              );
                                            } else {
                                              Fluttertoast.showToast(
                                                msg: "An error occurred",
                                                backgroundColor: Colors.red,
                                              );
                                            }
                                          },
                                          child: Text("Delete"),
                                        ),
                                      ],
                                    );
                                  },
                                );
                              },
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
