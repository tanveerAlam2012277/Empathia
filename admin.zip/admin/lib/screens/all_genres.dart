import 'dart:convert';
import 'package:emp_admin/constants/api_routes.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:emp_admin/models/generic.model.dart';
import 'package:flutter/material.dart';

class AllGenresScreen extends StatefulWidget {
  const AllGenresScreen({super.key});

  @override
  State<AllGenresScreen> createState() => _AllGenresScreenState();
}

class _AllGenresScreenState extends State<AllGenresScreen> {
  List<Generic> genres = [];

  TextEditingController genreController = TextEditingController();

  @override
  void initState() {
    super.initState();
    getGenres();
  }

  getGenres() async {
    var response = await http.get(
      Uri.parse(
        APIRoutes.getGenres,
      ),
    );
    var jsonResponse = jsonDecode(response.body)['genres'];
    if (response.statusCode == 200) {
      List<Generic> tempgenres = [];
      for (var genre in jsonResponse) {
        tempgenres.add(Generic.fromJson(genre));
      }
      setState(() {
        genres = tempgenres;
      });
    }
  }

  addGenre() {
    setState(() {
      genreController.text = "";
    });
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Text(
                "Add Genre",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: genreController,
                decoration: InputDecoration(
                  hintText: "Genre Name",
                ),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  if (genreController.text.isEmpty) {
                    Fluttertoast.showToast(msg: "Genre Name is required");
                    return;
                  }
                  Fluttertoast.showToast(
                    msg: "Adding Genre...",
                  );
                  await http.post(
                    Uri.parse(
                      APIRoutes.createGenre,
                    ),
                    body: {
                      "title": genreController.text,
                    },
                  ).then((response) {
                    if (response.statusCode == 200) {
                      Fluttertoast.showToast(
                        msg: jsonDecode(response.body)['message'],
                      );
                      Navigator.pop(context);
                      getGenres();
                    } else {
                      Fluttertoast.showToast(
                        msg: "Failed to add Genre",
                      );
                      Navigator.pop(context);
                    }
                  });
                },
                child: Text(
                  "Add",
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  editGenre(int index) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Text(
                "Edit Genre",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: genreController,
                decoration: InputDecoration(
                  hintText: "Genre Name",
                ),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  if (genreController.text.isEmpty) {
                    Fluttertoast.showToast(msg: "Genre Name is required");
                    return;
                  }
                  Fluttertoast.showToast(
                    msg: "Updating Genre...",
                  );
                  await http.put(
                    Uri.parse(
                      APIRoutes.updateGenre + "${genres[index].id}",
                    ),
                    body: {
                      "title": genreController.text,
                    },
                  ).then((response) {
                    if (response.statusCode == 200) {
                      Fluttertoast.showToast(
                        msg: jsonDecode(response.body)['message'],
                      );
                      setState(() {
                        genres[index].name = genreController.text;
                      });
                      Navigator.pop(context);
                    } else {
                      Fluttertoast.showToast(
                        msg: "Failed to update Genre",
                      );
                      Navigator.pop(context);
                    }
                  });
                },
                child: Text(
                  "Update",
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  deleteGenre(String id) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Text(
                "Delete Genre",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Text(
                "Are you sure you want to delete this genre? All music attached to it will be deleted as well.",
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  Fluttertoast.showToast(
                    msg: "Deleting Genre...",
                  );
                  await http
                      .delete(
                    Uri.parse(
                      APIRoutes.deleteGenreAndRelated + "$id",
                    ),
                  )
                      .then((response) {
                    if (response.statusCode == 200) {
                      Fluttertoast.showToast(
                        msg: jsonDecode(response.body)['message'],
                      );
                      Navigator.pop(context);
                      getGenres();
                    } else {
                      Fluttertoast.showToast(
                        msg: "Failed to delete Genre",
                      );
                      Navigator.pop(context);
                    }
                  });
                },
                child: Text(
                  "Delete",
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          addGenre();
        },
        child: Icon(
          Icons.add,
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20),
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Icon(
                  Icons.arrow_back_ios,
                  color: Colors.white,
                  size: 40,
                ),
              ),
              SizedBox(height: 15),
              Text(
                "Genres",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 5),
              Text(
                "Add New, View & Edit All Genres.",
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              SizedBox(
                height: 20,
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: genres.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        elevation: 3,
                        child: ListTile(
                          leading: Text("#${index + 1}"),
                          title: Text(
                            "${genres[index].name}",
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          trailing: Wrap(
                            children: [
                              InkWell(
                                onTap: () {
                                  genreController.text = genres[index].name;
                                  editGenre(index);
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(
                                    Icons.edit,
                                    color: Colors.blue,
                                    size: 30,
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: () {
                                  deleteGenre(
                                    genres[index].id,
                                  );
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(
                                    Icons.delete,
                                    color: Colors.red,
                                    size: 30,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
