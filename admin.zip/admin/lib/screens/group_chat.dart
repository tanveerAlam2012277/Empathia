import 'dart:async';
import 'dart:convert';

import 'package:emp_admin/constants/api_routes.dart';
import 'package:emp_admin/models/chatgroup.model.dart';
import 'package:emp_admin/models/chatmessage.model.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;

class GroupChatScreen extends StatefulWidget {
  ChatGroup chatGroup;

  GroupChatScreen({required this.chatGroup});

  @override
  _GroupChatScreenState createState() => _GroupChatScreenState();
}

class _GroupChatScreenState extends State<GroupChatScreen> {
  List<ChatMessage> messages = [];
  bool isSendingMessage = false;

  final messageController = TextEditingController();

  String userID = "admin";

  Timer? timer;

  @override
  void initState() {
    super.initState();
    getAllMessages();
    timer = Timer.periodic(
      Duration(seconds: 5),
      (Timer t) => getAllMessages(),
    );
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  getAllMessages() {
    http.post(
      Uri.parse(
        APIRoutes.getMessages,
      ),
      body: {
        "groupId": widget.chatGroup.id,
      },
    ).then((response) {
      print(response.body);
      var jsonResponse = jsonDecode(response.body)['data'];
      if (response.statusCode == 200) {
        List<ChatMessage> tempMessages = [];
        for (var message in jsonResponse) {
          tempMessages.add(
            ChatMessage.fromJson(
              message,
              message['user'] == userID,
            ),
          );
        }
        setState(() {
          messages = tempMessages;
        });
      }
    });
  }

  addMessage() async {
    setState(() {
      isSendingMessage = true;
    });
    var result = await http.post(
      Uri.parse(
        APIRoutes.addMessage,
      ),
      body: {
        "message": messageController.text,
        "groupId": widget.chatGroup.id,
        "userId": "admin",
      },
    );
    if (result.statusCode == 200) {
      var jsonResponse = jsonDecode(result.body)['data'];
      ChatMessage sentMessage = ChatMessage.fromJson(jsonResponse, true);
      setState(() {
        messages = [sentMessage, ...messages];
        messageController.text = "";
        isSendingMessage = false;
      });
    } else {
      setState(() {
        isSendingMessage = false;
      });
      Fluttertoast.showToast(msg: "msg sending failed.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.chatGroup.name,
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              reverse: true,
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final message = messages[index];
                return Container(
                  padding: EdgeInsets.all(10),
                  child: Align(
                    alignment:
                        message.isMe ? Alignment.topRight : Alignment.topLeft,
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        maxWidth: MediaQuery.of(context).size.width *
                            0.5, // 50% of screen width
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20),
                            bottomLeft: message.isMe
                                ? Radius.circular(20)
                                : Radius.circular(0),
                            bottomRight: message.isMe
                                ? Radius.circular(0)
                                : Radius.circular(20),
                          ),
                          color: message.isMe ? Colors.blue : Colors.grey,
                        ),
                        padding: EdgeInsets.all(10),
                        child: Column(
                          crossAxisAlignment: message.isMe
                              ? CrossAxisAlignment.end
                              : CrossAxisAlignment.start,
                          children: [
                            Text(
                              message.senderName,
                              style: TextStyle(
                                color: Colors.black,
                              ),
                            ),
                            Text(
                              message.message,
                              style: TextStyle(color: Colors.white),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 8),
              child: TextField(
                onChanged: (value) {
                  setState(() {});
                },
                controller: messageController,
                decoration: InputDecoration(
                  hintText: 'Type a message',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  suffixIcon: IconButton(
                    icon: isSendingMessage
                        ? SizedBox(
                            height: 10,
                            width: 10,
                            child: CircularProgressIndicator(),
                          )
                        : Icon(
                            Icons.send,
                            color: messageController.text.isNotEmpty
                                ? Colors.blue
                                : Colors.grey,
                          ),
                    onPressed: () {
                      if (messageController.text.isNotEmpty) {
                        addMessage();
                      }
                    },
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
