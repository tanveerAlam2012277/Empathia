import 'dart:convert';
import 'package:emp_admin/constants/api_routes.dart';
import 'package:emp_admin/models/generic.model.dart';
import 'package:emp_admin/screens/all_articles.dart';
import 'package:emp_admin/screens/all_quotes.dart';
import 'package:emp_admin/screens/dashboard.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:html';
import 'package:flutter/material.dart';
import 'package:flutter_quill/flutter_quill.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

class AddMotivation extends StatefulWidget {
  const AddMotivation({super.key});

  @override
  State<AddMotivation> createState() => _AddMotivationState();
}

class _AddMotivationState extends State<AddMotivation> {
  QuillController _controller = QuillController.basic();
  TextEditingController captionController = TextEditingController();

  File? selectedImage;

  bool isLoading = false;

  @override
  void initState() {
    super.initState();
  }

  getImage() async {
    FileUploadInputElement uploadInput = FileUploadInputElement()
      ..accept = 'image/*';
    uploadInput.click();

    uploadInput.onChange.listen((e) {
      final file = uploadInput.files!.first;
      final reader = FileReader();
      reader.readAsDataUrl(file);
      reader.onLoadEnd.listen((event) {
        setState(() {
          selectedImage = file;
        });
      });
    });
  }

  submitArticle() async {
    setState(() {
      isLoading = true;
    });
    Fluttertoast.showToast(
      msg: "Your upload has started, please wait",
    );
    String dateTime =
        DateTime.now().millisecondsSinceEpoch.toString() + "_motivation";
    FirebaseStorage.instance
        .ref()
        .child(
          dateTime.toString(),
        )
        .putBlob(selectedImage)
        .then(
      (val) async {
        print("Image uploaded");
        await val.ref.getDownloadURL().then(
          (downloadURL) async {
            print(downloadURL);
            var respone = await http.post(
              Uri.parse(
                APIRoutes.createMotivation,
              ),
              body: {
                "image": downloadURL,
                "caption": captionController.text,
              },
            );
            var jsonData = jsonDecode(respone.body);
            print(jsonData);
            if (respone.statusCode == 200) {
              Fluttertoast.showToast(
                msg: "Motivated added successfully",
              );
              setState(() {
                isLoading = false;
              });
              // Go to All articles
              Navigator.pushAndRemoveUntil(
                context,
                MaterialPageRoute(
                  builder: (_) => DashboardScreen(),
                ),
                (route) => false,
              );
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AllQuotes(),
                ),
              );
            } else {
              Fluttertoast.showToast(
                msg: "Failed to save motivation",
              );
            }
          },
        );
      },
    ).catchError((e) {
      print(e);
      Fluttertoast.showToast(
        msg: "Failed to save motivation. Please try again ($e)",
      );
    }).onError((error, stackTrace) {
      print(error);
      Fluttertoast.showToast(
        msg: "Failed to save motivation. Please try again ($error)",
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 20),
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Icon(
                    Icons.arrow_back_ios,
                    color: Colors.white,
                    size: 40,
                  ),
                ),
                SizedBox(height: 15),
                Text(
                  "Add Motivation Post",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  "Add Motivation Post and a Suited Caption.",
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: TextFormField(
                        controller: captionController,
                        decoration: InputDecoration(
                          labelText: "Post Caption",
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(
                      flex: 2,
                      child: InkWell(
                        onTap: getImage,
                        child: Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: selectedImage != null
                                  ? Colors.green
                                  : Colors.white,
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Center(
                              child: Text(
                                selectedImage != null
                                    ? "Edit Image: ${selectedImage!.name}"
                                    : "Select Image",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 22,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 15,
                ),
                if (isLoading)
                  Center(
                    child: CircularProgressIndicator(),
                  ),
                if (!isLoading)
                  InkWell(
                    onTap: () async {
                      if (selectedImage != null) {
                        submitArticle();
                      } else {
                        Fluttertoast.showToast(
                          msg: "Please add an image.",
                        );
                      }
                    },
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.blue,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Center(
                          child: Text(
                            "Post Motivation",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                SizedBox(
                  height: 15,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
