import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:emp_admin/constants/api_routes.dart';
import 'package:emp_admin/screens/add_article.dart';
import 'package:emp_admin/screens/edit_article.dart';
import 'package:flutter/cupertino.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:emp_admin/models/article.model.dart';
import 'package:flutter/material.dart';

class AllArticles extends StatefulWidget {
  const AllArticles({super.key});

  @override
  State<AllArticles> createState() => _AllArticlesState();
}

class _AllArticlesState extends State<AllArticles> {
  List<Article> articles = [];

  @override
  void initState() {
    super.initState();
    getArticles();
  }

  getArticles() async {
    var response = await http.get(
      Uri.parse(
        APIRoutes.getArticles,
      ),
    );
    var jsonRes = jsonDecode(response.body)['articles'];
    List<Article> articlesList = [];
    for (var article in jsonRes) {
      articlesList.add(Article.fromJson(article));
    }
    setState(() {
      articles = articlesList;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            CupertinoPageRoute(
              builder: (_) => AddArticle(),
            ),
          );
        },
        child: Icon(Icons.add),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20),
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Icon(
                  Icons.arrow_back_ios,
                  color: Colors.white,
                  size: 40,
                ),
              ),
              SizedBox(height: 15),
              Text(
                "Articles",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 5),
              Text(
                "View & Edit All Articles.",
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              SizedBox(
                height: 20,
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: articles.length,
                  itemBuilder: (context, index) {
                    return Card(
                      child: ListTile(
                        leading: SizedBox(
                          height: 100,
                          width: 100,
                          child: CachedNetworkImage(
                            imageUrl: articles[index].image,
                            fit: BoxFit.cover,
                            placeholder: (context, url) =>
                                LinearProgressIndicator(),
                            errorWidget: (context, url, error) =>
                                Icon(Icons.error),
                          ),
                        ),
                        title: Text(articles[index].title),
                        subtitle: Text(
                          "In " +
                              articles[index].categoryName +
                              " > " +
                              articles[index].subcategoryName,
                        ),
                        trailing: Wrap(
                          children: [
                            IconButton(
                              icon: Icon(Icons.edit),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  CupertinoPageRoute(
                                    builder: (_) => EditArticle(
                                      article: articles[index],
                                    ),
                                  ),
                                );
                              },
                            ),
                            IconButton(
                              icon: Icon(Icons.delete),
                              onPressed: () async {
                                showDialog(
                                  context: context,
                                  builder: (context) {
                                    return AlertDialog(
                                      title: Text("Delete Article"),
                                      content: Text(
                                          "Are you sure you want to delete this article?"),
                                      actions: [
                                        TextButton(
                                          onPressed: () {
                                            Navigator.pop(context);
                                          },
                                          child: Text("Cancel"),
                                        ),
                                        TextButton(
                                          onPressed: () async {
                                            var response = await http.delete(
                                              Uri.parse(
                                                APIRoutes.deleteArticle +
                                                    articles[index].id,
                                              ),
                                            );
                                            if (response.statusCode == 200) {
                                              Fluttertoast.showToast(
                                                  msg: "Article Deleted");
                                              getArticles();
                                              Navigator.pop(context);
                                            }
                                          },
                                          child: Text("Delete"),
                                        ),
                                      ],
                                    );
                                  },
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
