import 'dart:convert';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:emp_admin/constants/api_routes.dart';
import 'package:emp_admin/screens/add_music.dart';
import 'package:emp_admin/screens/edit_music.dart';
import 'package:flutter/cupertino.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:emp_admin/models/music.model.dart';
import 'package:flutter/material.dart';

class AllMusics extends StatefulWidget {
  const AllMusics({super.key});

  @override
  State<AllMusics> createState() => _AllMusicsState();
}

class _AllMusicsState extends State<AllMusics> {
  List<Music> musics = [];

  @override
  void initState() {
    super.initState();
    getMusics();
  }

  getMusics() async {
    var response = await http.get(
      Uri.parse(
        APIRoutes.getAllMusic,
      ),
    );
    var jsonRes = jsonDecode(response.body)['musics'];
    List<Music> musicsList = [];
    for (var music in jsonRes) {
      musicsList.add(Music.fromJson(music));
    }
    setState(() {
      musics = musicsList;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            CupertinoPageRoute(
              builder: (_) => AddMusic(),
            ),
          );
        },
        child: Icon(Icons.add),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20),
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Icon(
                  Icons.arrow_back_ios,
                  color: Colors.white,
                  size: 40,
                ),
              ),
              SizedBox(height: 15),
              Text(
                "Musics",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 5),
              Text(
                "View & Edit All Musics.",
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              SizedBox(
                height: 20,
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: musics.length,
                  itemBuilder: (context, index) {
                    return Card(
                      child: ListTile(
                        leading: SizedBox(
                          height: 100,
                          width: 100,
                          child: CachedNetworkImage(
                            imageUrl: musics[index].image,
                            fit: BoxFit.cover,
                            placeholder: (context, url) =>
                                LinearProgressIndicator(),
                            errorWidget: (context, url, error) =>
                                Icon(Icons.error),
                          ),
                        ),
                        title: Text(musics[index].title),
                        subtitle: Text("In " + musics[index].genreName),
                        trailing: Wrap(
                          children: [
                            IconButton(
                              icon: Icon(Icons.edit),
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  CupertinoPageRoute(
                                    builder: (_) => EditMusic(
                                      music: musics[index],
                                    ),
                                  ),
                                );
                              },
                            ),
                            IconButton(
                              icon: Icon(Icons.delete),
                              onPressed: () async {
                                showDialog(
                                  context: context,
                                  builder: (context) {
                                    return AlertDialog(
                                      title: Text("Delete Music"),
                                      content: Text(
                                          "Are you sure you want to delete this music?"),
                                      actions: [
                                        TextButton(
                                          onPressed: () {
                                            Navigator.pop(context);
                                          },
                                          child: Text("Cancel"),
                                        ),
                                        TextButton(
                                          onPressed: () async {
                                            var response = await http.delete(
                                              Uri.parse(
                                                APIRoutes.deleteMusic +
                                                    "/" +
                                                    musics[index].id,
                                              ),
                                            );
                                            if (response.statusCode == 200) {
                                              Fluttertoast.showToast(
                                                  msg: "Music Deleted");
                                              getMusics();
                                              Navigator.pop(context);
                                            }
                                          },
                                          child: Text("Delete"),
                                        ),
                                      ],
                                    );
                                  },
                                );
                              },
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
