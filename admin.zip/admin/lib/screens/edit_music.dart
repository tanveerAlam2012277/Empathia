import 'dart:convert';
import 'package:emp_admin/constants/api_routes.dart';
import 'package:emp_admin/models/generic.model.dart';
import 'package:emp_admin/models/music.model.dart';
import 'package:emp_admin/screens/all_music.dart';
import 'package:emp_admin/screens/dashboard.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'dart:html';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;

class EditMusic extends StatefulWidget {
  Music music;

  EditMusic({required this.music});

  @override
  State<EditMusic> createState() => _EditMusicState();
}

class _EditMusicState extends State<EditMusic> {
  TextEditingController titleController = TextEditingController();
  TextEditingController categoryController = TextEditingController();

  List<Generic> categories = [];

  Generic? selectedCategory;
  File? selectedImage;
  File? selectedAudio;

  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    getCategories();
  }

  getCategories() {
    http
        .get(
      Uri.parse(
        APIRoutes.getGenres,
      ),
    )
        .then((response) {
      var jsonData = jsonDecode(response.body)['genres'];
      List<Generic> cats = [];
      for (var item in jsonData) {
        cats.add(Generic.fromJson(item));
      }
      setState(() {
        categories = cats;
        selectedCategory = categories.firstWhere(
          (element) => element.id == widget.music.genreID,
        );
        titleController.text = widget.music.title;
      });
    });
  }

  getImage() async {
    FileUploadInputElement uploadInput = FileUploadInputElement()
      ..accept = 'image/*';
    uploadInput.click();

    uploadInput.onChange.listen((e) {
      final file = uploadInput.files!.first;
      final reader = FileReader();
      reader.readAsDataUrl(file);
      reader.onLoadEnd.listen((event) {
        setState(() {
          selectedImage = file;
        });
      });
    });
  }

  getAudioFile() async {
    FileUploadInputElement uploadInput = FileUploadInputElement()
      ..accept = 'audio/*';
    uploadInput.click();

    uploadInput.onChange.listen((e) {
      final file = uploadInput.files!.first;
      final reader = FileReader();
      reader.readAsDataUrl(file);
      reader.onLoadEnd.listen((event) {
        setState(() {
          selectedAudio = file;
        });
      });
    });
  }

  submitArticle() async {
    setState(() {
      isLoading = true;
    });
    Fluttertoast.showToast(
      msg: "Your upload has started, please wait",
    );
    final dateTime = DateTime.now().millisecondsSinceEpoch;
    String imageURL = widget.music.image;
    String audioURL = widget.music.url;

    if (selectedImage != null) {
      final ref = FirebaseStorage.instance.ref().child("music_$dateTime.jpg");
      await ref.putBlob(selectedImage!);
      imageURL = await ref.getDownloadURL();
    }

    if (selectedAudio != null) {
      final ref = FirebaseStorage.instance.ref().child("music_$dateTime.mp3");
      await ref.putBlob(selectedAudio!);
      audioURL = await ref.getDownloadURL();
    }

    var respone = await http.put(
      Uri.parse(
        APIRoutes.updateMusic + "/" + widget.music.id,
      ),
      body: {
        "image": imageURL,
        "title": titleController.text,
        "genre": selectedCategory!.id,
        "url": audioURL,
      },
    );
    var jsonData = jsonDecode(respone.body);
    print(jsonData);
    if (respone.statusCode == 200) {
      Fluttertoast.showToast(
        msg: "Music saved successfully",
      );
      setState(() {
        isLoading = false;
      });
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(
          builder: (_) => DashboardScreen(),
        ),
        (route) => false,
      );
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => AllMusics(),
        ),
      );
    } else {
      Fluttertoast.showToast(
        msg: "Failed to save Music. Please try again.",
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 20),
                InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Icon(
                    Icons.arrow_back_ios,
                    color: Colors.white,
                    size: 40,
                  ),
                ),
                SizedBox(height: 15),
                Text(
                  "Edit Music",
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  "Edit details for music file.",
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: TextFormField(
                        controller: titleController,
                        decoration: InputDecoration(
                          labelText: "Music Title",
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(
                      flex: 2,
                      child: InkWell(
                        onTap: getImage,
                        child: Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: selectedImage != null
                                  ? Colors.green
                                  : Colors.white,
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Center(
                              child: Text(
                                selectedImage != null
                                    ? "Edit Image: ${selectedImage!.name}"
                                    : "Select Image (Leave empty to keep the same)",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  children: [
                    Expanded(
                      flex: 2,
                      child: IgnorePointer(
                        child: DropdownButtonFormField<Generic>(
                          value: selectedCategory,
                          onChanged: (value) {
                            setState(() {
                              selectedCategory = value;
                              categoryController.text = value!.id;
                            });
                          },
                          items: categories.map((Generic category) {
                            return DropdownMenuItem<Generic>(
                              value: category,
                              child: Text(category.name),
                            );
                          }).toList(),
                          decoration: InputDecoration(
                            labelText: "Genre",
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 20,
                    ),
                    Expanded(
                      flex: 2,
                      child: InkWell(
                        onTap: getAudioFile,
                        child: Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: selectedAudio != null
                                  ? Colors.green
                                  : Colors.white,
                            ),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Center(
                              child: Text(
                                selectedAudio != null
                                    ? "Edit Audio: ${selectedAudio!.name}"
                                    : "Select Audio (Leave empty to keep the same)",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 15,
                ),
                if (isLoading)
                  Center(
                    child: CircularProgressIndicator(),
                  ),
                if (!isLoading)
                  InkWell(
                    onTap: () async {
                      if (titleController.text.isNotEmpty &&
                          selectedCategory != null) {
                        submitArticle();
                      } else {
                        Fluttertoast.showToast(
                          msg: "You can't leave title empty.",
                        );
                      }
                    },
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: Colors.blue,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Center(
                          child: Text(
                            "Save Music",
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                SizedBox(
                  height: 15,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
