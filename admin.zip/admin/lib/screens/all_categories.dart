import 'dart:convert';
import 'package:emp_admin/constants/api_routes.dart';
import 'package:emp_admin/models/subcategory.model.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:emp_admin/models/generic.model.dart';
import 'package:flutter/material.dart';

class AllCategoriesScreen extends StatefulWidget {
  const AllCategoriesScreen({super.key});

  @override
  State<AllCategoriesScreen> createState() => _AllCategoriesScreenState();
}

class _AllCategoriesScreenState extends State<AllCategoriesScreen> {
  List<Generic> categories = [];

  TextEditingController categoryController = TextEditingController();

  @override
  void initState() {
    super.initState();
    getCategories();
  }

  getCategories() async {
    var response = await http.get(
      Uri.parse(
        APIRoutes.getCategories,
      ),
    );
    var jsonResponse = jsonDecode(response.body)['categories'];
    if (response.statusCode == 200) {
      List<Generic> tempcategories = [];
      for (var category in jsonResponse) {
        tempcategories.add(Generic.fromJson(category));
      }
      setState(() {
        categories = tempcategories;
      });
    }
  }

  addCategory() {
    setState(() {
      categoryController.text = "";
    });
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Text(
                "Add Category",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: categoryController,
                decoration: InputDecoration(
                  hintText: "Category Name",
                ),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  if (categoryController.text.isEmpty) {
                    Fluttertoast.showToast(msg: "Category Name is required");
                    return;
                  }
                  Fluttertoast.showToast(
                    msg: "Adding Category...",
                  );
                  await http.post(
                    Uri.parse(
                      APIRoutes.createCategory,
                    ),
                    body: {
                      "title": categoryController.text,
                    },
                  ).then((response) {
                    if (response.statusCode == 200) {
                      Fluttertoast.showToast(
                        msg: jsonDecode(response.body)['message'],
                      );
                      Navigator.pop(context);
                      getCategories();
                    } else {
                      Fluttertoast.showToast(
                        msg: "Failed to add Category",
                      );
                      Navigator.pop(context);
                    }
                  });
                },
                child: Text(
                  "Add",
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  editCategory(int index) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Text(
                "Edit Category",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              TextFormField(
                controller: categoryController,
                decoration: InputDecoration(
                  hintText: "Category Name",
                ),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  if (categoryController.text.isEmpty) {
                    Fluttertoast.showToast(msg: "Category Name is required");
                    return;
                  }
                  Fluttertoast.showToast(
                    msg: "Updating Category...",
                  );
                  await http.put(
                    Uri.parse(
                      APIRoutes.updateCategory + "${categories[index].id}",
                    ),
                    body: {
                      "title": categoryController.text,
                    },
                  ).then((response) {
                    if (response.statusCode == 200) {
                      Fluttertoast.showToast(
                        msg: jsonDecode(response.body)['message'],
                      );
                      setState(() {
                        categories[index].name = categoryController.text;
                      });
                      Navigator.pop(context);
                    } else {
                      Fluttertoast.showToast(
                        msg: "Failed to update Category",
                      );
                      Navigator.pop(context);
                    }
                  });
                },
                child: Text(
                  "Update",
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  deleteCategory(String id) {
    showModalBottomSheet(
      context: context,
      builder: (context) {
        return Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              Text(
                "Delete Category",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Text(
                "Are you sure you want to delete this category? All articles and subcategories attached to it will be deleted as well.",
                style: TextStyle(
                  fontSize: 18,
                ),
              ),
              SizedBox(height: 10),
              ElevatedButton(
                onPressed: () async {
                  Fluttertoast.showToast(
                    msg: "Deleting Category...",
                  );
                  await http
                      .delete(
                    Uri.parse(
                      APIRoutes.deleteCategoryAndRelated + "$id",
                    ),
                  )
                      .then((response) {
                    if (response.statusCode == 200) {
                      Fluttertoast.showToast(
                        msg: jsonDecode(response.body)['message'],
                      );
                      Navigator.pop(context);
                      getCategories();
                    } else {
                      Fluttertoast.showToast(
                        msg: "Failed to delete Category",
                      );
                      Navigator.pop(context);
                    }
                  });
                },
                child: Text(
                  "Delete",
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          addCategory();
        },
        child: Icon(
          Icons.add,
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20),
              InkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Icon(
                  Icons.arrow_back_ios,
                  color: Colors.white,
                  size: 40,
                ),
              ),
              SizedBox(height: 15),
              Text(
                "Categories",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 5),
              Text(
                "Add New, View & Edit All Categories.",
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              SizedBox(
                height: 20,
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: categories.length,
                  itemBuilder: (context, index) {
                    return Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Card(
                        elevation: 3,
                        child: ListTile(
                          leading: Text("#${index + 1}"),
                          title: Text(
                            "${categories[index].name}",
                            style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          trailing: Wrap(
                            children: [
                              InkWell(
                                onTap: () {
                                  categoryController.text =
                                      categories[index].name;
                                  editCategory(index);
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(
                                    Icons.edit,
                                    color: Colors.blue,
                                    size: 30,
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: () {
                                  deleteCategory(
                                    categories[index].id,
                                  );
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: Icon(
                                    Icons.delete,
                                    color: Colors.red,
                                    size: 30,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
