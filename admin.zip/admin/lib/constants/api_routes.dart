class APIRoutes {
  // static const String baseURL =
  //     "https://empbackend-production-6ba5.up.railway.app/";
  static const String baseURL =
      "https://empbackend-production-6ea7.up.railway.app/";
  static const String createArticle = baseURL + "article/create";
  static const String getArticles = baseURL + "articles";
  static const String getAllSubcategories = baseURL + "allsubcategories";
  static const String getCategories = baseURL + "categories";
  static const String getSubcategoriesByCat =
      baseURL + "categories/subcategories";
  static const String getSubcategoriesAndArticles = baseURL + "articles";
  static const String createCategory = baseURL + "category/create";
  static const String createSubcategory = baseURL + "subcategory/create";
  static const String updateCategory = baseURL + "category/update/";
  static const String updateSubcategory = baseURL + "subcategory/update/";
  static const String updateArticle = baseURL + "article/update/";
  static const String deleteArticle = baseURL + "article/delete/";
  static const String deleteCategoryAndRelated = baseURL + "category/delete/";
  static const String deleteSubcategoryAndRelated =
      baseURL + "subcategory/delete/";

  static const String createMusic = baseURL + "music/create";
  static const String createGenre = baseURL + "genre/create";
  static const String getAllMusic = baseURL + "musics";
  static const String getGenres = baseURL + "genres";
  static const String updateGenre = baseURL + "genre/update";
  static const String updateMusic = baseURL + "music/update";
  static const String deleteGenreAndRelated = baseURL + "genre/delete";
  static const String deleteMusic = baseURL + "music/delete";

  static const String getTests = baseURL + "test/get";
  static const String addQuestion = baseURL + "test/addQuestion";
  static const String deleteQuestion = baseURL + "test/deleteQuestion";

  static const String counts = baseURL + "counts";

  static const String users = baseURL + "users";
  static const String cycos = baseURL + "cyco/users";
  static const String approveCycos = baseURL + "cyco/approve";
  static const String unapproveCycos = baseURL + "cyco/unapprove";

  static const String createPost = baseURL + "post/create";
  static const String deletePost = baseURL + "post/delete";
  static const String likePost = baseURL + "post/like";
  static const String unlikePost = baseURL + "post/unlike";
  static const String getAllPosts = baseURL + "post/getAll";

  static const String getAllGroups = baseURL + "group/all";
  static const String createGroup = baseURL + "group/create";
  static const String addMessage = baseURL + "group/addMessage";
  static const String getMessages = baseURL + "group/messages/";

  static const String createMotivation = baseURL + "motivation/create";
  static const String getAllMotivation = baseURL + "motivation/all";
  static const String deleteMotivation = baseURL + "motivation/delete";
  static const String submitTest = baseURL + "motivation/delete";
}
