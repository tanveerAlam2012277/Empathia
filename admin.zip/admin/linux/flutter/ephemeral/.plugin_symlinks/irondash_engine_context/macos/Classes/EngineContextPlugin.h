#import <FlutterMacOS/FlutterMacOS.h>

@interface IrondashEngineContextPlugin : NSObject <FlutterPlugin>
@end
