## 0.5.3

- Fix Android debug with Rust 1.78

## 0.5.2

- Update cargokit

## 0.5.1

- Update cargokit

## 0.5.0

- Bump version to match Rust crate version.

## 0.4.1

- **FEAT**: update cargokit
- **CHORE**: add android namespace

## 0.4.0

- **FEAT**: update cargokit

## 0.4.0-dev.2

- **FEAT**: update cargokit

## 0.4.0-dev.1

- **FEAT**: add precompiled binaries

## 0.3.1

 - **FEAT**: upgrade to dart 3.0  (#24).

## 0.3.0

- **FEAT**: improved support for FFI plugins

## 0.2.0

  - **FEAT**: dart 3 support

## 0.1.1

 - **FIX**: [android] build failing with proguard enabled (#18).
 - **FIX**: rename engine plugin file.
 - **FIX**: typo in comments.
 - **FIX**: rename package name.
 - **FEAT**: add irondash_texture (#8).
 - **FEAT**: rename to irondash (#5).
 - **FEAT**: add ironbird_engine_context (#2).
 - **DOCS**: add license symlinks.
 - **DOCS**: move license to root.
 - **DOCS**: move readme outside of package.
 - **DOCS**: improve comments.

## 0.1.0

* Initial release.
