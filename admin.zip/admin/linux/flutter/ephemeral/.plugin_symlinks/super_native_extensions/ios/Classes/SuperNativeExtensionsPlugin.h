#import <Flutter/Flutter.h>

@interface SuperNativeExtensionsPlugin : NSObject<FlutterPlugin>
@end
