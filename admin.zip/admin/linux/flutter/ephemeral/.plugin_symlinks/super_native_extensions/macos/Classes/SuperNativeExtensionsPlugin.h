#import <FlutterMacOS/FlutterMacOS.h>

@interface SuperNativeExtensionsPlugin : NSObject<FlutterPlugin>
@end
