# super_native_extensions

This plugin contains native functionality for [`super_clipboard`](https://pub.dev/packages/super_clipboard) and [`super_drag_and_drop`](https://pub.dev/packages/super_drag_and_drop).
