bool snapshotToImageSupportedInternal() {
  return true;
}
