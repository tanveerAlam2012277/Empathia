import 'package:flutter_web_plugins/flutter_web_plugins.dart';

/// A web implementation of the SuperNativeExtensionsPlatform of the SuperNativeExtensions plugin.
class SuperNativeExtensionsWeb {
  /// Constructs a SuperNativeExtensionsWeb
  SuperNativeExtensionsWeb();

  static void registerWith(Registrar registrar) {}
}
